# ClarifAI RAG - Product Requirements Document (Implementation Guide)

> Step-by-step implementation guide for adding RAG to ClarifAI.
> Each step includes the exact file, line numbers, and complete code to write or modify.
> Refer to `RAG.md` for architectural rationale.

---

## Prerequisites

Before starting, ensure:

- [ ] PostgreSQL server is running at `localhost:5432` with database `clarifai_system`
- [ ] You have admin access to install PostgreSQL extensions
- [ ] A valid Gemini API key that supports the `gemini-embedding-001` model
- [ ] Python virtual environment is active with existing dependencies installed

---

## Step 1: Install Python Dependencies

**File:** `ClarifAI/requirements.txt`
**Current state:** 15 lines, ends with `pydantic`

**Action:** Append two lines at the end of the file (after line 15):

```
pgvector
google-genai
```

**Then run:**

```bash
pip install pgvector google-genai psycopg2-binary
```

> `psycopg2-binary` is the PostgreSQL adapter required by SQLAlchemy. It may already be installed but is not listed in requirements.txt. Install it explicitly.

**Verification:** `python -c "from pgvector.sqlalchemy import Vector; print('pgvector OK')"` should print `pgvector OK`.

---

## Step 2: Enable pgvector Extension in PostgreSQL

**Action:** Connect to the PostgreSQL database and run:

```sql
\c clarifai_system
CREATE EXTENSION IF NOT EXISTS vector;
```

**Verification:** `SELECT * FROM pg_extension WHERE extname = 'vector';` should return one row.

---

## Step 3: Add Environment Variables

**File:** `ClarifAI/.env`
**Current state:** 5 lines ending with `GEMINI_API_KEY = YOUR_GEMINI_API_KEY`

**Action:** Append after line 5:

```
# RAG Configuration
RAG_ENABLED=true
RAG_EMBEDDING_MODEL=gemini-embedding-001
RAG_EMBEDDING_DIMENSIONS=768
RAG_RETRIEVAL_K=5
RAG_SIMILARITY_THRESHOLD=0.70
RAG_MAX_EXAMPLES=3
RAG_MIN_STORIES_FOR_RETRIEVAL=10
```

---

## Step 4: Update Database Configuration

**File:** `ClarifAI/db.py`
**Current state:** 8 lines total

```python
# db.py
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

DATABASE_URL = "postgresql://postgres:YOURUSERNAME@localhost:5432/clarifai_system"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
```

**Action:** Replace the entire file with:

```python
# db.py
from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import sessionmaker

DATABASE_URL = "postgresql://postgres:YOURUSERNAME@localhost:5432/clarifai_system"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@event.listens_for(engine, "connect")
def _register_pgvector(dbapi_connection, connection_record):
    """Register pgvector types when a new database connection is established."""
    try:
        from pgvector.sqlalchemy import Vector  # noqa: F401 - triggers type registration
    except ImportError:
        pass


def init_vector_extension():
    """One-time utility: enable the pgvector extension in PostgreSQL."""
    with engine.connect() as conn:
        conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        conn.commit()
```

**What changed:**
- Added `event, text` to imports (line 2)
- Added `_register_pgvector` listener that fires on every new DB connection to register the `Vector` type
- Added `init_vector_extension()` utility for one-time setup from Python

---

## Step 5: Add the UserStoryEmbedding Model

**File:** `ClarifAI/models.py`
**Current state:** 15 lines with only `ProgressTracker` model

```python
from sqlalchemy import Column, String, Text, TIMESTAMP, ARRAY
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class ProgressTracker(Base):
    __tablename__ = "clarifai_progress_tracker"
    doc_id = Column(String(64), primary_key=True)
    doc_name = Column(String(255), nullable=False)
    stage = Column(String(50), nullable=False)
    output_paths = Column(ARRAY(Text))
    date_last_modified = Column(TIMESTAMP, default=datetime.utcnow)
```

**Action:** Replace the entire file with:

```python
import uuid
from sqlalchemy import Column, String, Text, TIMESTAMP, ARRAY, Float, Integer, Boolean
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

try:
    from pgvector.sqlalchemy import Vector
except ImportError:
    Vector = None  # Graceful fallback if pgvector not installed

Base = declarative_base()


class ProgressTracker(Base):
    __tablename__ = "clarifai_progress_tracker"

    doc_id = Column(String(64), primary_key=True)
    doc_name = Column(String(255), nullable=False)
    stage = Column(String(50), nullable=False)
    output_paths = Column(ARRAY(Text))
    date_last_modified = Column(TIMESTAMP, default=datetime.utcnow)


class UserStoryEmbedding(Base):
    __tablename__ = "clarifai_user_story_embeddings"

    # Primary key
    id = Column(String(64), primary_key=True, default=lambda: uuid.uuid4().hex)

    # User story content
    user_story_id = Column(String(20), nullable=False)
    title = Column(String(500), nullable=False)
    user_story_text = Column(Text, nullable=False)
    acceptance_criteria = Column(ARRAY(Text))
    description = Column(Text)

    # Source requirement
    requirement_id = Column(String(20))
    requirement_text = Column(Text)

    # Metadata for filtering
    tags = Column(ARRAY(Text))
    priority = Column(String(20))
    tshirt_size = Column(String(5))
    confidence_score = Column(Float)

    # Source tracking
    source_agent = Column(String(50), nullable=False)
    source_doc_id = Column(String(64))

    # Embedding vector (768 dimensions)
    embedding = Column(Vector(768), nullable=False) if Vector else Column(Text)

    # Timestamps
    created_at = Column(TIMESTAMP, default=datetime.utcnow)

    # Quality signals
    user_rating = Column(Integer)
    was_edited = Column(Boolean, default=False)
```

**What changed:**
- Added `uuid`, `Float`, `Integer`, `Boolean` imports
- Added `pgvector.sqlalchemy.Vector` import with graceful fallback
- Added `UserStoryEmbedding` class with all fields from the RAG.md schema
- `ProgressTracker` is unchanged

**After saving, create the table:**

```python
python -c "from models import Base; from db import engine; Base.metadata.create_all(engine); print('Tables created')"
```

---

## Step 6: Create `tools/embedding_utils.py` (New File)

**File:** `ClarifAI/tools/embedding_utils.py` (new)

**Action:** Create this file with the following content:

```python
# tools/embedding_utils.py
"""
Embedding generation utilities using Gemini gemini-embedding-001.
Uses the google.genai SDK (same pattern as agents/image_extractor_agent.py line 7).
"""
import os
import time
import logging
from typing import List, Optional

from google import genai
from google.genai import types

from utils.logger import get_logger

logger = get_logger()

# Configuration from environment
EMBEDDING_MODEL = os.getenv("RAG_EMBEDDING_MODEL", "gemini-embedding-001")
EMBEDDING_DIMENSIONS = int(os.getenv("RAG_EMBEDDING_DIMENSIONS", "768"))
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "YOUR_GEMINI_API_KEY")


def compose_embedding_text(story: dict) -> str:
    """
    Build the composite text to embed from a user story dict.

    Handles both output schemas:
    - UserStoryAgent: uses "user_story", "acceptance_criteria", "tags"
    - RequirementUserStoryAgent: uses "story", "acceptanceCriteria", "Tags/Labels"
    - UserStoryFeedbackAgent: uses "story", "acceptanceCriteria", "tags"
    """
    parts = []

    if story.get("title"):
        parts.append(f"Title: {story['title']}")

    # Handle both agent output key names
    story_text = story.get("user_story") or story.get("story", "")
    if story_text:
        parts.append(f"Story: {story_text}")

    criteria = story.get("acceptance_criteria") or story.get("acceptanceCriteria") or []
    if criteria:
        parts.append("Acceptance Criteria:")
        for c in criteria:
            parts.append(f"- {c}")

    tags = story.get("tags") or story.get("Tags/Labels") or []
    if tags:
        if isinstance(tags, list):
            parts.append(f"Tags: {', '.join(str(t) for t in tags)}")
        else:
            parts.append(f"Tags: {tags}")

    return "\n".join(parts)


def generate_embedding(text: str, api_key: str = None, dimensions: int = None) -> List[float]:
    """
    Generate a single embedding vector using Gemini embedding API.

    Args:
        text: The text to embed.
        api_key: Optional API key override.
        dimensions: Optional dimension override (default: 768).

    Returns:
        List of floats (the embedding vector).

    Raises:
        Exception if all retry attempts fail.
    """
    key = api_key or GEMINI_API_KEY
    dims = dimensions or EMBEDDING_DIMENSIONS

    client = genai.Client(api_key=key)

    for attempt in range(3):
        try:
            result = client.models.embed_content(
                model=EMBEDDING_MODEL,
                contents=text,
                config=types.EmbedContentConfig(
                    output_dimensionality=dims,
                ),
            )
            return result.embeddings[0].values
        except Exception as e:
            wait = 2 ** attempt  # 1s, 2s, 4s
            logger.warning(f"[embedding_utils] Attempt {attempt + 1}/3 failed: {e}. Retrying in {wait}s...")
            time.sleep(wait)

    raise Exception(f"Failed to generate embedding after 3 attempts for text: {text[:100]}...")


def generate_embeddings_batch(texts: List[str], api_key: str = None, dimensions: int = None) -> List[List[float]]:
    """
    Batch embed multiple texts.

    Tries batch API first. Falls back to individual calls if batch fails.

    Args:
        texts: List of strings to embed.
        api_key: Optional API key override.
        dimensions: Optional dimension override.

    Returns:
        List of embedding vectors (same order as input texts).
    """
    if not texts:
        return []

    key = api_key or GEMINI_API_KEY
    dims = dimensions or EMBEDDING_DIMENSIONS

    # Try batch call
    try:
        client = genai.Client(api_key=key)
        result = client.models.embed_content(
            model=EMBEDDING_MODEL,
            contents=texts,
            config=types.EmbedContentConfig(
                output_dimensionality=dims,
            ),
        )
        return [emb.values for emb in result.embeddings]
    except Exception as e:
        logger.warning(f"[embedding_utils] Batch embed failed: {e}. Falling back to individual calls.")

    # Fallback: embed one by one
    embeddings = []
    for text in texts:
        try:
            emb = generate_embedding(text, api_key=key, dimensions=dims)
            embeddings.append(emb)
        except Exception as e:
            logger.error(f"[embedding_utils] Failed to embed text: {e}. Skipping.")
            embeddings.append(None)

    return embeddings
```

**Key nuances:**
- Uses `google.genai.Client(api_key=...)` pattern from `image_extractor_agent.py:58`
- `compose_embedding_text` handles 3 different agent output schemas (field name variations)
- `generate_embedding` has exponential backoff retry (3 attempts: 1s, 2s, 4s)
- `generate_embeddings_batch` tries batch first, falls back to individual on failure
- `None` is returned for individually failed embeddings in fallback mode (caller must handle)

---

## Step 7: Create `tools/vector_store.py` (New File)

**File:** `ClarifAI/tools/vector_store.py` (new)

**Action:** Create this file:

```python
# tools/vector_store.py
"""
pgvector CRUD operations for user story embeddings.
Uses the existing SessionLocal from db.py and UserStoryEmbedding from models.py.
"""
import uuid
import logging
from typing import List, Dict, Optional

from sqlalchemy import text, func
from db import SessionLocal
from models import UserStoryEmbedding

from utils.logger import get_logger

logger = get_logger()


def store_user_story(
    story: dict,
    embedding: List[float],
    source_agent: str = "unknown",
    requirement_text: str = None,
    session=None
) -> Optional[str]:
    """
    Insert a single user story + embedding into the vector store.

    Args:
        story: User story dict (from any agent output).
        embedding: The embedding vector (768 floats).
        source_agent: Which agent produced this story.
        requirement_text: The original requirement text (for display during retrieval).
        session: Optional SQLAlchemy session. Creates one if not provided.

    Returns:
        The database record ID, or None if insertion failed.
    """
    own_session = session is None
    if own_session:
        session = SessionLocal()

    try:
        # Extract fields handling both agent schemas
        story_text = story.get("user_story") or story.get("story", "")

        # Deduplication: skip if exact text already exists
        existing = session.query(UserStoryEmbedding).filter(
            UserStoryEmbedding.user_story_text == story_text
        ).first()

        if existing:
            logger.info(f"[vector_store] Duplicate story skipped: {story_text[:80]}...")
            return existing.id

        record_id = uuid.uuid4().hex
        record = UserStoryEmbedding(
            id=record_id,
            user_story_id=story.get("user_story_id") or story.get("usid", "unknown"),
            title=story.get("title", "Untitled"),
            user_story_text=story_text,
            acceptance_criteria=story.get("acceptance_criteria") or story.get("acceptanceCriteria"),
            description=story.get("description") or story.get("Description/Note"),
            requirement_id=story.get("requirement_id"),
            requirement_text=requirement_text,
            tags=story.get("tags") or story.get("Tags/Labels"),
            priority=story.get("priority"),
            tshirt_size=story.get("tshirt_size"),
            confidence_score=story.get("confidence_score") or story.get("confidence"),
            source_agent=source_agent,
            embedding=embedding,
            was_edited=story.get("was_edited", False),
        )

        session.add(record)
        session.commit()
        logger.info(f"[vector_store] Stored story {record.user_story_id} (id={record_id})")
        return record_id

    except Exception as e:
        session.rollback()
        logger.error(f"[vector_store] Failed to store story: {e}")
        return None
    finally:
        if own_session:
            session.close()


def store_user_stories_batch(
    stories: List[dict],
    embeddings: List[List[float]],
    source_agent: str = "unknown",
    requirement_texts: dict = None,
    session=None
) -> List[str]:
    """
    Batch insert multiple stories + embeddings.

    Args:
        stories: List of user story dicts.
        embeddings: List of embedding vectors (same order as stories).
        source_agent: Which agent produced these stories.
        requirement_texts: Dict mapping requirement_id -> requirement_text.
        session: Optional SQLAlchemy session.

    Returns:
        List of database record IDs for successfully inserted stories.
    """
    if not stories or not embeddings:
        return []

    req_texts = requirement_texts or {}
    ids = []

    for story, embedding in zip(stories, embeddings):
        if embedding is None:
            logger.warning(f"[vector_store] Skipping story with None embedding: {story.get('title', 'unknown')}")
            continue

        req_text = req_texts.get(story.get("requirement_id"))
        record_id = store_user_story(
            story=story,
            embedding=embedding,
            source_agent=source_agent,
            requirement_text=req_text,
            session=session,
        )
        if record_id:
            ids.append(record_id)

    return ids


def search_similar_stories(
    query_embedding: List[float],
    k: int = 5,
    similarity_threshold: float = 0.70,
    tag_filter: List[str] = None,
    session=None
) -> List[dict]:
    """
    Find the k most similar user stories using cosine distance.

    Uses pgvector's <=> operator for cosine distance.
    Cosine similarity = 1 - cosine_distance.

    Args:
        query_embedding: The query vector (768 floats).
        k: Maximum number of results.
        similarity_threshold: Minimum cosine similarity (0.0 - 1.0).
        tag_filter: Optional list of tags to filter by (array overlap).
        session: Optional SQLAlchemy session.

    Returns:
        List of dicts, each containing story fields + similarity_score.
        Ordered by similarity descending (most similar first).
    """
    own_session = session is None
    if own_session:
        session = SessionLocal()

    try:
        # Build the similarity expression
        # pgvector <=> returns cosine distance, similarity = 1 - distance
        distance = UserStoryEmbedding.embedding.cosine_distance(query_embedding)
        similarity = (1 - distance).label("similarity")

        query = session.query(
            UserStoryEmbedding,
            similarity,
        ).filter(
            (1 - distance) >= similarity_threshold
        )

        # Optional tag filter: PostgreSQL array overlap operator &&
        if tag_filter:
            query = query.filter(
                UserStoryEmbedding.tags.overlap(tag_filter)
            )

        query = query.order_by(distance.asc()).limit(k)

        results = []
        for record, sim_score in query.all():
            results.append({
                "user_story_id": record.user_story_id,
                "title": record.title,
                "user_story_text": record.user_story_text,
                "acceptance_criteria": record.acceptance_criteria,
                "description": record.description,
                "requirement_id": record.requirement_id,
                "requirement_text": record.requirement_text,
                "tags": record.tags,
                "priority": record.priority,
                "tshirt_size": record.tshirt_size,
                "confidence_score": record.confidence_score,
                "was_edited": record.was_edited,
                "similarity_score": float(sim_score),
            })

        logger.info(f"[vector_store] Found {len(results)} similar stories (threshold={similarity_threshold})")
        return results

    except Exception as e:
        logger.error(f"[vector_store] Search failed: {e}")
        return []
    finally:
        if own_session:
            session.close()


def get_story_count(session=None) -> int:
    """Return total number of stored user story embeddings."""
    own_session = session is None
    if own_session:
        session = SessionLocal()
    try:
        count = session.query(func.count(UserStoryEmbedding.id)).scalar()
        return count or 0
    except Exception as e:
        logger.error(f"[vector_store] Count failed: {e}")
        return 0
    finally:
        if own_session:
            session.close()


def delete_stories_by_source(source_agent: str, session=None) -> int:
    """Remove all stories from a specific source agent. Returns count deleted."""
    own_session = session is None
    if own_session:
        session = SessionLocal()
    try:
        count = session.query(UserStoryEmbedding).filter(
            UserStoryEmbedding.source_agent == source_agent
        ).delete()
        session.commit()
        logger.info(f"[vector_store] Deleted {count} stories from source: {source_agent}")
        return count
    except Exception as e:
        session.rollback()
        logger.error(f"[vector_store] Delete failed: {e}")
        return 0
    finally:
        if own_session:
            session.close()
```

**Key nuances:**
- `store_user_story` performs deduplication by checking `user_story_text` exact match before inserting
- Handles all 3 agent output schemas (different field names for the same concept)
- `search_similar_stories` uses `UserStoryEmbedding.embedding.cosine_distance()` from pgvector
- All functions manage their own sessions if none is provided (via `SessionLocal()`)
- All functions wrap operations in try/except with rollback on failure

---

## Step 8: Create `tools/rag_utils.py` (New File)

**File:** `ClarifAI/tools/rag_utils.py` (new)

**Action:** Create this file:

```python
# tools/rag_utils.py
"""
RAG orchestration layer.
Glues embedding_utils, vector_store, and prompt augmentation together.
"""
import os
import json
import logging
from typing import List, Dict, Optional

from tools.embedding_utils import compose_embedding_text, generate_embedding, generate_embeddings_batch
from tools.vector_store import search_similar_stories, store_user_stories_batch, get_story_count

from utils.logger import get_logger

logger = get_logger()

# --- Configuration from environment ---
RAG_ENABLED = os.getenv("RAG_ENABLED", "true").lower() == "true"
RAG_MIN_STORIES = int(os.getenv("RAG_MIN_STORIES_FOR_RETRIEVAL", "10"))
RAG_RETRIEVAL_K = int(os.getenv("RAG_RETRIEVAL_K", "5"))
RAG_SIMILARITY_THRESHOLD = float(os.getenv("RAG_SIMILARITY_THRESHOLD", "0.70"))
RAG_MAX_EXAMPLES = int(os.getenv("RAG_MAX_EXAMPLES", "3"))


def retrieve_similar_examples(
    requirement_text: str,
    k: int = None,
    threshold: float = None,
    tag_filter: List[str] = None,
) -> List[dict]:
    """
    RETRIEVAL step: Embed the requirement text and search for similar past stories.

    Returns empty list if:
    - RAG is disabled
    - Vector store has fewer than RAG_MIN_STORIES entries
    - No stories above similarity threshold

    Args:
        requirement_text: The requirement(s) text to search against.
        k: Override for number of candidates (default: RAG_RETRIEVAL_K).
        threshold: Override for similarity threshold (default: RAG_SIMILARITY_THRESHOLD).
        tag_filter: Optional tag list for metadata filtering.

    Returns:
        List of similar story dicts with similarity_score field.
    """
    if not RAG_ENABLED:
        return []

    # Cold start check
    story_count = get_story_count()
    if story_count < RAG_MIN_STORIES:
        logger.info(f"[rag_utils] Cold start: only {story_count}/{RAG_MIN_STORIES} stories in store. Skipping retrieval.")
        return []

    k = k or RAG_RETRIEVAL_K
    threshold = threshold or RAG_SIMILARITY_THRESHOLD

    try:
        # Embed the requirement text as the search query
        query_embedding = generate_embedding(requirement_text)

        # Search the vector store
        results = search_similar_stories(
            query_embedding=query_embedding,
            k=k,
            similarity_threshold=threshold,
            tag_filter=tag_filter,
        )

        logger.info(f"[rag_utils] Retrieved {len(results)} similar examples for query: {requirement_text[:100]}...")
        return results

    except Exception as e:
        logger.warning(f"[rag_utils] Retrieval failed (non-blocking): {e}")
        return []


def format_examples_for_prompt(examples: List[dict], max_examples: int = None) -> str:
    """
    AUGMENTATION step: Format retrieved stories into a prompt-ready string.

    Produces a block of text that can be injected into the LLM prompt
    between the system instructions and the input requirements.

    Args:
        examples: List of story dicts from retrieve_similar_examples().
        max_examples: Maximum examples to include (default: RAG_MAX_EXAMPLES).

    Returns:
        Formatted string ready for prompt injection, or empty string if no examples.
    """
    if not examples:
        return ""

    max_ex = max_examples or RAG_MAX_EXAMPLES
    top_examples = examples[:max_ex]

    lines = [
        "Below are high-quality user stories previously generated for similar requirements.",
        "Use these as reference for style, detail level, and acceptance criteria quality.",
        "Do NOT copy these stories -- generate original content for the new requirements.",
        "",
    ]

    for i, ex in enumerate(top_examples, 1):
        sim = ex.get("similarity_score", 0.0)
        lines.append(f"--- Reference Example {i} (relevance: {sim:.2f}) ---")

        if ex.get("requirement_text"):
            lines.append(f'Original Requirement: "{ex["requirement_text"]}"')

        # Format the story as JSON for the LLM to see the exact output structure
        story_json = {
            "user_story_id": ex.get("user_story_id", ""),
            "title": ex.get("title", ""),
            "user_story": ex.get("user_story_text", ""),
            "description": ex.get("description", ""),
            "acceptance_criteria": ex.get("acceptance_criteria", []),
            "tags": ex.get("tags", []),
            "tshirt_size": ex.get("tshirt_size", ""),
            "priority": ex.get("priority", ""),
            "confidence_score": ex.get("confidence_score", 0.0),
        }
        lines.append(f"Generated User Story:")
        lines.append(json.dumps(story_json, indent=4))
        lines.append("")

    lines.append("Now generate user stories for the following NEW requirements:")
    lines.append("")

    return "\n".join(lines)


def store_generated_stories(
    stories: List[dict],
    source_agent: str = "unknown",
    requirement_texts: dict = None,
) -> int:
    """
    INSERTION step: Embed and store generated user stories into the vector store.

    Called after any agent successfully generates user stories.
    Non-blocking: logs warnings on failure but never raises.

    Args:
        stories: List of generated user story dicts.
        source_agent: Name of the agent that produced these stories.
        requirement_texts: Optional dict of {requirement_id: requirement_text} for cross-reference.

    Returns:
        Count of stories successfully stored.
    """
    if not RAG_ENABLED or not stories:
        return 0

    try:
        # Step 1: Compose embedding text for each story
        texts = [compose_embedding_text(s) for s in stories]

        # Step 2: Batch embed
        embeddings = generate_embeddings_batch(texts)

        # Step 3: Batch store (deduplication happens inside store_user_story)
        ids = store_user_stories_batch(
            stories=stories,
            embeddings=embeddings,
            source_agent=source_agent,
            requirement_texts=requirement_texts,
        )

        logger.info(f"[rag_utils] Stored {len(ids)}/{len(stories)} stories from {source_agent}")
        return len(ids)

    except Exception as e:
        logger.warning(f"[rag_utils] Store failed (non-blocking): {e}")
        return 0
```

**Key nuances:**
- `RAG_ENABLED` is the master kill switch -- if `false`, all functions return empty/zero immediately
- `retrieve_similar_examples` checks `get_story_count() < RAG_MIN_STORIES` for cold start protection
- `format_examples_for_prompt` outputs the exact format shown in RAG.md Section 6, including similarity scores and JSON structure
- `store_generated_stories` chains: `compose_embedding_text` -> `generate_embeddings_batch` -> `store_user_stories_batch`
- Every function is non-blocking: catches all exceptions and returns safe defaults

---

## Step 9: Modify `agents/user_story_agent.py`

**File:** `ClarifAI/agents/user_story_agent.py`
**Current state:** 173 lines

### 9a. Add imports (after line 5)

**Current line 5:**
```python
from tools.prompt_utils import extract_clean_json
```

**Insert after line 5:**
```python
from tools.rag_utils import retrieve_similar_examples, format_examples_for_prompt, store_generated_stories, RAG_ENABLED
```

### 9b. Add RAG retrieval (after line 22, before line 24)

**Current lines 19-24:**
```python
        ]

        if not functional_reqs:
            return {"user_stories": []}

        # Step 2: Build prompt
```

**Insert between `return {"user_stories": []}` and `# Step 2: Build prompt`:**
```python

        # Step 1.5: RAG - Retrieve similar past stories as few-shot examples
        rag_examples_text = ""
        if RAG_ENABLED:
            try:
                all_req_texts = " ".join([r["requirement_text"] for r in functional_reqs])
                similar = retrieve_similar_examples(all_req_texts, tag_filter=None)
                if similar:
                    rag_examples_text = format_examples_for_prompt(similar)
            except Exception as e:
                logging.warning(f"[UserStoryAgent] RAG retrieval failed (non-blocking): {e}")

```

### 9c. Inject examples into the prompt (modify the prompt string)

**Current lines 155-162 (end of prompt, before `.strip()`):**
```python
        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        Requirements:
        {formatted}
        """.strip()
```

**Replace with:**
```python
        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        {rag_examples_text}
        Requirements:
        {formatted}
        """.strip()
```

**What this does:** When `rag_examples_text` is empty (no RAG results or RAG disabled), the prompt is identical to before. When it has content, the few-shot examples appear right before "Requirements:" -- exactly where RAG.md Section 6 specifies.

### 9d. Add RAG insertion (after line 167, before the return)

**Current lines 167-172:**
```python
            parsed = extract_clean_json(llm_response)
        except Exception as e:
            logging.error(f"Failed to parse LLM response: {e}, raw: {llm_response[:500]}")
            parsed = []

        return {"user_stories": parsed}
```

**Replace with:**
```python
            parsed = extract_clean_json(llm_response)
        except Exception as e:
            logging.error(f"Failed to parse LLM response: {e}, raw: {llm_response[:500]}")
            parsed = []

        # Step 4: RAG - Store generated stories for future retrieval
        if RAG_ENABLED and parsed:
            try:
                req_texts = {r["requirement_id"]: r["requirement_text"] for r in functional_reqs}
                store_generated_stories(parsed, source_agent="UserStoryAgent", requirement_texts=req_texts)
            except Exception as e:
                logging.warning(f"[UserStoryAgent] RAG storage failed (non-blocking): {e}")

        return {"user_stories": parsed}
```

---

## Step 10: Modify `agents/requirement_user_story_agent.py`

**File:** `ClarifAI/agents/requirement_user_story_agent.py`
**Current state:** 113 lines

### 10a. Add imports (after line 4)

**Current line 4:**
```python
from tools.prompt_utils import extract_clean_json
```

**Insert after line 4:**
```python
from tools.rag_utils import retrieve_similar_examples, format_examples_for_prompt, store_generated_stories, RAG_ENABLED
```

### 10b. Add RAG retrieval (after line 37, before the prompt string at line 38)

**Current lines 36-38:**
```python
            combined_info = raw_info
        prompt = f"""
You are an expert software analyst assistant...
```

**Insert between `combined_info = raw_info` and `prompt = f"""` :**
```python

        # RAG: Retrieve similar past stories as few-shot examples
        rag_examples_text = ""
        if RAG_ENABLED:
            try:
                search_query = combined_info[:500]  # First 500 chars as search query
                similar = retrieve_similar_examples(search_query, tag_filter=None)
                if similar:
                    rag_examples_text = format_examples_for_prompt(similar)
            except Exception as e:
                logging.warning(f"[RequirementUserStoryAgent] RAG retrieval failed: {e}")

```

### 10c. Inject examples into the prompt

**Current lines 98-103 (end of prompt, before Input section):**
```python
Input:

{combined_info}
""".strip()
```

**Replace with:**
```python
{rag_examples_text}
Input:

{combined_info}
""".strip()
```

### 10d. Add RAG insertion (after line 108, before the return at line 113)

**Current lines 108-113:**
```python
            parsed = extract_clean_json(llm_response)
        except Exception as e:
            logging.error(f"Failed to parse LLM response: {e}, raw: {llm_response[:500]}")
            parsed = []

        return {"user_stories": parsed}
```

**Replace with:**
```python
            parsed = extract_clean_json(llm_response)
        except Exception as e:
            logging.error(f"Failed to parse LLM response: {e}, raw: {llm_response[:500]}")
            parsed = []

        # RAG: Store generated stories for future retrieval
        if RAG_ENABLED and parsed:
            try:
                store_generated_stories(parsed, source_agent="RequirementUserStoryAgent")
            except Exception as e:
                logging.warning(f"[RequirementUserStoryAgent] RAG storage failed: {e}")

        return {"user_stories": parsed}
```

---

## Step 11: Modify `agents/user_story_feedback_agent.py`

**File:** `ClarifAI/agents/user_story_feedback_agent.py`
**Current state:** 81 lines

### 11a. Add imports (after line 4)

**Current line 4:**
```python
from tools.prompt_utils import extract_clean_json
```

**Insert after line 4:**
```python
from tools.rag_utils import store_generated_stories, RAG_ENABLED
```

### 11b. Add RAG insertion for edited stories (after line 80, the return)

**Current line 80:**
```python
        return {"updated_story": updated or story}
```

**Replace with:**
```python
        # RAG: Store feedback-edited stories as higher quality signals
        if RAG_ENABLED and updated:
            try:
                updated_with_flag = dict(updated)
                updated_with_flag["was_edited"] = True
                store_generated_stories([updated_with_flag], source_agent="UserStoryFeedbackAgent")
            except Exception:
                pass  # Silent failure - feedback flow must not be affected

        return {"updated_story": updated or story}
```

**Key nuance:** We create a copy of `updated` with `was_edited=True` set. Stories marked `was_edited=True` in the vector store are treated as higher-quality signals during retrieval.

---

## Step 12: Modify `main.py` (CLI entry point)

**File:** `ClarifAI/main.py`
**Current state:** 67 lines

### 12a. Add RAG storage after user story generation

**Current lines 52-55:**
```python
    user_stories = agent.run(validated)

    if user_stories.get("user_stories"):
        jira_utils.post_user_stories_to_jira(user_stories["user_stories"])
```

**Replace with:**
```python
    user_stories = agent.run(validated)

    # RAG: Store generated stories in vector store
    if user_stories.get("user_stories"):
        try:
            from tools.rag_utils import store_generated_stories, RAG_ENABLED
            if RAG_ENABLED:
                req_texts = {r["requirement_id"]: r["requirement_text"] for r in extracted}
                store_generated_stories(
                    user_stories["user_stories"],
                    source_agent="CLI-UserStoryAgent",
                    requirement_texts=req_texts,
                )
        except Exception as e:
            print(f"RAG storage skipped: {e}")

        jira_utils.post_user_stories_to_jira(user_stories["user_stories"])
```

---

## Step 13: Add RAG API Endpoints

**File:** `ClarifAI/api/endpoints/requirements.py`
**Current state:** 523 lines

### 13a. Add imports at the top (after existing imports around line 25)

**Insert after the existing import block:**
```python
from tools.rag_utils import retrieve_similar_examples, store_generated_stories, RAG_ENABLED
from tools.vector_store import get_story_count
```

### 13b. Add endpoints at the bottom of the file (after line 523)

**Append to the end of the file:**

```python
###########################################################################
# RAG Endpoints
###########################################################################

class RAGSearchRequest(BaseModel):
    query: str
    k: int = 5
    threshold: float = 0.70
    tags: Optional[List[str]] = None


@router.post("/rag/search")
async def rag_search_stories(request: RAGSearchRequest):
    """Semantic search for similar past user stories in the RAG vector store."""
    if not RAG_ENABLED:
        return {"similar_stories": [], "count": 0, "message": "RAG is disabled"}

    results = retrieve_similar_examples(
        request.query,
        k=request.k,
        threshold=request.threshold,
        tag_filter=request.tags,
    )
    return {"similar_stories": results, "count": len(results)}


@router.get("/rag/stats")
async def rag_stats():
    """Get RAG vector store statistics."""
    count = get_story_count()
    return {
        "total_stories_in_vector_store": count,
        "rag_enabled": RAG_ENABLED,
    }


class RAGSeedRequest(BaseModel):
    user_stories: List[Dict[str, Any]]


@router.post("/rag/seed")
async def rag_seed(request: RAGSeedRequest):
    """
    Bulk-import historical user stories into the RAG vector store.
    Use this to bootstrap the knowledge base with data from past runs.
    """
    if not RAG_ENABLED:
        raise HTTPException(status_code=400, detail="RAG is disabled")

    count = store_generated_stories(
        request.user_stories,
        source_agent="RAG-Seed",
    )
    return {"stored_count": count, "total_submitted": len(request.user_stories)}
```

---

## Step 14: Create HNSW Index (After First Data Load)

Once there are stories in the vector store (after running the pipeline at least once), create the HNSW index for fast cosine similarity search:

```sql
CREATE INDEX idx_story_embedding_cosine
    ON clarifai_user_story_embeddings
    USING hnsw (embedding vector_cosine_ops);
```

> Do NOT create this index on an empty table. HNSW indexes are built from existing data. Create it after seeding or after the first pipeline run.

---

## Verification Checklist

### Phase 1: Foundation Verification

```bash
# 1. Check pgvector extension
psql -d clarifai_system -c "SELECT * FROM pg_extension WHERE extname = 'vector';"

# 2. Check table was created
psql -d clarifai_system -c "\d clarifai_user_story_embeddings"

# 3. Test embedding generation
python -c "
from tools.embedding_utils import generate_embedding, compose_embedding_text
sample = {'title': 'Login via OTP', 'user_story': 'As a user I want to login via OTP', 'tags': ['auth']}
text = compose_embedding_text(sample)
emb = generate_embedding(text)
print(f'Embedding dimensions: {len(emb)}')  # Should print 768
print(f'First 5 values: {emb[:5]}')
"
```

### Phase 2: Storage Verification

```python
python -c "
from tools.vector_store import store_user_story, search_similar_stories, get_story_count
from tools.embedding_utils import generate_embedding, compose_embedding_text

# Insert a test story
story = {
    'user_story_id': 'US-TEST-001',
    'title': 'Password Reset via Email',
    'user_story': 'As a user, I want to reset my password via email',
    'acceptance_criteria': ['Given a user clicks forgot password, Then a reset link is sent'],
    'tags': ['authentication', 'password'],
    'priority': 'High',
    'tshirt_size': 'M',
    'confidence_score': 0.9,
    'requirement_id': 'REQ-TEST'
}
text = compose_embedding_text(story)
emb = generate_embedding(text)
rid = store_user_story(story, emb, source_agent='test')
print(f'Stored with id: {rid}')

# Search for it
query_emb = generate_embedding('password recovery functionality')
results = search_similar_stories(query_emb, k=3, similarity_threshold=0.5)
print(f'Found {len(results)} results')
for r in results:
    print(f'  {r[\"title\"]} (similarity: {r[\"similarity_score\"]:.3f})')

print(f'Total count: {get_story_count()}')
"
```

### Phase 3: Full Cycle Verification

```bash
# Run the CLI pipeline
python main.py

# Check RAG stats via API
curl http://localhost:8000/rag/stats

# Search via API
curl -X POST http://localhost:8000/rag/search \
  -H "Content-Type: application/json" \
  -d '{"query": "user authentication login", "k": 3}'

# Run the pipeline again -- this time RAG examples should appear in prompts
# (Check logs for "[rag_utils] Retrieved X similar examples")
python main.py
```

### Verification Signals

| What to check | Expected result |
|---------------|-----------------|
| `/rag/stats` | `total_stories_in_vector_store` > 0 after first pipeline run |
| Logs after 2nd run | `[rag_utils] Retrieved N similar examples for query:...` |
| `/rag/search` with query | Returns stories with `similarity_score` values |
| Pipeline with `RAG_ENABLED=false` | Runs identically to before (no RAG behavior) |
| Streamlit UI | Works without any code changes (RAG is inside the agent) |

---

## Troubleshooting

| Issue | Cause | Fix |
|-------|-------|-----|
| `ModuleNotFoundError: pgvector` | Package not installed | `pip install pgvector` |
| `extension "vector" is not available` | pgvector not installed on PostgreSQL server | Install pgvector PostgreSQL extension (OS-level) |
| `column "embedding" is of type vector but expression is of type text` | pgvector type not registered | Check `db.py` has `_register_pgvector` event listener |
| `RAG retrieval returns empty` on 2nd run | Fewer than 10 stories in store | Lower `RAG_MIN_STORIES_FOR_RETRIEVAL` in `.env` or seed data via `/rag/seed` |
| `generate_embedding` fails with 429 | Gemini rate limit | Retry logic handles this (3 attempts). If persistent, add delay between pipeline stages |
| Stories not appearing in prompt | `rag_examples_text` is empty | Check logs for cold start message or retrieval errors |
| Streamlit UI errors | Import path issue | Ensure `tools/rag_utils.py` imports work from the Streamlit working directory |

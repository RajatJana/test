# tools/vector_store.py
"""
pgvector CRUD operations for user story embeddings.
Uses the existing SessionLocal from db.py and UserStoryEmbedding from models.py.
"""
import uuid
import logging
from typing import List, Dict, Optional

from sqlalchemy import text, func
from db import SessionLocal
from models import UserStoryEmbedding

from utils.logger import get_logger

logger = get_logger()


def store_user_story(
    story: dict,
    embedding: List[float],
    source_agent: str = "unknown",
    requirement_text: str = None,
    session=None
) -> Optional[str]:
    """
    Insert a single user story + embedding into the vector store.

    Args:
        story: User story dict (from any agent output).
        embedding: The embedding vector (768 floats).
        source_agent: Which agent produced this story.
        requirement_text: The original requirement text (for display during retrieval).
        session: Optional SQLAlchemy session. Creates one if not provided.

    Returns:
        The database record ID, or None if insertion failed.
    """
    own_session = session is None
    if own_session:
        session = SessionLocal()

    try:
        # Extract fields handling both agent schemas
        story_text = story.get("user_story") or story.get("story", "")

        # Deduplication: skip if exact text already exists
        existing = session.query(UserStoryEmbedding).filter(
            UserStoryEmbedding.user_story_text == story_text
        ).first()

        if existing:
            logger.info(f"[vector_store] Duplicate story skipped: {story_text[:80]}...")
            return existing.id

        record_id = uuid.uuid4().hex
        record = UserStoryEmbedding(
            id=record_id,
            user_story_id=story.get("user_story_id") or story.get("usid", "unknown"),
            title=story.get("title", "Untitled"),
            user_story_text=story_text,
            acceptance_criteria=story.get("acceptance_criteria") or story.get("acceptanceCriteria"),
            description=story.get("description") or story.get("Description/Note"),
            requirement_id=story.get("requirement_id"),
            requirement_text=requirement_text,
            tags=story.get("tags") or story.get("Tags/Labels"),
            priority=story.get("priority"),
            tshirt_size=story.get("tshirt_size"),
            confidence_score=story.get("confidence_score") or story.get("confidence"),
            source_agent=source_agent,
            embedding=embedding,
            was_edited=story.get("was_edited", False),
        )

        session.add(record)
        session.commit()
        logger.info(f"[vector_store] Stored story {record.user_story_id} (id={record_id})")
        return record_id

    except Exception as e:
        session.rollback()
        logger.error(f"[vector_store] Failed to store story: {e}")
        return None
    finally:
        if own_session:
            session.close()


def store_user_stories_batch(
    stories: List[dict],
    embeddings: List[List[float]],
    source_agent: str = "unknown",
    requirement_texts: dict = None,
    session=None
) -> List[str]:
    """
    Batch insert multiple stories + embeddings.

    Args:
        stories: List of user story dicts.
        embeddings: List of embedding vectors (same order as stories).
        source_agent: Which agent produced these stories.
        requirement_texts: Dict mapping requirement_id -> requirement_text.
        session: Optional SQLAlchemy session.

    Returns:
        List of database record IDs for successfully inserted stories.
    """
    if not stories or not embeddings:
        return []

    req_texts = requirement_texts or {}
    ids = []

    for story, embedding in zip(stories, embeddings):
        if embedding is None:
            logger.warning(f"[vector_store] Skipping story with None embedding: {story.get('title', 'unknown')}")
            continue

        req_text = req_texts.get(story.get("requirement_id"))
        record_id = store_user_story(
            story=story,
            embedding=embedding,
            source_agent=source_agent,
            requirement_text=req_text,
            session=session,
        )
        if record_id:
            ids.append(record_id)

    return ids


def search_similar_stories(
    query_embedding: List[float],
    k: int = 5,
    similarity_threshold: float = 0.70,
    tag_filter: List[str] = None,
    session=None
) -> List[dict]:
    """
    Find the k most similar user stories using cosine distance.

    Uses pgvector's <=> operator for cosine distance.
    Cosine similarity = 1 - cosine_distance.

    Args:
        query_embedding: The query vector (768 floats).
        k: Maximum number of results.
        similarity_threshold: Minimum cosine similarity (0.0 - 1.0).
        tag_filter: Optional list of tags to filter by (array overlap).
        session: Optional SQLAlchemy session.

    Returns:
        List of dicts, each containing story fields + similarity_score.
        Ordered by similarity descending (most similar first).
    """
    own_session = session is None
    if own_session:
        session = SessionLocal()

    try:
        # Build the similarity expression
        # pgvector <=> returns cosine distance, similarity = 1 - distance
        distance = UserStoryEmbedding.embedding.cosine_distance(query_embedding)
        similarity = (1 - distance).label("similarity")

        query = session.query(
            UserStoryEmbedding,
            similarity,
        ).filter(
            (1 - distance) >= similarity_threshold
        )

        # Optional tag filter: PostgreSQL array overlap operator &&
        if tag_filter:
            query = query.filter(
                UserStoryEmbedding.tags.overlap(tag_filter)
            )

        query = query.order_by(distance.asc()).limit(k)

        results = []
        for record, sim_score in query.all():
            results.append({
                "user_story_id": record.user_story_id,
                "title": record.title,
                "user_story_text": record.user_story_text,
                "acceptance_criteria": record.acceptance_criteria,
                "description": record.description,
                "requirement_id": record.requirement_id,
                "requirement_text": record.requirement_text,
                "tags": record.tags,
                "priority": record.priority,
                "tshirt_size": record.tshirt_size,
                "confidence_score": record.confidence_score,
                "was_edited": record.was_edited,
                "similarity_score": float(sim_score),
            })

        logger.info(f"[vector_store] Found {len(results)} similar stories (threshold={similarity_threshold})")
        return results

    except Exception as e:
        logger.error(f"[vector_store] Search failed: {e}")
        return []
    finally:
        if own_session:
            session.close()


def get_story_count(session=None) -> int:
    """Return total number of stored user story embeddings."""
    own_session = session is None
    if own_session:
        session = SessionLocal()
    try:
        count = session.query(func.count(UserStoryEmbedding.id)).scalar()
        return count or 0
    except Exception as e:
        logger.error(f"[vector_store] Count failed: {e}")
        return 0
    finally:
        if own_session:
            session.close()


def delete_stories_by_source(source_agent: str, session=None) -> int:
    """Remove all stories from a specific source agent. Returns count deleted."""
    own_session = session is None
    if own_session:
        session = SessionLocal()
    try:
        count = session.query(UserStoryEmbedding).filter(
            UserStoryEmbedding.source_agent == source_agent
        ).delete()
        session.commit()
        logger.info(f"[vector_store] Deleted {count} stories from source: {source_agent}")
        return count
    except Exception as e:
        session.rollback()
        logger.error(f"[vector_store] Delete failed: {e}")
        return 0
    finally:
        if own_session:
            session.close()

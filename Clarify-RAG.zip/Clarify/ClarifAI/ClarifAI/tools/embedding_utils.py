# tools/embedding_utils.py
"""
Embedding generation utilities using Gemini gemini-embedding-001.
Uses the google.genai SDK (same pattern as agents/image_extractor_agent.py line 7).
"""
import os
import time
import logging
from typing import List, Optional

from google import genai
from google.genai import types

from utils.logger import get_logger

logger = get_logger()

# Configuration from environment
EMBEDDING_MODEL = os.getenv("RAG_EMBEDDING_MODEL", "gemini-embedding-001")
EMBEDDING_DIMENSIONS = int(os.getenv("RAG_EMBEDDING_DIMENSIONS", "768"))
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "YOUR_GEMINI_API_KEY")


def compose_embedding_text(story: dict) -> str:
    """
    Build the composite text to embed from a user story dict.

    Handles both output schemas:
    - UserStoryAgent: uses "user_story", "acceptance_criteria", "tags"
    - RequirementUserStoryAgent: uses "story", "acceptanceCriteria", "Tags/Labels"
    - UserStoryFeedbackAgent: uses "story", "acceptanceCriteria", "tags"
    """
    parts = []

    if story.get("title"):
        parts.append(f"Title: {story['title']}")

    # Handle both agent output key names
    story_text = story.get("user_story") or story.get("story", "")
    if story_text:
        parts.append(f"Story: {story_text}")

    criteria = story.get("acceptance_criteria") or story.get("acceptanceCriteria") or []
    if criteria:
        parts.append("Acceptance Criteria:")
        for c in criteria:
            parts.append(f"- {c}")

    tags = story.get("tags") or story.get("Tags/Labels") or []
    if tags:
        if isinstance(tags, list):
            parts.append(f"Tags: {', '.join(str(t) for t in tags)}")
        else:
            parts.append(f"Tags: {tags}")

    return "\n".join(parts)


def generate_embedding(text: str, api_key: str = None, dimensions: int = None) -> List[float]:
    """
    Generate a single embedding vector using Gemini embedding API.

    Args:
        text: The text to embed.
        api_key: Optional API key override.
        dimensions: Optional dimension override (default: 768).

    Returns:
        List of floats (the embedding vector).

    Raises:
        Exception if all retry attempts fail.
    """
    key = api_key or GEMINI_API_KEY
    dims = dimensions or EMBEDDING_DIMENSIONS

    client = genai.Client(api_key=key)

    for attempt in range(3):
        try:
            result = client.models.embed_content(
                model=EMBEDDING_MODEL,
                contents=text,
                config=types.EmbedContentConfig(
                    output_dimensionality=dims,
                ),
            )
            return result.embeddings[0].values
        except Exception as e:
            wait = 2 ** attempt  # 1s, 2s, 4s
            logger.warning(f"[embedding_utils] Attempt {attempt + 1}/3 failed: {e}. Retrying in {wait}s...")
            time.sleep(wait)

    raise Exception(f"Failed to generate embedding after 3 attempts for text: {text[:100]}...")


def generate_embeddings_batch(texts: List[str], api_key: str = None, dimensions: int = None) -> List[List[float]]:
    """
    Batch embed multiple texts.

    Tries batch API first. Falls back to individual calls if batch fails.

    Args:
        texts: List of strings to embed.
        api_key: Optional API key override.
        dimensions: Optional dimension override.

    Returns:
        List of embedding vectors (same order as input texts).
    """
    if not texts:
        return []

    key = api_key or GEMINI_API_KEY
    dims = dimensions or EMBEDDING_DIMENSIONS

    # Try batch call
    try:
        client = genai.Client(api_key=key)
        result = client.models.embed_content(
            model=EMBEDDING_MODEL,
            contents=texts,
            config=types.EmbedContentConfig(
                output_dimensionality=dims,
            ),
        )
        return [emb.values for emb in result.embeddings]
    except Exception as e:
        logger.warning(f"[embedding_utils] Batch embed failed: {e}. Falling back to individual calls.")

    # Fallback: embed one by one
    embeddings = []
    for text in texts:
        try:
            emb = generate_embedding(text, api_key=key, dimensions=dims)
            embeddings.append(emb)
        except Exception as e:
            logger.error(f"[embedding_utils] Failed to embed text: {e}. Skipping.")
            embeddings.append(None)

    return embeddings

# tools/rag_utils.py
"""
RAG orchestration layer.
Glues embedding_utils, vector_store, and prompt augmentation together.
"""
import os
import json
import logging
from typing import List, Dict, Optional

from tools.embedding_utils import compose_embedding_text, generate_embedding, generate_embeddings_batch
from tools.vector_store import search_similar_stories, store_user_stories_batch, get_story_count

from utils.logger import get_logger

logger = get_logger()

# --- Configuration from environment ---
RAG_ENABLED = os.getenv("RAG_ENABLED", "true").lower() == "true"
RAG_MIN_STORIES = int(os.getenv("RAG_MIN_STORIES_FOR_RETRIEVAL", "10"))
RAG_RETRIEVAL_K = int(os.getenv("RAG_RETRIEVAL_K", "5"))
RAG_SIMILARITY_THRESHOLD = float(os.getenv("RAG_SIMILARITY_THRESHOLD", "0.70"))
RAG_MAX_EXAMPLES = int(os.getenv("RAG_MAX_EXAMPLES", "3"))


def retrieve_similar_examples(
    requirement_text: str,
    k: int = None,
    threshold: float = None,
    tag_filter: List[str] = None,
) -> List[dict]:
    """
    RETRIEVAL step: Embed the requirement text and search for similar past stories.

    Returns empty list if:
    - RAG is disabled
    - Vector store has fewer than RAG_MIN_STORIES entries
    - No stories above similarity threshold

    Args:
        requirement_text: The requirement(s) text to search against.
        k: Override for number of candidates (default: RAG_RETRIEVAL_K).
        threshold: Override for similarity threshold (default: RAG_SIMILARITY_THRESHOLD).
        tag_filter: Optional tag list for metadata filtering.

    Returns:
        List of similar story dicts with similarity_score field.
    """
    if not RAG_ENABLED:
        return []

    # Cold start check
    story_count = get_story_count()
    if story_count < RAG_MIN_STORIES:
        logger.info(f"[rag_utils] Cold start: only {story_count}/{RAG_MIN_STORIES} stories in store. Skipping retrieval.")
        return []

    k = k or RAG_RETRIEVAL_K
    threshold = threshold or RAG_SIMILARITY_THRESHOLD

    try:
        # Embed the requirement text as the search query
        query_embedding = generate_embedding(requirement_text)

        # Search the vector store
        results = search_similar_stories(
            query_embedding=query_embedding,
            k=k,
            similarity_threshold=threshold,
            tag_filter=tag_filter,
        )

        logger.info(f"[rag_utils] Retrieved {len(results)} similar examples for query: {requirement_text[:100]}...")
        return results

    except Exception as e:
        logger.warning(f"[rag_utils] Retrieval failed (non-blocking): {e}")
        return []


def format_examples_for_prompt(examples: List[dict], max_examples: int = None) -> str:
    """
    AUGMENTATION step: Format retrieved stories into a prompt-ready string.

    Produces a block of text that can be injected into the LLM prompt
    between the system instructions and the input requirements.

    Args:
        examples: List of story dicts from retrieve_similar_examples().
        max_examples: Maximum examples to include (default: RAG_MAX_EXAMPLES).

    Returns:
        Formatted string ready for prompt injection, or empty string if no examples.
    """
    if not examples:
        return ""

    max_ex = max_examples or RAG_MAX_EXAMPLES
    top_examples = examples[:max_ex]

    lines = [
        "Below are high-quality user stories previously generated for similar requirements.",
        "Use these as reference for style, detail level, and acceptance criteria quality.",
        "Do NOT copy these stories -- generate original content for the new requirements.",
        "",
    ]

    for i, ex in enumerate(top_examples, 1):
        sim = ex.get("similarity_score", 0.0)
        lines.append(f"--- Reference Example {i} (relevance: {sim:.2f}) ---")

        if ex.get("requirement_text"):
            lines.append(f'Original Requirement: "{ex["requirement_text"]}"')

        # Format the story as JSON for the LLM to see the exact output structure
        story_json = {
            "user_story_id": ex.get("user_story_id", ""),
            "title": ex.get("title", ""),
            "user_story": ex.get("user_story_text", ""),
            "description": ex.get("description", ""),
            "acceptance_criteria": ex.get("acceptance_criteria", []),
            "tags": ex.get("tags", []),
            "tshirt_size": ex.get("tshirt_size", ""),
            "priority": ex.get("priority", ""),
            "confidence_score": ex.get("confidence_score", 0.0),
        }
        lines.append(f"Generated User Story:")
        lines.append(json.dumps(story_json, indent=4))
        lines.append("")

    lines.append("Now generate user stories for the following NEW requirements:")
    lines.append("")

    return "\n".join(lines)


def store_generated_stories(
    stories: List[dict],
    source_agent: str = "unknown",
    requirement_texts: dict = None,
) -> int:
    """
    INSERTION step: Embed and store generated user stories into the vector store.

    Called after any agent successfully generates user stories.
    Non-blocking: logs warnings on failure but never raises.

    Args:
        stories: List of generated user story dicts.
        source_agent: Name of the agent that produced these stories.
        requirement_texts: Optional dict of {requirement_id: requirement_text} for cross-reference.

    Returns:
        Count of stories successfully stored.
    """
    if not RAG_ENABLED or not stories:
        return 0

    try:
        # Step 1: Compose embedding text for each story
        texts = [compose_embedding_text(s) for s in stories]

        # Step 2: Batch embed
        embeddings = generate_embeddings_batch(texts)

        # Step 3: Batch store (deduplication happens inside store_user_story)
        ids = store_user_stories_batch(
            stories=stories,
            embeddings=embeddings,
            source_agent=source_agent,
            requirement_texts=requirement_texts,
        )

        logger.info(f"[rag_utils] Stored {len(ids)}/{len(stories)} stories from {source_agent}")
        return len(ids)

    except Exception as e:
        logger.warning(f"[rag_utils] Store failed (non-blocking): {e}")
        return 0

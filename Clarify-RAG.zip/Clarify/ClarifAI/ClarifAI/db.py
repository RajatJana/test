# db.py
from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import sessionmaker

DATABASE_URL = "postgresql://postgres:YOURUSERNAME@localhost:5432/clarifai_system"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@event.listens_for(engine, "connect")
def _register_pgvector(dbapi_connection, connection_record):
    """Register pgvector types when a new database connection is established."""
    try:
        from pgvector.sqlalchemy import Vector  # noqa: F401 - triggers type registration
    except ImportError:
        pass


def init_vector_extension():
    """One-time utility: enable the pgvector extension in PostgreSQL."""
    with engine.connect() as conn:
        conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        conn.commit()

# logger.py or in main.py
import logging
import os
from logging.handlers import RotatingFileHandler

def get_logger(name="ClarifAI", log_to_console=True, log_to_file=True, level=logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(level)

    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    if log_to_console:
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

    if log_to_file:
        os.makedirs("logs", exist_ok=True)
        file_handler = RotatingFileHandler(
            f"logs/{name.lower()}.log", maxBytes=1_000_000, backupCount=3
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    logger.propagate = False  # Prevent duplicate logs
    return logger
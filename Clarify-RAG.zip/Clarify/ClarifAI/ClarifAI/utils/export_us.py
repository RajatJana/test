import json
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter

# 🔍 Recursively find lists of dicts
def find_lists_in_json(obj, path=""):
    """
    Recursively search a JSON-like object for lists of dictionaries.

    Args:
        obj: The JSON object (dict or list) to search.
        path: Current path in the JSON hierarchy.

    Returns:
        Dict mapping path strings to lists of dicts found.
    """
    found = {}
    if isinstance(obj, list) and all(isinstance(i, dict) for i in obj):
        found[path or "root_list"] = obj
    elif isinstance(obj, dict):
        for k, v in obj.items():
            new_path = f"{path}.{k}" if path else k
            found.update(find_lists_in_json(v, new_path))
    return found

# 🔄 Flatten nested dicts
def flatten_dict(d, parent_key="", sep="."):
    items = {}
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.update(flatten_dict(v, new_key, sep=sep))
        elif isinstance(v, list):
            items[new_key] = json.dumps(v, ensure_ascii=False)
        else:
            items[new_key] = v
    return items

# 🧠 Format JSON for Excel
def format_json(json_data, flatten=False):
    formatted = []
    for item in json_data:
        if flatten:
            item = flatten_dict(item)
        new_item = {}
        for k, v in item.items():
            if isinstance(v, list):
                # Bullet formatting for lists
                new_item[k] = '\n• ' + '\n• '.join(str(x) for x in v)
            elif isinstance(v, dict):
                new_item[k] = json.dumps(v, ensure_ascii=False, indent=2)
            else:
                new_item[k] = v
        formatted.append(new_item)
    return formatted

# 📊 Convert to Excel
def convert_to_excel(data):
    if not data:
        raise ValueError("No data provided")

    wb = Workbook()
    ws = wb.active
    ws.title = "User Stories"

    # Collect headers
    headers = []
    for item in data:
        for key in item.keys():
            if key not in headers:
                headers.append(key)
    ws.append(headers)

    # Add rows
    for item in data:
        row = []
        for h in headers:
            value = item.get(h, "")
            if isinstance(value, (list, dict)):
                value = json.dumps(value, ensure_ascii=False, indent=2)
            row.append(str(value) if value is not None else "")
        ws.append(row)

    # Adjust column widths
    for col_idx, header in enumerate(headers, 1):
        col_letter = get_column_letter(col_idx)
        max_length = 0
        for row in ws.iter_rows(min_row=1, max_row=ws.max_row,
                                min_col=col_idx, max_col=col_idx):
            cell = row[0]
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))
        ws.column_dimensions[col_letter].width = min(max_length + 2, 50)

    # Wrap text
    for row in ws.iter_rows():
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")

    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer

# 🚀 Main export function
def export_user_stories_to_excel(payload, flatten=False):
    """
    Convert a JSON payload of user stories to an Excel file.

    Args:
        payload: Dict with 'user_stories' key containing a list of dictionaries,
                 or a list of dictionaries directly.
        flatten: Whether to flatten nested dicts before export.

    Returns:
        Dict with status, file path (if saved), and any errors.
    """
    errors = []
    file_path = "UserStories.xlsx"

    try:
        # Extract list of user stories
        if isinstance(payload, dict):
            if "user_stories" in payload:
                json_data = payload["user_stories"]
            else:
                lists_found = find_lists_in_json(payload)
                if lists_found:
                    _, json_data = next(iter(lists_found.items()))
                else:
                    errors.append({"error": "No list of user stories found in payload."})
                    return {"status": "failed", "file_path": None, "errors": errors}
        elif isinstance(payload, list):
            json_data = payload
        else:
            errors.append({"error": "Invalid payload format. Expected a list or dict."})
            return {"status": "failed", "file_path": None, "errors": errors}

        if not json_data:
            errors.append({"error": "Empty user stories list."})
            return {"status": "failed", "file_path": None, "errors": errors}

        # Format JSON for Excel
        formatted_data = format_json(json_data, flatten=flatten)

        # Convert to Excel
        excel_buffer = convert_to_excel(formatted_data)

        # Save locally
        with open(file_path, "wb") as f:
            f.write(excel_buffer.read())

        return {"status": "success", "file_path": file_path, "errors": errors}

    except Exception as e:
        errors.append({"error": f"Failed to generate Excel file: {str(e)}"})
        return {"status": "failed", "file_path": None, "errors": errors}

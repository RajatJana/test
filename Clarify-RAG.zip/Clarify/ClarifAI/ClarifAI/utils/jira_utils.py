import requests
from requests.auth import HTTPBasicAuth
import json

JIRA_URL = "JIRA URL"
API_ENDPOINT = f"{JIRA_URL}/rest/api/2/issue/bulk"
EMAIL = "YOUR_EMAIL"
API_TOKEN ="JIRA_API_TOKEN"
PROJECT_KEY = "JIRA_PROJECT_NAME"

auth = HTTPBasicAuth(EMAIL, API_TOKEN)
headers = {"Content-Type": "application/json"}


def post_user_stories_to_jira(user_stories):
    updated_keys = []
    created_keys = []
    errors = []

    # 1️⃣ Collect all user_story_ids
    labels = [story["user_story_id"] for story in user_stories if "user_story_id" in story]

    if not labels:
        print("No user_story_id found in input.")
        return

    # 2️⃣ Search Jira for existing issues with these labels
    jql_labels = ",".join(f'"{l}"' for l in labels)
    jql = f'project = "{PROJECT_KEY}" AND labels in ({jql_labels})'
    search_url = f"{JIRA_URL}/rest/api/2/search"
    search_resp = requests.get(search_url, headers=headers, auth=auth, params={"jql": jql, "fields": "key,labels"})

    if search_resp.status_code != 200:
        print("Failed to search Jira:", search_resp.status_code, search_resp.text)
        return

    existing_map = {}  # user_story_id → issueKey
    for issue in search_resp.json().get("issues", []):
        for label in issue["fields"]["labels"]:
            if label in labels:
                existing_map[label] = issue["key"]

    # 3️⃣ Split into updates and creates
    updates = []
    creates = []
    for story in user_stories:
        fields = {
            "project": {"key": PROJECT_KEY},
            "summary": story["user_story"],
            "description": "\n".join(story.get("acceptance_criteria", [])),
            "issuetype": {"name": "Task"},
            "labels": [story["user_story_id"]]
        }
        if "priority" in story and story["priority"]:
            fields["priority"] = {"name": story["priority"]}

        if story["user_story_id"] in existing_map:
            updates.append((existing_map[story["user_story_id"]], fields))
        else:
            creates.append({"fields": fields})

    # 4️⃣ Perform updates (one by one)
    for issue_key, fields in updates:
        update_url = f"{JIRA_URL}/rest/api/2/issue/{issue_key}"
        resp = requests.put(update_url, headers=headers, auth=auth, data=json.dumps({"fields": fields}))
        if resp.status_code == 204:
            print(f"Updated {issue_key}")
            updated_keys.append(issue_key)
        else:
            print(f"Failed to update {issue_key}: {resp.status_code} {resp.text}")
            errors.append({"issue": issue_key, "status": resp.status_code, "error": resp.text})

    if creates:
        bulk_url = f"{JIRA_URL}/rest/api/2/issue/bulk"
        resp = requests.post(bulk_url, headers=headers, auth=auth, data=json.dumps({"issueUpdates": creates}))
        if resp.status_code == 201:
            created = [issue["key"] for issue in resp.json().get("issues", [])]
            print("Bulk create successful:", created)
            created_keys.extend(created)
        else:
            print("Bulk create failed:", resp.status_code, resp.text)
            errors.append({"bulk_create": resp.status_code, "error": resp.text})

    # ✅ Always return a dict so your API never sees None
    return {
        "updated": updated_keys,
        "created": created_keys,
        "errors": errors
    }
###################################################################################################
def post_test_cases_to_jira(test_cases):
    issues_to_create = []
    for tc in test_cases:
        description = (
            f"*Precondition*: {tc.get('precondition', '')}\n"
            f"*Steps*:\n" +
            "\n".join([f"- {step}" for step in tc.get('steps', [])]) +
            f"\n*Expected Result*: {tc.get('expected_result', '')}\n"
            f"*Priority*: {tc.get('priority', '')}\n"
            f"*Tags*: {', '.join(tc.get('tags', []))}"
        )
        issues_to_create.append({
            "fields": {
                "project": {"key": PROJECT_KEY},
                "summary": tc.get("title", tc.get("test_id", "Test Case")),
                "description": description,
                "issuetype": {"name": "Task"}, 
                "labels": tc.get("tags", []),
                "priority": {"name": tc.get("priority", "Medium")},
            }
        })

    payload = {"issueUpdates": issues_to_create}
    headers = {"Content-Type": "application/json"}

    response = requests.post(
        API_ENDPOINT,
        headers=headers,
        auth=HTTPBasicAuth(EMAIL, API_TOKEN),
        data=json.dumps(payload)
    )

    if response.status_code == 201:
        print("Bulk test cases created successfully!")
        return response.json()
    else:
        print(f"Failed with status code {response.status_code}")
        print(response.text)
        return None
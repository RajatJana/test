import uuid
from sqlalchemy import Column, String, Text, TIMESTAMP, ARRAY, Float, Integer, Boolean
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

try:
    from pgvector.sqlalchemy import Vector
except ImportError:
    Vector = None  # Graceful fallback if pgvector not installed

Base = declarative_base()


class ProgressTracker(Base):
    __tablename__ = "clarifai_progress_tracker"

    doc_id = Column(String(64), primary_key=True)
    doc_name = Column(String(255), nullable=False)
    stage = Column(String(50), nullable=False)
    output_paths = Column(ARRAY(Text))
    date_last_modified = Column(TIMESTAMP, default=datetime.utcnow)


class UserStoryEmbedding(Base):
    __tablename__ = "clarifai_user_story_embeddings"

    # Primary key
    id = Column(String(64), primary_key=True, default=lambda: uuid.uuid4().hex)

    # User story content
    user_story_id = Column(String(20), nullable=False)
    title = Column(String(500), nullable=False)
    user_story_text = Column(Text, nullable=False)
    acceptance_criteria = Column(ARRAY(Text))
    description = Column(Text)

    # Source requirement
    requirement_id = Column(String(20))
    requirement_text = Column(Text)

    # Metadata for filtering
    tags = Column(ARRAY(Text))
    priority = Column(String(20))
    tshirt_size = Column(String(5))
    confidence_score = Column(Float)

    # Source tracking
    source_agent = Column(String(50), nullable=False)
    source_doc_id = Column(String(64))

    # Embedding vector (768 dimensions)
    embedding = Column(Vector(768), nullable=False) if Vector else Column(Text)

    # Timestamps
    created_at = Column(TIMESTAMP, default=datetime.utcnow)

    # Quality signals
    user_rating = Column(Integer)
    was_edited = Column(Boolean, default=False)

# agents/requirement_user_story_agent.py
import logging
from typing import Dict, List, Callable
from tools.prompt_utils import extract_clean_json
from tools.doc_parsers import extract_text_from_file  # your new parser
from tools.rag_utils import retrieve_similar_examples, format_examples_for_prompt, store_generated_stories, RAG_ENABLED

class RequirementUserStoryAgent:
    def __init__(self, llm_caller: Callable[[str], str]):
        self.llm_caller = llm_caller

    def _extract_reference_text(self, docs: List) -> str:
        """
        Extracts and concatenates text from a list of document file paths or file-like objects.
        """
        extracted_parts = []
        for doc in docs:
            try:
                text = extract_text_from_file(doc)
                if text:
                    extracted_parts.append(text.strip())
            except Exception as e:
                logging.error(f"Failed to extract text from {doc}: {e}")
        return "\n\n".join(extracted_parts)

    def run(self, inputs: Dict) -> Dict:
        raw_info = inputs.get("raw_info", "")
        reference_docs = inputs.get("reference_docs", [])  # optional list of file paths or file-like objects

        # Merge reference document text if provided
        reference_text = ""
        if reference_docs:
            reference_text = self._extract_reference_text(reference_docs)

        if reference_text:
            combined_info = f"{raw_info}\n\n---\nReference Documents:\n{reference_text}"
        else:
            combined_info = raw_info

        # RAG: Retrieve similar past stories as few-shot examples
        rag_examples_text = ""
        if RAG_ENABLED:
            try:
                search_query = combined_info[:500]  # First 500 chars as search query
                similar = retrieve_similar_examples(search_query, tag_filter=None)
                if similar:
                    rag_examples_text = format_examples_for_prompt(similar)
            except Exception as e:
                logging.warning(f"[RequirementUserStoryAgent] RAG retrieval failed: {e}")

        prompt = f"""
You are an expert software analyst assistant. Your task is to analyze the following raw information extracted from a UI/UX design and generate detailed user stories in a specific JSON format.

For each user story, provide:

⦁   user_story_id: Start the first story with "US-001" and increment sequentially for subsequent stories.
⦁   title: A short, descriptive title for the story.
⦁   user_story: 
            As a <role>
            When I, <action>
            Then, I can <benefit>
    Rules:
    <role>: Be specific. Instead of a generic "user," use a descriptive role like "existing customer," "first-time visitor," or "administrator."
    <action>: Describe a specific, active event, not a passive state. It must start with a verb. For example, use "Tap on 'Send' from the Transfers screen" instead of "I am on the Transfers screen."
    <benefit>: Phrase this as a capability the user gains. It must start with "I can." For example, use "I can initiate a transfer" instead of "I want to initiate a transfer."

⦁  acceptance_criteria: 
    - Provide minimum 3–4 clear, testable acceptance criteria in a "Given..., When..., Then..." format.
    - Avoid adding acceptance criteria that are not supported by the provided UI/UX information unless they are explicitly present in the provided reference document. In such cases, include them clearly and maintain their traceability to the reference document.
    - Avoid repeating identical acceptance criteria across multiple stories unless absolutely necessary.
    - Include additional **plausible negative scenarios** (even if not shown in the UI/Figma) that could be relevant for BA review, clearly marking them as "Potential Negative Scenario" in the statement so they can be included/excluded later.

⦁   Description/Note: If the reference documents provide a specific description, note, or business rule, use that exact text as the description for the respective user story, regardless of its length. If no such information is available in the documents, then write a brief sentence to add context or clarification.
⦁   Tags/Labels: An array of relevant string keywords for categorization.
⦁   confidence_score: A float between 0.0 and 1.0 representing the confidence in the story's accuracy based on the input.
⦁   tshirt_size: A relative effort estimate using "XS", "S", "M", "L", or "XL"
⦁   priority: "High", "Medium", or "Low".
⦁   requirement_id: Always set this to "N/A".

Here is an example of the required output format:
[
    {{
        "requirement_id": "N/A",
        "user_story_id": "US-001",
        "title": "User Authentication via OTP",
        "user_story": "As a User, When I click on login, Then i can able to access OTP based login",
        "acceptance_criteria": [
            "Given a user is on the login page, When they enter a valid username and click 'Send OTP', Then an OTP is sent to their registered mobile number/email.",
            "Given an OTP has been sent, When 5 minutes have passed, Then the OTP is invalid.",
            "Given a user has entered an invalid username, When they click 'Send OTP', Then an error message is displayed."
        ],
        "Description/Note": "This user story covers the generation and sending of the one-time password. The verification part is handled in a separate story.",
        "Tags/Labels": [
            "authentication",
            "security",
            "login"
        ],
        "confidence_score": 0.95,
        "tshirt_size": "M",
        "priority": "High"
    }}
]


IMPORTANT:

⦁   Do NOT use Markdown or triple backticks in your final output.

⦁   Do NOT add any explanations, introductions, or conversational text.

⦁   Respond ONLY with the raw JSON array containing the generated user stories.

{rag_examples_text}
Input:

{combined_info}
""".strip()
        print("=== FINAL PROMPT ===\n", prompt)
        llm_response = self.llm_caller(prompt)

        try:
            parsed = extract_clean_json(llm_response)
        except Exception as e:
            logging.error(f"Failed to parse LLM response: {e}, raw: {llm_response[:500]}")
            parsed = []

        # RAG: Store generated stories for future retrieval
        if RAG_ENABLED and parsed:
            try:
                store_generated_stories(parsed, source_agent="RequirementUserStoryAgent")
            except Exception as e:
                logging.warning(f"[RequirementUserStoryAgent] RAG storage failed: {e}")

        return {"user_stories": parsed}

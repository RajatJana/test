from typing import List, Dict, Callable
import re
import json
from tools.prompt_utils import extract_clean_json

class ValidationAgent:
    def __init__(self, llm_caller: Callable[[str], str]):
        self.llm_caller = llm_caller

    def _rule_based_issues(self, text: str) -> List[str]:
        issues = []
        if len(text.strip().split()) < 5:
            issues.append("Too short")
        if re.search(r"\betc\.|\bstuff\b|\bthings\b|\bshould handle\b", text.lower()):
            issues.append("Vague phrasing")
        return issues

    def run(self, inputs: Dict) -> Dict:
        print(inputs)
        requirements = inputs["classified_requirements"]

        # Step 1: Build the input list for Gemini
        req_list = [
            {"id": req["requirement_id"], "text": req["requirement_text"]}
            for req in requirements
        ]

        # Step 2: Prompt
        formatted = "\n".join([
            f'{r["id"]}: {r["text"]}' for r in req_list
        ])
        # 
        prompt = f"""
        You are a meticulous and senior Business Analyst and requirement validator. Your task is to analyze a list of business requirements and determine their quality based on a set of precise criteria. For each requirement, you must return a JSON object containing a quality assessment.

        You must apply the following specific validation criteria:
        
        ⦁	Measurable and Verifiable: The requirement must be quantifiable and allow for a clear pass/fail test. It should include specific metrics such as time (e.g., "within 2 seconds"), percentage (e.g., "99.9% uptime"), or number (e.g., "up to 1,000 users"). If a requirement is not measurable, it fails this check.
        
        ⦁	Unambiguous and Clear: The requirement must be free of vague, subjective, or open-ended language. The meaning must be singular and not open to multiple interpretations. Identify and flag vague terms such as "fast," "robust," "user-friendly," "efficient," "easy," "as soon as possible," or "reliable."

        ⦁	Atomic: Each requirement must state a single, self-contained business need. It should not combine multiple, distinct functions or needs into one statement. Check for conjunctions like 'and' or 'or' which often indicate a violation of this criterion.

        ⦁	Completeness: The requirement should contain all necessary information to be fully understood. A complete requirement typically answers the 'what', 'who', 'when', 'where', and 'how'.

        For each requirement, respond with a JSON object in the following raw format:
            [
            {{
                "requirement_id": "REQ-001",
                "llm_check_passed": true,
                "issues": [],
                "justification": "The requirement is clearly defined and testable."
            }},
            ...
            ]

        The justification field must provide a concise summary of the validation results, explicitly mentioning which criteria were met or failed. If a requirement fails, the justification must explain why, referencing the specific issue found.
        The issues field must be an array of strings. Each string must combine the issue type and the reason for the issue in a single statement. The format must be "Issue Type: The reason for the issue."
        
        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        Requirements:
        {formatted}
        """.strip()
        # prompt = f"""
        # You are a senior Business Analyst and requirement validator. Your task is to analyze a list of business requirements and determine their quality based on a set of precise criteria. For each requirement, you must return a JSON object containing a quality assessment.

        # You must apply the following specific validation criteria:

        #     - Measurable and Verifiable: The requirement must be quantifiable and allow for a clear pass/fail test. It should include specific metrics such as time (e.g., "within 2 seconds"), percentage (e.g., "99.9% uptime"), or number (e.g., "up to 1,000 users"). If a requirement is not measurable, it fails this check.

        #     - Unambiguous and Clear: The requirement must be free of vague, subjective, or open-ended language. The meaning must be singular and not open to multiple interpretations. Identify and flag vague terms such as "fast," "robust," "user-friendly," "efficient," "easy," "as soon as possible," or "reliable."

        #     - Atomic: Each requirement should state a single, self-contained business need. It should not combine multiple, distinct functions or needs into one statement.

        # For each requirement, respond with a JSON object in the following raw format:
        #     [
        #     {{
        #         "requirement_id": "REQ-001",
        #         "llm_check_passed": true,
        #         "issues": [],
        #         "justification": "The requirement is clearly defined and testable."
        #     }},
        #     ...
        #     ]

        # IMPORTANT:
        # - Do NOT use Markdown or triple backticks.
        # - Do NOT add explanations.
        # - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        # Requirements:
        # {formatted}
        # """.strip()
        # prompt = f"""
        # You are a requirement quality checker. You are validating business requirements.

        # Below is a list of requirements. 
        # For each requirement, return:
        # - requirement_id
        # - llm_check_passed: true if the requirement is clear, testable, and unambiguous
        # - issues: list of issues if not valid (e.g. vague, not measurable)
        # - justification: a short reason for why it's valid (if passed)

        # Respond in this raw JSON format:
        # [
        # {{
        #     "requirement_id": "REQ-001",
        #     "llm_check_passed": true,
        #     "issues": [],
        #     "justification": "The requirement is clearly defined and testable."
        # }},
        # ...
        # ]

        # IMPORTANT:
        # - Do NOT use Markdown or triple backticks.
        # - Do NOT add explanations.
        # - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        # Requirements:
        # {formatted}
        # """.strip()

        llm_response = self.llm_caller(prompt)
        try:
            # llm_results = json.loads(llm_response)
            llm_results = extract_clean_json(llm_response)
        except Exception:
            llm_results = []

        # Step 3: Map by ID
        result_map = {r["requirement_id"]: r for r in llm_results}

        # Step 4: Merge with original list
        for req in requirements:
            #  rule_issues = self._rule_based_issues(req["requirement_text"])
            llm_result = result_map.get(req["requirement_id"], {
                "llm_check_passed": False,
                "issues": ["LLM did not return result"],
                "justification": "LLM did not return result"
            })

            # combined_issues = sorted(set(rule_issues + llm_result.get("issues", [])))
            combined_issues = sorted(set(llm_result.get("issues", [])))

            req["validation"] = {
                "llm_check_passed": llm_result.get("llm_check_passed", False),
                "issues": combined_issues,
                "justification": llm_result.get("justification", "")
            }

        return {"validated_requirements": requirements}
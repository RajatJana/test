import json
from typing import List, Dict, Callable
import logging

from tools.prompt_utils import extract_clean_json

class TestCaseAgent:
    def __init__(self, llm_caller: Callable[[str], str]):
        self.llm_caller = llm_caller

    def run(self, inputs: Dict) -> Dict:
        user_stories: List[Dict] = inputs["user_stories"]

        if not user_stories:
            return {"gherkin_scenarios": []}
        
        # Format prompt content
        #formatted = "\n".join([f"""
                               # Requirement ID: {story['requirement_id']}
                               #User Story: {story['user_story']}
                               # Acceptance Criteria:
                                #- {'\\n- '.join(story['acceptance_criteria'])}
                                #""".strip() for story in user_stories
        #])
        formatted = "\n".join([
                    f"""Requirement ID: {story['requirement_id']}
                    User Story Id: {story['user_story_id']}
                    User Story: {story['user_story']}
                    Description: {story['Description/Note']}
                    Acceptance Criteria:
-                   {joined_criteria}""".strip()
                    for story in user_stories
                    for joined_criteria in ['\n- '.join(story['acceptance_criteria'])]
        ])

        prompt = f"""
        You are a test engineer assistant.

        Given a list of user stories with acceptance criteria, generate test cases.
        Each test case should include:
        - test_id (A unique identifier for the test case, generated based on the following logic:
                    If a requirement_id is available: The test_id should follow the format TC-[requirement_id]-[user_story_id]-[sequential_number].

                    Example: "test_id": "TC-REQ-001-US-001-001"

                    If the requirement_id is 'n/a': The test_id should follow the format TC-[user_story_id]-[sequential_number].

                    Example: "test_id": "TC-US-001-001" )
        - title
        - precondition
        - steps (list of steps)
        - expected_result
        - priority (High, Medium, Low)
        - tags (list of keywords like regression, login, security, etc.)

        Only return raw JSON, like:
        [
        {{
            "test_id": "TC-REQ-001-US-001-1",
            "title": "Login with correct credentials",
            "precondition": "User is on the login page",
            "steps": ["Enter valid username", "Enter valid password", "Click Login"],
            "expected_result": "User is logged in",
            "priority": "High",
            "tags": ["login", "regression"]
        }},
        ...
        ]

        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        Input:
        {formatted}
        """.strip()

        response = self.llm_caller(prompt)
        print("LLM Raw Response:", response)

        try:
            test_cases = extract_clean_json(response)
            print("Parsed test cases:", test_cases)
        except Exception as e:
            test_cases = []

        return {"test_cases": test_cases}

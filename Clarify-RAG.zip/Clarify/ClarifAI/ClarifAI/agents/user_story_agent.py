from typing import List, Dict, Callable
import json
import logging

from tools.prompt_utils import extract_clean_json
from tools.rag_utils import retrieve_similar_examples, format_examples_for_prompt, store_generated_stories, RAG_ENABLED

class UserStoryAgent:
    def __init__(self, llm_caller: Callable[[str], str]):
        self.llm_caller = llm_caller

    def run(self, inputs: Dict) -> Dict:
        validated = inputs["validated_requirements"]

        # Step 1: Filter functional and validated
        functional_reqs = [
            r for r in validated
            if r.get("requirement_type") == "Functional"
            and r.get("validation", {}).get("llm_check_passed") is True
        ]

        if not functional_reqs:
            return {"user_stories": []}

        # Step 1.5: RAG - Retrieve similar past stories as few-shot examples
        rag_examples_text = ""
        if RAG_ENABLED:
            try:
                all_req_texts = " ".join([r["requirement_text"] for r in functional_reqs])
                similar = retrieve_similar_examples(all_req_texts, tag_filter=None)
                if similar:
                    rag_examples_text = format_examples_for_prompt(similar)
            except Exception as e:
                logging.warning(f"[UserStoryAgent] RAG retrieval failed (non-blocking): {e}")

        # Step 2: Build prompt
        formatted = "\n".join([
            f'{r["requirement_id"]}: {r["requirement_text"]}' for r in functional_reqs
        ])
        #v1
        # prompt = f"""
        # You are a product owner.

        # For each of the following requirements, generate:
        # - A user story in the format: "As a <role>, I want to <action>, so that <benefit>"
        # - 2–4 clear acceptance criteria
        # - A confidence score between 0.0 and 1.0 based on how confident you are that the requirement was converted correctly
        # - A T-shirt size estimate (XS, S, M, L, XL) representing the relative effort or complexity to implement the user story

        # Respond with raw JSON in the format:
        # [
        # {{
        #     "requirement_id": "REQ-001",
        #     "user_story": "As a user, I want to log in with OTP so that I can access my account securely.",
        #     "acceptance_criteria": [
        #     "User receives OTP after entering username.",
        #     "OTP must expire after 5 minutes.",
        #     "User cannot proceed without valid OTP."
        #     ],
        #     "confidence_score": 0.92,
        #     "tshirt_size": "M"
        # }},
        # ...
        # ]

        # IMPORTANT:
        # - Do NOT use Markdown or triple backticks.
        # - Do NOT add explanations.
        # - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        # Requirements:
        # {formatted}
        # """.strip()
        

        #v2
        # prompt = f"""
        # You are a product owner.

        # For each requirement, generate ONE OR MORE user stories (some requirements may result in multiple user stories).

        # For each user story, provide:

        # - title - short description
        # - A user story in the format: "As a <role>, I want to <action>, so that <benefit>"
        # - 2–4 clear acceptance criteria
        # - A confidence score between 0.0 and 1.0 based on how confident you are that the requirement was converted correctly
        # - A T-shirt size estimate (XS, S, M, L, XL) representing the relative effort or complexity to implement the user story
        # - priority - High/Medium/Low
        # - status - Draft/In Progress/Done
        # - Always start 1st user story id from US-001

        # Respond with raw JSON in the format (example):
        # [
        # {{
        # "requirement_id": "REQ-001",
        # "user_stories": [
        # {{
        # "id": "US-001"
        # "title": "Login validation"
        # "story": "As a user, I want to log in with OTP so that I can access my account securely.",
        # "acceptance_criteria": [
        # "User receives OTP after entering username.",
        # "OTP must expire after 5 minutes.",
        # "User cannot proceed without valid OTP."
        # ],
        # "priority": "High",
        # "tshirt_size": "M",
        # "confidence_score": 0.92
        # }},
        # ...
        # ]
        # }},
        # ...
        # ]

        # IMPORTANT:
        # - Do NOT use Markdown or triple backticks.
        # - Do NOT add explanations.
        # - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        # Requirements:
        # {formatted}
        # """.strip()

        #v3
        # For the 1st Requirement generate atleast 3 user stories.
        prompt = f"""
        You are a skilled product owner. Your task is to analyze business requirements and break them down into actionable user stories for a development team. For each requirement, generate one or more user stories (some requirements may result in multiple user stories).

        For each user story, provide:

        ⦁	user_story_id: Always start the 1st user story ID from US-001. Subsequent IDs should increment sequentially.
        ⦁	title: A short, descriptive title.
        ⦁	user_story: In the format: "As a <role>, I want to <action>, so that <benefit>."
        ⦁	description: A brief sentence to add context or clarification.
        ⦁	acceptance_criteria: 3–4 clear and testable acceptance criteria.
        ⦁	confidence_score: A score from 0.0 to 1.0 reflecting how confidently you believe the requirement was converted correctly. Base this on the clarity and detail of the original requirement. A vague requirement should result in a lower score.
        ⦁	tshirt_size: An estimate (XS, S, M, L, XL) representing the relative effort to implement the story. These estimates should be consistent across all generated stories.
        ⦁	priority: A priority level (High/Medium/Low) based on business value and urgency.

        Respond with raw JSON in the format:
        [
        {{
            "requirement_id": "REQ-001",
            "user_story_id": "US-001",
            "title": "User Authentication via OTP"
            "user_story": "As a user, I want to log in with OTP so that I can access my account securely.",
            "description": "This user story covers the generation and sending of the one-time password. The verification part is handled in a separate story.",            
            "acceptance_criteria": [
            "User receives OTP after entering username.",
            "OTP must expire after 5 minutes.",
            "User cannot proceed without valid OTP."
            ],
            "confidence_score": 0.92,
            "tshirt_size": "M",
            "priority": "High",
            "tags": [
            "authentication",
            "security",
            "login"
            ]
        }},
        ...
        ]

        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        {rag_examples_text}
        Requirements:
        {formatted}
        """.strip()
        llm_response = self.llm_caller(prompt)

        try:
            # parsed = json.loads(llm_response)
            parsed = extract_clean_json(llm_response)
        except Exception as e:
            logging.error(f"Failed to parse LLM response: {e}, raw: {llm_response[:500]}")
            parsed = []

        # Step 4: RAG - Store generated stories for future retrieval
        if RAG_ENABLED and parsed:
            try:
                req_texts = {r["requirement_id"]: r["requirement_text"] for r in functional_reqs}
                store_generated_stories(parsed, source_agent="UserStoryAgent", requirement_texts=req_texts)
            except Exception as e:
                logging.warning(f"[UserStoryAgent] RAG storage failed (non-blocking): {e}")

        return {"user_stories": parsed}

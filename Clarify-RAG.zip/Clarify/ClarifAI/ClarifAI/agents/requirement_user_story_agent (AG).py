# agents/requirement_user_story_agent.py
import logging
from typing import Dict, List, Callable
from tools.prompt_utils import extract_clean_json
from tools.doc_parsers import extract_text_from_file, extract_tables_from_file, extract_images_from_file

class RequirementUserStoryAgent:
    def __init__(self, llm_caller: Callable[[str], str]):
        self.llm_caller = llm_caller

    def _extract_reference_text(self, docs: List) -> str:
        """
        Extracts and concatenates text, tables, and image descriptions from a list of documents.
        """
        extracted_parts = []
        for doc in docs:
            try:
                # Extract plain text
                text = extract_text_from_file(doc)
                if text:
                    extracted_parts.append(f"[TEXT]\n{text.strip()}")

                # Extract tables as Markdown or CSV-like text
                tables = extract_tables_from_file(doc)
                if tables:
                    for idx, table in enumerate(tables, start=1):
                        extracted_parts.append(f"[TABLE {idx}]\n{table.strip()}")

                # Extract image descriptions (OCR or captioning)
                images = extract_images_from_file(doc)
                if images:
                    for idx, img_desc in enumerate(images, start=1):
                        extracted_parts.append(f"[IMAGE {idx} DESCRIPTION]\n{img_desc.strip()}")

            except Exception as e:
                logging.error(f"Failed to extract content from {doc}: {e}")

        return "\n\n".join(extracted_parts)

    def run(self, inputs: Dict) -> Dict:
        raw_info = inputs.get("raw_info", "")
        reference_docs = inputs.get("reference_docs", [])

        reference_text = ""
        if reference_docs:
            reference_text = self._extract_reference_text(reference_docs)

        if reference_text:
            combined_info = f"{raw_info}\n\n---\nReference Documents (may include text, tables, image descriptions, business rules, and screen flows):\n{reference_text}"
        else:
            combined_info = raw_info
# 5. Handling Priority-Based Logic (Combinatorial Scenarios):
#    - For features where multiple input fields can be used at the same time and the system follows a priority order (e.g., a search form that prioritizes an 'ID' field over a 'Name' field), you MUST capture this logic explicitly.
#    - Create a dedicated user story for the search/execution logic.
#    - Within that story, the `acceptance_criteria` MUST clearly define the hierarchy of operations.
#    - Example Criteria for a Search Priority (ID > Email > Name):
#        - 'The search must be executed using the `ID` if the `ID` field is populated, ignoring all other search fields.'
#        - 'If the `ID` field is empty, the search must be executed using the `Email` if it is populated, ignoring the `Name` field.'
#        - 'The search must only be executed using the `Name` field if both the `ID` and `Email` fields are empty.'

        prompt = f"""
You are an expert software analyst assistant. Your task is to analyze the provided UI/UX designs and reference documents to generate detailed user stories in a specific JSON format.

Core Principles for Story Creation:

Granularity Hierarchy (Non-Negotiable):
1. Sub-Use Case / Business Rule Level:
   - Each sub-use case, work package, or distinct business rule in the reference document MUST generate its own separate user story (or set of stories if multiple screens are involved).
   - Stories from different sub-use cases MUST NEVER be merged, even if they share the same screens, workflows, or UI components.
   - This ensures that UC2.1, UC2.2, or any future UC3.x, UC4.x, etc. always produce distinct user stories.

2. Screen-Level Granularity (Within a Sub-Use Case):
   - Within each sub-use case, you MUST break down features into separate user stories based on the user interface screens or distinct workflow steps.
   - A single story should not span multiple screens.
   - Example: For a feature involving a search form and a results display, you MUST create two separate stories:
       Story 1 (Search Screen): Focuses entirely on the UI, interactions, and rules for the search input screen.
       Story 2 (Results Screen): Focuses entirely on the logic for executing the search and displaying the returned data on the results screen.

3. Functional Cohesion (Within a Single Screen):
   - For any screen containing multiple distinct functionalities or components, you MUST break them down into separate, functionally-cohesive user stories. A single story should not bundle unrelated actions, even if they appear on the same screen.
   - Primary Example (Grouping by Component/Function): On a search results screen with multiple navigation options, you MUST create separate stories for distinct functions:
       - Story A (Return Actions): Focuses only on links that navigate the user back to the search screen.
       - Story B (In-Row Actions): Focuses on the primary actions available on each result row (e.g., View, Edit, More Options).
       - Story C (Pagination): Focuses exclusively on the controls for navigating pages of results.
   - Secondary Example (Grouping by Logic): For a very complex form, another valid method is to separate the "happy path" (successful submission) from "validation and error handling."

4. Separation of Concerns:
   - You MUST break down complex features into smaller, focused user stories.
   - A primary method is to separate the "happy path" from validation and error handling.
   - Example: For a search feature, create two distinct stories:
       1. Search Execution Story: Focuses on a user successfully performing a search with valid data and seeing the results.
       2. Validation Story: Focuses on providing feedback and error messages when a user enters invalid data.

For each user story you generate, provide the following JSON fields:
user_story_id: Start the first story with "US-001" and increment sequentially for subsequent stories.
title: A short, descriptive title for the story.
user_story:
    As a <role>
    I want to <goal/action>
    So that <benefit/value>
    Rules:
        - <role>: Be specific (e.g., "Claims Agent," "New Applicant").
        - <goal/action>: Describe the action the user wants to perform as a concise statement of their immediate goal.
        - <benefit/value>: Explain the larger reason or value the user gains from achieving their goal. This articulates the "why".

acceptance_criteria:
    - Format: Use the Rule-Oriented (Declarative) style. Each criterion must be a direct, testable statement of a rule or expected outcome. Do not use the "Given..., When..., Then..." format.
    - Crucial Rule: You MUST generate a distinct acceptance criterion for every single business rule, validation check, UI state change, specific error message, and success outcome detailed in the reference documents.
    - Exhaustiveness is Key: Create a complete checklist of all testable requirements.
    - Structure: Group criteria by category for clarity (e.g., UI Behavior, Validation Rules, Business Logic).
    - Traceability: If a requirement is sourced from a specific part of a reference document (e.g., a requirement ID like 'BR-LP-03.006' or a section number), append this reference in parentheses at the end of the criterion.
    - Negative Scenarios: Include plausible negative scenarios where applicable.

Description/Note: A purely high-level summary of the feature's purpose and overall logic. This field provides the "why" and should read like a narrative, not a technical specification.
    What to Include:
        - The feature's primary goal and user benefit.
        - A brief, prose explanation of complex business logic.
        - Traceability: If the overall feature is described in a specific section of a reference document, mention it (e.g., "This feature is based on the requirements in section 4.2 of the BRD.").
    What to EXCLUDE (CRUCIAL):
        - ABSOLUTELY NO field-level validation rules or specific error messages.
        - ABSOLUTELY NO descriptions of UI states (e.g., "the button is disabled").
        - Example of what NOT to write: "The system validates the Contract field is numeric and shows an error..."
        - Example of what TO write: "This feature allows users to find records by various criteria. It includes input checks to ensure data quality before processing the search."

Tags/Labels: An array of relevant string keywords for categorization.
confidence_score: A float between 0.0 and 1.0 representing the confidence in the story's accuracy based on the input.
tshirt_size: A relative effort estimate using "XS", "S", "M", "L", or "XL"
priority: "High", "Medium", or "Low".
requirement_id: Always set this to "N/A".

Here is an example of the required output format:
[
    {{
        "requirement_id": "N/A",
        "user_story_id": "US-001",
        "title": "User Authentication via OTP",
        "user_story": "As a User, I want to use a one-time password to log in, so that I can securely access my account.",
        "acceptance_criteria": [
            "An OTP must be successfully sent to the user's registered mobile number when they enter a valid username and click 'Send OTP' (Req. 7.3.1).",
            "The error message 'Username not found' must be displayed if the user enters an invalid or non-existent username.",
            "The OTP code must expire and become invalid after 5 minutes (Req. 7.3.2).",
            "The input field for the OTP must accept only numeric characters.",
            "Potential Negative Scenario: A system error message 'OTP service is currently down...' must be displayed if the OTP service is unavailable."
        ],
        "Description/Note": "This story covers the generation and dispatch of a one-time password (OTP) for user login, based on the requirements in section 7.3 of the security specification document.\n- The system performs a check on the username before triggering the OTP service.\n- OTPs have a defined lifecycle and expire after a set duration. The verification of the entered OTP is handled in a separate story.",
        "Tags/Labels": [
            "authentication",
            "security",
            "login"
        ],
        "confidence_score": 0.95,
        "tshirt_size": "M",
        "priority": "High"
    }}
]

IMPORTANT:

- Do NOT use Markdown or triple backticks in your final output.
- Do NOT add any explanations, introductions, or conversational text.
- Respond ONLY with the raw JSON array.

Input:

{combined_info}

If reference documents are provided, consider their content (including any extracted text, tables, image descriptions, business rules, and screen-to-screen flow logic) as supporting context to refine and validate the user stories, but do not invent features solely from them unless explicitly stated.
""".strip()

        print("=== FINAL PROMPT ===\n", prompt)
        llm_response = self.llm_caller(prompt)

        try:
            parsed = extract_clean_json(llm_response)
        except Exception as e:
            logging.error(f"Failed to parse LLM response: {e}, raw: {llm_response[:500]}")
            parsed = []

        return {"user_stories": parsed}

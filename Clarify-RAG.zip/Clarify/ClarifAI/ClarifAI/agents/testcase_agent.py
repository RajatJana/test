import json
from typing import List, Dict, Callable
import logging

from tools.prompt_utils import extract_clean_json

class TestCaseAgent:
    def __init__(self, llm_caller: Callable[[str], str]):
        self.llm_caller = llm_caller

    def run(self, inputs: Dict) -> Dict:
        user_stories: List[Dict] = inputs["user_stories"]

        if not user_stories:
            return {"gherkin_scenarios": []}
        
        # Format prompt content
        #formatted = "\n".join([f"""
                               # Requirement ID: {story['requirement_id']}
                               #User Story: {story['user_story']}
                               # Acceptance Criteria:
                                #- {'\\n- '.join(story['acceptance_criteria'])}
                                #""".strip() for story in user_stories
        #])
        formatted = "\n".join([
                    f"""Requirement ID: {story['requirement_id']}
                    User Story Id: {story['user_story_id']}
                    User Story: {story['user_story']}
                    Description: {story.get('description', story.get('Description/Note', 'N/A'))}
                    Acceptance Criteria:
-                   {joined_criteria}""".strip()
                    for story in user_stories
                    for joined_criteria in ['\n- '.join(story['acceptance_criteria'])]
        ])

        prompt = f"""
        You are a test engineer assistant.

        Given a list of user stories with acceptance criteria, generate test cases.

        Test Case Generation Strategy:
        Based on the user stories and acceptance criteria, create a variety of test cases to ensure full coverage. This should include:
        * Positive Scenarios (Happy Path): Test cases that verify the functionality works as expected with valid inputs and user flows, directly mapping to the acceptance criteria.
        * Negative Scenarios (Error Path): Test cases designed to check the system's response to invalid input or unexpected actions. This includes, but is not limited to:
            * Using invalid data formats (e.g., letters in a numeric field).
            * Submitting empty or null values for required fields.
            * Testing with data that violates business rules (e.g., a start date after an end date).
            * Verifying that clear and user-friendly error messages are displayed.
        * Boundary Value Analysis: Test cases that focus on the boundary values of input domains. For any field with a range (e.g., password length of 8-16 characters), test the minimum, maximum, just below the minimum, and just above the maximum values (e.g., 7, 8, 16, and 17 characters).
        * Optional Field Scenarios: If a feature includes optional fields or settings, generate test cases to:
            * Verify the primary functionality works correctly when the optional fields are left empty.
            * Verify the functionality works correctly when the optional fields are filled with valid data.
            * Verify proper behavior or error handling when optional fields are filled with invalid data.
        * Combinatorial & Priority-Based Scenarios: For features where multiple input fields can be used simultaneously and a priority order is defined (e.g., a search form):
            * Generate test cases combining two or more input fields to test the priority logic.
            * The `title` and `expected_result` for these tests must clearly state which field is expected to take precedence.
            * **Example Test:** Fill a high-priority field (e.g., `Affiliate ID`) and a low-priority field (e.g., `Affiliate Name`). The expected result should be that the search is executed *only* using the `Affiliate ID`.
            * Cover various combinations (High + Low priority, Medium + Low priority, all fields filled, etc.).
            * Include negative combinations, such as a valid high-priority input with an invalid low-priority input, to ensure the priority logic is strictly followed.

        Each test case should include:
        - test_id (A unique identifier for the test case, generated based on the following logic:
                    If a requirement_id is available: The test_id should follow the format TC-[requirement_id]-[user_story_id]-[sequential_number].

                    Example: "test_id": "TC-REQ-001-US-001-001"

                    If the requirement_id is 'n/a': The test_id should follow the format TC-[user_story_id]-[sequential_number].

                    Example: "test_id": "TC-US-001-001" )
        - title
        - precondition
        - steps (list of steps)
        - expected_result
        - priority (High, Medium, Low)
        - tags (list of keywords like regression, login, security, positive, negative, boundary, etc.)

        Only return raw JSON, like:
        [
        {{
            "test_id": "TC-REQ-001-US-001-1",
            "title": "Login with correct credentials",
            "precondition": "User is on the login page",
            "steps": ["Enter valid username", "Enter valid password", "Click Login"],
            "expected_result": "User is logged in",
            "priority": "High",
            "tags": ["login", "regression"]
        }},
        ...
        ]

        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        Input:
        {formatted}
        """.strip()

        response = self.llm_caller(prompt)
        # print("LLM Raw Response:", response)

        try:
            test_cases = extract_clean_json(response)
            # print("Parsed test cases:", test_cases)
        except Exception as e:
            test_cases = []

        return {"test_cases": test_cases}

from typing import List, Dict
import logging

logger = logging.getLogger("RequirementAI")

class TraceabilityAgent:
    def extract_ids_from_test_case_id(self, tc_id: str) -> Dict[str, str]:
        """
        Extract requirement_id and user_story_id from test case ID.
        Expected format: TC-REQ-001-US-001-001
        """
        try:
            parts = tc_id.split("-")
            if len(parts) >= 5 and parts[0] == "TC":
                requirement_id = f"{parts[1]}-{parts[2]}"  # e.g., REQ-001
                user_story_id = f"{parts[3]}-{parts[4]}"  # e.g., US-001
                return {"requirement_id": requirement_id, "user_story_id": user_story_id}
            logger.warning(f"Invalid test case ID format: {tc_id}")
            return {}
        except Exception as e:
            logger.error(f"Error parsing test case ID {tc_id}: {str(e)}")
            return {}

    def run(self, inputs: Dict) -> Dict:
        """
        Build a traceability matrix keyed by requirement_id.
        Expected inputs:
        {
            "classified": [{"requirement_id": "...", "requirement_text": "...", "requirement_type": "...", "confidence_score": float}],
            "validated": [{"requirement_id": "...", "validation": {"llm_check_passed": bool, "issues": [...]}}],
            "user_stories": [{"requirement_id": "...", "user_story_id": "...", "user_story": "...", "acceptance_criteria": [...]}],
            "gherkin_scenarios": [{"requirement_id": "...", "feature": "...", "scenarios": [...]}],
            "test_cases": [{"test_id": "...", ...}]
        }
        """
        logger.info("Starting traceability matrix generation")

        # --- Initialize input dictionaries with safe defaults ---
        classified = {r.get("requirement_id", ""): r for r in inputs.get("classified", []) if r.get("requirement_id")}
        validated = {r.get("requirement_id", ""): r for r in inputs.get("validated", []) if r.get("requirement_id")}
        user_stories = {r.get("requirement_id", ""): r for r in inputs.get("user_stories", []) if r.get("requirement_id")}
        gherkin = {r.get("requirement_id", ""): r for r in inputs.get("gherkin_scenarios", []) if r.get("requirement_id")}
        test_cases = inputs.get("test_cases", [])

        # --- Deduplicate user stories by user_story_id ---
        us_map: Dict[str, List[Dict]] = {}
        seen_us_ids: set = set()
        for us in inputs.get("user_stories", []):
            rid = us.get("requirement_id")
            usid = us.get("user_story_id")
            if rid and usid:
                if (rid, usid) not in seen_us_ids:
                    us_map.setdefault(rid, []).append(us)
                    seen_us_ids.add((rid, usid))
                else:
                    logger.warning(f"Duplicate user story found: requirement_id={rid}, user_story_id={usid}")
            else:
                logger.warning(f"User story missing requirement_id or user_story_id: {us.get('user_story_id', 'unknown')}")

        # --- Index test cases by requirement_id ---
        tc_map: Dict[str, List[Dict]] = {}
        for tc in test_cases:
            ids = self.extract_ids_from_test_case_id(tc.get("test_id", ""))
            rid = ids.get("requirement_id")
            if rid:
                tc_map.setdefault(rid, []).append(tc)
                logger.debug(f"Mapped test case {tc.get('test_id')} to requirement_id={rid}")
            else:
                logger.warning(f"Test case missing valid requirement_id: {tc.get('test_id', 'unknown')}")

        # --- Collect all requirement IDs ---
        all_ids = sorted(set(
            list(classified.keys())
            + list(validated.keys())
            + list(user_stories.keys())
            + list(gherkin.keys())
            + list(tc_map.keys())
        ))

        logger.info(f"Building traceability matrix for {len(all_ids)} requirements")

        traceability = []

        for rid in all_ids:
            logger.debug(f"Processing requirement_id: {rid}")
            # --- Initialize trace entry with defaults ---
            trace = {
                "requirement_id": rid,
                "requirement_text": classified.get(rid, {}).get("requirement_text", ""),
                "requirement_type": classified.get(rid, {}).get("requirement_type", ""),
                "confidence_score": classified.get(rid, {}).get("confidence_score", 0.0),
                "llm_check_passed": validated.get(rid, {}).get("validation", {}).get("llm_check_passed", False),
                "validation_issues": validated.get(rid, {}).get("validation", {}).get("issues", []),
                "gherkin_feature": gherkin.get(rid, {}).get("feature", ""),
                "gherkin_scenarios": gherkin.get(rid, {}).get("scenarios", []),
                "test_cases": tc_map.get(rid, []),
                "user_stories": []
            }

            # --- Add user stories ---
            for us in us_map.get(rid, []):
                us_entry = {
                    "user_story_id": us.get("user_story_id", ""),
                    "user_story": us.get("user_story", ""),
                    "acceptance_criteria": us.get("acceptance_criteria", []),
                    "test_cases": []  # Simplified: test cases are already in trace["test_cases"]
                }
                trace["user_stories"].append(us_entry)

            traceability.append(trace)

        logger.info("Traceability matrix generation completed")
        return {"traceability": traceability}
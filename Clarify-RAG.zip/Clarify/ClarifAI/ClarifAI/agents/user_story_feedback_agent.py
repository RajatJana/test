from typing import Dict, Callable
import logging

from tools.prompt_utils import extract_clean_json
from tools.rag_utils import store_generated_stories, RAG_ENABLED

logger = logging.getLogger(__name__)

class UserStoryFeedbackAgent:
    def __init__(self, llm_caller: Callable[[str], str]):
        self.llm_caller = llm_caller

    def run(self, inputs: Dict) -> Dict:
        story = inputs.get("story", {})
        feedback = inputs.get("feedback", "").strip()

        if not story or not feedback:
            logger.warning("Missing story or feedback in input")
            return {"updated_story": story, "error": "Missing story or feedback"}

        # Build prompt
        prompt = f"""
        You are a senior product owner reviewing a user story.

        Here is the current story:
        User Story ID: {story.get("usid")}
        Title: {story.get("title")}
        Role: {story.get("role")}
        Story: {story.get("story")}
        Description: {story.get("description")}
        Acceptance Criteria:
        {chr(10).join(f"- {ac}" for ac in story.get("acceptanceCriteria", []))}
        T-shirt Size: {story.get("tshirt_size")}
        Priority: {story.get("priority")}
        Tags: {chr(10).join(f"- {tg}" for tg in story.get("tags", []))}
        Confidence Score: {story.get("confidence")}

        User feedback:
        "{feedback}"

        Based on this feedback, revise the user story and acceptance criteria. When revising, carefully consider how the feedback affects the story's complexity and clarity.

        ⦁	Modify ONLY the fields explicitly addressed or implied by the user's feedback.

        ⦁	Leave all other fields, including those not mentioned, completely unchanged.

        ⦁	If the feedback adds detail or clarifies ambiguity, update the Confidence Score accordingly.

        ⦁	If the feedback adds or removes complexity, update the T-shirt Size accordingly.

        ⦁   If the feedback changes anything in description, update the Acceptance Criteria, T-shirt Size, Priority and tags accordingly.

        Respond with raw JSON in the format:
        {{
            "usid": "<updated usid>",
            "title": "<updated title>",
            "role": "<updated role>",
            "story": "<updated user story>",
            "description": <updated description>
            "acceptanceCriteria": ["<updated criteria 1>", "<updated criteria 2>", ...],
            "tshirt_size": "<updated size>",
            "priority": "<updated priority>",
            "tags": ["<updated tag 1>", "<updated tag 2>", ...],
            "confidence": "<keep unchanged>"
        }}

        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object.
        """.strip()

        llm_response = self.llm_caller(prompt)

        try:
            updated = extract_clean_json(llm_response)
        except Exception as e:
            logger.error(f"Failed to parse LLM response: {e}")
            updated = {}

        # RAG: Store feedback-edited stories as higher quality signals
        if RAG_ENABLED and updated:
            try:
                updated_with_flag = dict(updated)
                updated_with_flag["was_edited"] = True
                store_generated_stories([updated_with_flag], source_agent="UserStoryFeedbackAgent")
            except Exception:
                pass  # Silent failure - feedback flow must not be affected

        return {"updated_story": updated or story}

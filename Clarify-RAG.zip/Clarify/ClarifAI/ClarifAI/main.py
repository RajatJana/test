# main.py
import sys
import os

# get the current directory of the file
current_dir = os.path.dirname(os.path.abspath(__file__))
# get the parent directory of the file by going one level up
parent_dir = os.path.dirname(current_dir)

# Add the parent directory to the sys path
if parent_dir not in sys.path:
    sys.path.append(parent_dir)

from agents.extractor_agent import ExtractorAgent
from agents.classifier_agent import ClassifierAgent
from agents.validation_agent import ValidationAgent
from agents.user_story_agent import UserStoryAgent
from agents.gherkin_agent import GherkinAgent
from agents.testcase_agent import TestCaseAgent

from tools.llm_utils import call_gemini
from utils import jira_utils
from itertools import cycle

if __name__ == "__main__":
    file_path = r"C:\137150\MyLabSpace\10-ClarifAI\sample_docs\Sample-BRD.docx"
    
#for key rotation
    api_keys = cycle([os.getenv("GOOGLE_API_KEY_1"), os.getenv("GOOGLE_API_KEY_2")])
    def alternating_llm_caller(prompt):
     key = next(api_keys)
     return call_gemini(prompt, api_key=key)
    
    # agent = ExtractorAgent(llm_caller=call_gemini)
    agent = ExtractorAgent(llm_caller=alternating_llm_caller)  # Use this for key rotation
    extracted = agent.run(file_path)

    from pprint import pprint
    pprint(extracted)
    len(extracted)

    # agent = ClassifierAgent(llm_caller=call_gemini, verbose=True)
    agent = ClassifierAgent(llm_caller=alternating_llm_caller, verbose=True)
    classified = agent.run(extracted)

    # agent = ValidationAgent(llm_caller=call_gemini)
    agent = ValidationAgent(llm_caller=alternating_llm_caller)
    validated = agent.run(classified)

    # agent = UserStoryAgent(llm_caller=call_gemini)
    agent = UserStoryAgent(llm_caller=alternating_llm_caller)
    user_stories = agent.run(validated)

    # RAG: Store generated stories in vector store
    if user_stories.get("user_stories"):
        try:
            from tools.rag_utils import store_generated_stories, RAG_ENABLED
            if RAG_ENABLED:
                req_texts = {r["requirement_id"]: r["requirement_text"] for r in extracted}
                store_generated_stories(
                    user_stories["user_stories"],
                    source_agent="CLI-UserStoryAgent",
                    requirement_texts=req_texts,
                )
        except Exception as e:
            print(f"RAG storage skipped: {e}")

        jira_utils.post_user_stories_to_jira(user_stories["user_stories"])

    # agent = GherkinAgent(llm_caller=call_gemini)
    agent = GherkinAgent(llm_caller=alternating_llm_caller)
    gherkin_scenarios = agent.run(user_stories)

    # agent = TestCaseAgent(llm_caller=call_gemini)
    agent = TestCaseAgent(llm_caller=alternating_llm_caller)
    test_cases_output = agent.run(user_stories)

    test_cases = test_cases_output.get("test_cases", [])
    if test_cases:
       jira_utils.post_test_cases_to_jira(test_cases)
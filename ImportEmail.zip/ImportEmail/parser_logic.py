import os
import uuid
import email
from email import policy

# Configuration
BASE_OUTPUT_DIR = "extracted_data"
os.makedirs(BASE_OUTPUT_DIR, exist_ok=True)

def sanitize_filename(filename):
    if not filename:
        return f"file_{uuid.uuid4().hex[:6]}"
    return "".join([c for c in filename if c.isalnum() or c in "._- "]).strip()

def process_eml(file_path):
    """This is the function uvicorn is looking for."""
    session_id = str(uuid.uuid4())[:8]
    output_subdir = os.path.join(BASE_OUTPUT_DIR, f"mail_{session_id}")
    attach_dir = os.path.join(output_subdir, "attachments")
    os.makedirs(attach_dir, exist_ok=True)

    with open(file_path, 'rb') as f:
        msg = email.message_from_binary_file(f, policy=policy.default)

    metadata = {
        "Subject": msg.get('subject', 'No Subject'),
        "From": msg.get('from', 'Unknown Sender'),
        "To": msg.get('to', 'Unknown Recipient'),
        "Date": msg.get('date', 'Unknown Date')
    }

    body_part = msg.get_body(preferencelist=('plain', 'html'))
    body_content = body_part.get_content() if body_part else "No body content found."

    attachment_list = []
    for part in msg.iter_attachments():
        fname = sanitize_filename(part.get_filename())
        payload = part.get_content()
        if payload:
            save_path = os.path.join(attach_dir, fname)
            mode = "wb" if isinstance(payload, bytes) else "w"
            encoding = None if mode == "wb" else "utf-8"
            with open(save_path, mode, encoding=encoding) as f:
                f.write(payload)
            attachment_list.append(fname)

    meta_body_path = os.path.join(output_subdir, "metadata_and_body.txt")
    with open(meta_body_path, "w", encoding="utf-8") as f:
        f.write("=== EMAIL METADATA ===\n")
        for key, value in metadata.items():
            f.write(f"{key}: {value}\n")
        f.write("\n=== EMAIL BODY ===\n")
        f.write(body_content)

    return {
        "metadata": metadata, 
        "attachments": attachment_list, 
        "saved_location": os.path.abspath(output_subdir)
    }
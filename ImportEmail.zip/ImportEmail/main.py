import os
import uuid
import shutil
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse

# Import the logic from our other file
from parser_logic import process_eml

app = FastAPI(title="EML Parser API")

@app.post("/upload")
async def upload_eml(file: UploadFile = File(...)):
    # 1. Verify extension
    if not file.filename.lower().endswith('.eml'):
        raise HTTPException(status_code=400, detail="Only .eml files are supported.")

    # 2. Setup temp path
    temp_path = f"temp_{uuid.uuid4().hex}_{file.filename}"
    
    try:
        # 3. Save uploaded stream to temp file
        with open(temp_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        # 4. Call the parser logic
        result = process_eml(temp_path)
        return {"status": "success", "result": result}

    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
    
    finally:
        # 5. Cleanup temp file
        if os.path.exists(temp_path):
            os.remove(temp_path)
import os
from dotenv import load_dotenv
from google import genai
from PromptHub import load_prompt  # Assuming this handles your prompt loading logic

# Load variables from the .env file into os.environ
load_dotenv()

class ConverterService:
    def __init__(self, api_key: str = None):
        # Force the client to use the global 'google-ai' universe
        # This bypasses the 'asia-southeast1' regional 0-quota limit
        self.client = genai.Client(
            api_key=api_key or os.getenv("GOOGLE_API_KEY"),
            http_options={'api_version': 'v1beta'} # Uses the newest endpoint features
        )
        # 2026 Pro-Tip: Match the model ID to your 'working' tool exactly
        self.model_id = "gemini-1.5-flash"
# class ConverterService:
#     def __init__(self, api_key: str = None):
#         """
#         Initializes the Gemini client.
#         If no api_key is passed, it automatically looks for GOOGLE_API_KEY in .env
#         """
#         self.client = genai.Client(api_key=api_key or os.getenv("GOOGLE_API_KEY"))
#         # Gemini 3 Flash is optimized for specialized code generation/conversion
#         self.model_id = "gemini-2.5-flash"

    def _generate_response(self, prompt_name: str, **kwargs) -> str:
        """Internal helper to load prompts and generate content."""
        try:
            template = load_prompt(prompt_name)
            prompt = template.format(**kwargs)
            
            response = self.client.models.generate_content(
                model=self.model_id,
                contents=prompt
            )
            
            if not response.text:
                raise ValueError(f"Model returned no text for {prompt_name}")
                
            return response.text.strip()
        except Exception as e:
            print(f"Error in {prompt_name}: {e}")
            return f"Error during conversion: {str(e)}"

    # --- Public Conversion Methods ---

    def interpret_pipeline_structure(self, file_content: str, source: str, target: str) -> str:
        """Interprets pipeline structure for platform transformation."""
        return self._generate_response(
            "interpret_pipeline_structure_prompt.txt",
            file_content=file_content,
            source_platform=source,
            target_platform=target
        )

    def convert_azure_to_jenkins(self, file_content: str, os_env: str) -> str:
        """Converts Azure DevOps pipeline YAML to Jenkins pipeline syntax."""
        print("Processing: Azure -> Jenkins")
        return self._generate_response(
            "convert_azure_to_jenkins_prompt.txt", 
            file_content=file_content, 
            os=os_env
        )

    def convert_jenkins_to_azure(self, file_content: str, os_env: str) -> str:
        """Converts Jenkins pipeline to Azure DevOps format."""
        print("Processing: Jenkins -> Azure")
        return self._generate_response(
            "convert_jenkins_to_azure_prompt.txt", 
            file_content=file_content, 
            os=os_env
        )

    def convert_jenkins_to_gitlab(self, file_content: str, os_env: str) -> str:
        """Converts Jenkins pipeline to GitLab CI YAML."""
        print("Processing: Jenkins -> GitLab")
        return self._generate_response(
            "convert_jenkins_to_gitlab_prompt.txt", 
            file_content=file_content, 
            os=os_env
        )
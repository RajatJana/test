# import os
# from google.adk.runners import Runner
# from google.adk.sessions import InMemorySessionService
# from google.genai import types

# async def run_agent(
#     agent,
#     prompt_text: str,
#     app_name: str = "generic_llm_app",
#     user_id: str = "default_user"
# ) -> str:
#     session_service = InMemorySessionService()
#     session_id = "session_" + os.urandom(4).hex()

#     await session_service.create_session(
#         user_id=user_id,
#         session_id=session_id,
#         app_name=app_name
#     )

#     prompt = types.Content(
#         role="user",
#         parts=[types.Part(text=prompt_text)]
#     )

#     runner = Runner(agent=agent, session_service=session_service, app_name=app_name)
#     generator = runner.run_async(user_id=user_id, session_id=session_id, new_message=prompt)

#     final_output = ""
#     async for event in generator:
#         if event.content and event.content.parts:
#             for part in event.content.parts:
#                 if hasattr(part, "text") and part.text:
#                     final_output += part.text + "\n"
#                 elif hasattr(part, "function_call"):
#                     print("📦 Function call detected")

#     return final_output.strip()

import os
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

async def run_agent(
    agent,
    prompt_text: str,
    app_name: str = "generic_llm_app",
    user_id: str = "default_user"
) -> str:
    session_service = InMemorySessionService()
    session_id = "session_" + os.urandom(4).hex()

    await session_service.create_session(
        user_id=user_id,
        session_id=session_id,
        app_name=app_name
    )

    prompt = types.Content(
        role="user",
        parts=[types.Part(text=prompt_text)]
    )

    runner = Runner(agent=agent, session_service=session_service, app_name=app_name)
    generator = runner.run_async(user_id=user_id, session_id=session_id, new_message=prompt)

    final_output = ""
    async for event in generator:
        if event.content and event.content.parts:
            for part in event.content.parts:
                # Plain text output
                if getattr(part, "text", None):
                    final_output += part.text + "\n"

                # Function call output
                elif getattr(part, "function_call", None):
                    fn_name = part.function_call.name
                    args = part.function_call.args or {}
                    print(f"📦 Function call detected: {fn_name}({args})")

                    # Find the matching tool in the agent
                    tool_fn = None
                    for tool in agent.tools:
                        if tool.__name__ == fn_name:
                            tool_fn = tool
                            break

                    if tool_fn is None:
                        raise ValueError(f"No matching tool found for function: {fn_name}")

                    # Call the tool with unpacked args
                    try:
                        tool_result = tool_fn(**args)
                        # If the tool is async, await it
                        if hasattr(tool_result, "__await__"):
                            tool_result = await tool_result
                        final_output += str(tool_result) + "\n"
                    except Exception as e:
                        raise RuntimeError(f"Error executing tool {fn_name}: {e}")

    return final_output.strip()

# from fastapi import APIRouter, HTTPException
# from pydantic import BaseModel
# from agents.modifier_agent import create_modifier_agent
# from runners.modifier_runner import run_modifier
# router = APIRouter()

# # ✅ Request model
# class ModifierRequest(BaseModel):
#     code: str
#     user_input: str

# # ✅ Response model
# class ModifierResponse(BaseModel):
#     output: str

# # 🔌 API endpoint
# @router.post("/request-change", response_model=ModifierResponse)
# async def connect_to_Modifier(request: ModifierRequest):
#     try:
#         result = await run_modifier(request.code, request.user_input)
#         return ModifierResponse(output=result)
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Modifier error: {str(e)}")

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from agents.ModifierAgent import modifier_agent

router = APIRouter()

# ✅ Request model
class ModifierRequest(BaseModel):
    code: str
    user_input: str

# ✅ Response model
class ModifierResponse(BaseModel):
    output: str

# 🔌 API endpoint
@router.post("/request-change", response_model=ModifierResponse)
async def request_change(request: ModifierRequest):
    try:
        # Direct call to the consolidated agent's method
        result = modifier_agent.modify_pipeline(
            code=request.code, 
            user_input=request.user_input
        )
        
        if "Error:" in result:
            raise HTTPException(status_code=500, detail=result)
            
        return ModifierResponse(output=result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Modifier error: {str(e)}")
# from fastapi import APIRouter, HTTPException
# from pydantic import BaseModel
# from agents.refiner_agent import PipelineRefiner

# router = APIRouter()

# refiner_instance = None  # Global instance

# # Request Models
# class RefinementRequest(BaseModel):
#     pipeline_code: str

# class FeedbackRequest(BaseModel):
#     feedback: str

# # Response Model
# class RefinementSplitResponse(BaseModel):
#     refiner: str
#     devops: str

# @router.post("/start-refinement", response_model=RefinementSplitResponse)
# async def start_refinement(request: RefinementRequest):
#     global refiner_instance
#     try:
#         refiner_instance = PipelineRefiner(request.pipeline_code)
#         result = await refiner_instance.start_session()  # ✅ returns dict with keys
#         return result
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Refiner error: {str(e)}")

# @router.post("/send-feedback", response_model=RefinementSplitResponse)
# async def send_feedback(request: FeedbackRequest):
#     global refiner_instance
#     if refiner_instance is None:
#         raise HTTPException(status_code=400, detail="Refiner session not started.")
#     try:
#         result = await refiner_instance.user_feedback(request.feedback)
#         return result
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Refiner error: {str(e)}")


from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from agents.RefinerAgent import refiner_agent

router = APIRouter()

# Simple in-memory state tracking
current_pipeline_state = {}

class RefinementRequest(BaseModel):
    pipeline_code: str

class FeedbackRequest(BaseModel):
    feedback: str

class RefinementSplitResponse(BaseModel):
    refiner: str
    devops: str

@router.post("/start-refinement", response_model=RefinementSplitResponse)
async def start_refinement(request: RefinementRequest):
    try:
        result = refiner_agent.start_refinement(request.pipeline_code)
        # Store the code for the feedback turn
        current_pipeline_state["session_active"] = result["refiner"]
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Refiner error: {str(e)}")

@router.post("/send-feedback", response_model=RefinementSplitResponse)
async def send_feedback(request: FeedbackRequest):
    # Retrieve the code from the previous turn
    code_to_update = current_pipeline_state.get("session_active")
    if not code_to_update:
        raise HTTPException(status_code=400, detail="Refinement session not started.")
    
    try:
        result = refiner_agent.process_feedback(code_to_update, request.feedback)
        # Update state with new refined version
        current_pipeline_state["session_active"] = result["refiner"]
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Feedback failure: {str(e)}")
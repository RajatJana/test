# # from fastapi import APIRouter, HTTPException
# # from pydantic import BaseModel
# # from typing import Literal
# # import asyncio
# # from runners.converter_runner import run_conversion

# # router = APIRouter()

# # # ✅ Request schema
# # class ConversionRequest(BaseModel):
# #     source_tech: Literal["azure", "jenkins"]
# #     target_tech: Literal["azure", "jenkins"]
# #     pipeline_code: str
# #     input_os: Literal["linux", "windows", "mac"]

# # # ✅ Response schema
# # class ConversionResponse(BaseModel):
# #     converted_code: str

# # # 🔁 Conversion endpoint
# # @router.post("/convert-pipeline", response_model=ConversionResponse)
# # async def convert_pipeline(request: ConversionRequest):
# #     if request.source_tech == request.target_tech:
# #         raise HTTPException(status_code=400, detail="Source and target technologies must be different.")

# #     try:
# #         converted_code = await run_conversion(
# #             source_tech=request.source_tech,
# #             target_tech=request.target_tech,
# #             pipeline_code=request.pipeline_code,
# #             input_os=request.input_os
# #         )
# #         return ConversionResponse(converted_code=converted_code)
# #     except Exception as e:
# #         raise HTTPException(status_code=500, detail=f"Conversion failed: {str(e)}")

# from fastapi import APIRouter, HTTPException
# from pydantic import BaseModel
# from typing import Literal
# from runners.converter_runner import run_conversion

# router = APIRouter()

# # ✅ Request schema
# class ConversionRequest(BaseModel):
#     source_tech: Literal["azure", "jenkins", "gitlab"]
#     target_tech: Literal["azure", "jenkins", "gitlab"]
#     pipeline_code: str
#     input_os: Literal["linux", "windows", "mac"]

# # ✅ Response schema
# class ConversionResponse(BaseModel):
#     converted_code: str

# # 🔁 Conversion endpoint
# @router.post("/convert-pipeline", response_model=ConversionResponse)
# async def convert_pipeline(request: ConversionRequest):
#     if request.source_tech == request.target_tech:
#         raise HTTPException(status_code=400, detail="Source and target technologies must be different.")

#     try:
#         converted_code = await run_conversion(
#             source_tech=request.source_tech,
#             target_tech=request.target_tech,
#             pipeline_code=request.pipeline_code,
#             input_os=request.input_os
#         )
#         return ConversionResponse(converted_code=converted_code)
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Conversion failed: {str(e)}")
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Literal
# Import your new single-file agent
from agents.ConverterAgent import Converter_Agent

router = APIRouter()

# Initialize the agent once at the module level for efficiency
converter_agent = Converter_Agent()

# ✅ Request schema
class ConversionRequest(BaseModel):
    source_tech: Literal["azure", "jenkins", "gitlab"]
    target_tech: Literal["azure", "jenkins", "gitlab"]
    pipeline_code: str
    input_os: Literal["linux", "windows", "mac"]

# ✅ Response schema
class ConversionResponse(BaseModel):
    converted_code: str

# 🔁 Conversion endpoint
@router.post("/convert-pipeline", response_model=ConversionResponse)
async def convert_pipeline(request: ConversionRequest):
    if request.source_tech == request.target_tech:
        raise HTTPException(
            status_code=400, 
            detail="Source and target technologies must be different."
        )

    try:
        # Direct call to your new Agent class method
        # Since this involves an external API call, we use await if you made it async,
        # otherwise call it normally. (The version I provided was sync for simplicity).
        converted_code = converter_agent.convert_pipeline(
            pipeline_code=request.pipeline_code,
            source_tech=request.source_tech,
            target_tech=request.target_tech,
            input_os=request.input_os
        )
        
        # Check if the agent returned an internal error message
        if "Error:" in converted_code:
            raise HTTPException(status_code=500, detail=converted_code)
            
        return ConversionResponse(converted_code=converted_code)
        
    except Exception as e:
        # Standardize the error response for the frontend
        raise HTTPException(status_code=500, detail=f"Conversion failed: {str(e)}")
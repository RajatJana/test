# from fastapi import APIRouter, HTTPException
# from pydantic import BaseModel
# from agents.generator_agent import create_generator_agent
# from runners.generator_runner import run_generation
# from typing import Literal

# router = APIRouter()

# # ✅ Request model
# class PipelineRequest(BaseModel):
#     detected_info: str
#     repo_link: str
#     user_additions: str
#     ci_cd_tool: Literal["azure", "jenkins", "gitlab"]
#     os: str

# # ✅ Response model
# class PipelineResponse(BaseModel):
#     pipeline: str

# # 🔁 Generator Agent Endpoint
# @router.post("/generate-pipeline", response_model=PipelineResponse)
# async def generate_pipeline(request: PipelineRequest):
#     try:
#         # Delegate fully to runner; prompt construction handled internally
#         result = await run_generation(detected_info=request.detected_info,
#             repo_link=request.repo_link,
#             user_additions=request.user_additions,
#             ci_cd_tool=request.ci_cd_tool,
#             os=request.os
#         )

#         return PipelineResponse(pipeline=result.strip())
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Generator agent error: {str(e)}")

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Literal
# Import your consolidated single-file agent
from agents.GeneratorAgent import Generator_Agent

router = APIRouter()

# Initialize the agent once at the module level for efficiency
generator_agent = Generator_Agent()

# ✅ Request model
class PipelineRequest(BaseModel):
    detected_info: str
    repo_link: str
    user_additions: str
    ci_cd_tool: Literal["azure", "jenkins", "gitlab"]
    os: str

# ✅ Response model
class PipelineResponse(BaseModel):
    pipeline: str

# 🔁 Generator Agent Endpoint
@router.post("/generate-pipeline", response_model=PipelineResponse)
async def generate_pipeline(request: PipelineRequest):
    try:
        # Directly call the consolidated generator agent
        # This replaces the complex 'run_generation' runner logic
        result = generator_agent.generate_pipeline(
            detected_info=request.detected_info,
            repo_link=request.repo_link,
            user_additions=request.user_additions,
            ci_cd_tool=request.ci_cd_tool,
            os_env=request.os
        )

        # Check for internal agent errors or quota failures
        if "Error:" in result:
            raise HTTPException(status_code=500, detail=result)

        return PipelineResponse(pipeline=result.strip())
    except Exception as e:
        # Standardize error reporting for the frontend dashboard
        raise HTTPException(status_code=500, detail=f"Generator agent error: {str(e)}")
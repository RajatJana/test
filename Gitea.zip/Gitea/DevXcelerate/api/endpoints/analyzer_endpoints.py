# from fastapi import APIRouter, HTTPException
# from pydantic import BaseModel
# from agents.analyzer_agent import create_analyzer_agent
# from runners.analyzer_runner import run_analyzer

# router = APIRouter()

# # ✅ Request model
# class AnalyzerRequest(BaseModel):
#     repo_link: str

# # ✅ Response model
# class AnalyzerResponse(BaseModel):
#     result: str

# # 🔌 API endpoint
# @router.post("/analyze-codebase", response_model=AnalyzerResponse)
# async def analyze_codebase(request: AnalyzerRequest):
#     try:
#         result = await run_analyzer(request.repo_link)
#         return AnalyzerResponse(result=result)
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Analyzer error: {str(e)}")
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from agents.AnalyzerAgent import Analyzer_Agent

router = APIRouter()
# Initialize once to reuse the client
analyzer_agent = Analyzer_Agent()

class AnalyzerRequest(BaseModel):
    repo_link: str

class AnalyzerResponse(BaseModel):
    result: str

@router.post("/analyze-codebase", response_model=AnalyzerResponse)
async def analyze_codebase(request: AnalyzerRequest):
    try:
        # Direct call to the consolidated agent
        result = await analyzer_agent.analyze_codebase(request.repo_link)
        if "Error:" in result:
            raise HTTPException(status_code=500, detail=result)
        return AnalyzerResponse(result=result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analyzer error: {str(e)}")
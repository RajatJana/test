import os
import shutil
import tempfile
import git
import google.generativeai as genai
from dotenv import load_dotenv
from PromptHub import load_prompt

# ====== CONFIG ======
load_dotenv()
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
model = genai.GenerativeModel("gemini-2.5-flash")

# ====== STEP 1: Clone GitHub Repo ======
def clone_repo(repo_link):
    temp_dir = tempfile.mkdtemp()
    try:
        git.Repo.clone_from(repo_link, temp_dir)
        return temp_dir, None
    except Exception as e:
        shutil.rmtree(temp_dir)
        return None, str(e)

# ====== STEP 2: Extract Representative Files ======
def collect_key_files(project_path, max_files=20, max_chars=5000):
    important_files = []
    extensions = ('.xml', '.gradle', '.txt', '.go', '.sln', '.mod', '.kts', '.yml', '.yaml', 'Dockerfile', '.tf', '.json', '.properties')
    
    for root, dirs, files in os.walk(project_path):
        for file in files:
            filepath = os.path.join(root, file)
            if file.endswith(extensions) or file == 'Dockerfile':
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if content.strip():
                            important_files.append({
                                "name": file,
                                "path": filepath,
                                "content": content[:max_chars]
                            })
                            if len(important_files) >= max_files:
                                return important_files
                except Exception:
                    continue
    return important_files

# ====== STEP 3: Detect Tech ======
# def detect_tech(files_data, repo_link):
#     file_texts = "\n\n".join([f"File: {f['path']}\nContent:\n{f['content']}" for f in files_data])
#     template = load_prompt("detect_tech_prompt.txt")
#     prompt = template.format(files_data=files_data, repo_link=repo_link, file_texts=file_texts)
#     response = model.generate_content(prompt)
#     return response.text.strip()


def analyzer_tool(repo_link: str) -> str:
    project_path, error = clone_repo(repo_link)
    if error:
        return f"Failed to clone repo: {error}"

    if not project_path:
        return "Unknown error occurred while cloning."

    files_data = collect_key_files(project_path)
    if not files_data:
        cleanup(project_path)
        return "No valid config files found for analysis."
    
    file_texts = "\n\n".join([f"File: {f['path']}\nContent:\n{f['content']}" for f in files_data])
    template = load_prompt("detect_tech_prompt.txt")
    prompt = template.format(files_data=files_data, repo_link=repo_link, file_texts=file_texts)
    try:
        response = model.generate_content(prompt)
        return response.text.strip()
    finally:
        cleanup(project_path)

# ====== Optional Cleanup ======
def cleanup(path):
    try:
        shutil.rmtree(path)
    except Exception:
        pass

# ====== SINGLE ENTRY POINT ======
# def analyzer_tool(repo_link: str) -> str:
#     project_path, error = clone_repo(repo_link)
#     if error:
#         return {"status": "error", "message": f"Failed to clone repo: {error}"}

#     if not project_path:
#         return {"status": "error", "message": "Unknown error occurred while cloning."}

#     files_data = collect_key_files(project_path)
#     if not files_data:
#         cleanup(project_path)
#         return {"status": "warning", "message": "No valid config files found for analysis."}

#     try:
#         tech_result = detect_tech(files_data, repo_link)
#         return tech_result
#     finally:
#         cleanup(project_path)
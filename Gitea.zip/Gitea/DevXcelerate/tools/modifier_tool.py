import os
import google.generativeai as genai
from dotenv import load_dotenv
from PromptHub import load_prompt

# ====== CONFIG ======
load_dotenv()
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
model = genai.GenerativeModel("gemini-2.0-flash")

# ====== ======== ======
def modifier_tool(code: str, user_input: str) -> str:

    template = load_prompt("modifier_prompt.txt")
    prompt = template.format(code=code, user_input=user_input)
    response = model.generate_content(prompt)
    return response.text.strip()
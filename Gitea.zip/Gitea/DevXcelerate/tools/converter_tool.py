# import google.generativeai as genai

# from services.converter_service import ConverterService



# # 🔧 Tool function for pipeline conversion
# def convert_pipeline_tool(pipeline_yaml: str, source_tech: str, target_tech: str, input_os: str) -> str:
#     print("🔧 In convert_pipeline_tool function")
#     print("source_tech:", source_tech)
#     print("target_tech:", target_tech)

#     converter = ConverterService()
   
#     source = source_tech.lower().replace(" ", "").replace("_", "")
#     target = target_tech.lower().replace(" ", "").replace("_", "")
#     if "azure" in source and "jenkins" in target:
#         return converter.convert_azure_to_jenkins(pipeline_yaml, input_os)
#     elif "jenkins" in source and "azure" in target:
#         return converter.convert_jenkins_to_azure(pipeline_yaml, input_os)
#     elif "jenkins" in source and "gitlab" in target:  # ✅ NEW case
#         return converter.convert_jenkins_to_gitlab(pipeline_yaml, input_os)
#     else:
#         raise ValueError(f"Unsupported conversion from {source_tech} to {target_tech}")

# 🔧 Updated Tool function for pipeline conversion
from services.converter_service import ConverterService

# Initialize once to reuse the connection/client
converter = ConverterService()

def convert_pipeline_tool(pipeline_yaml: str, source_tech: str, target_tech: str, input_os: str) -> str:
    print(f"🔧 In convert_pipeline_tool: {source_tech} -> {target_tech}")

    # Standardize strings (lowercase and remove extra characters)
    source = "".join(filter(str.isalnum, source_tech.lower()))
    target = "".join(filter(str.isalnum, target_tech.lower()))

    # Route to the correct service method
    if "azure" in source and "jenkins" in target:
        return converter.convert_azure_to_jenkins(pipeline_yaml, input_os)
        
    elif "jenkins" in source and "azure" in target:
        return converter.convert_jenkins_to_azure(pipeline_yaml, input_os)
        
    elif "jenkins" in source and "gitlab" in target:
        return converter.convert_jenkins_to_gitlab(pipeline_yaml, input_os)
        
    else:
        # It's helpful to show exactly what was received in the error
        raise ValueError(f"Unsupported conversion: '{source_tech}' to '{target_tech}'")
# from PromptHub import load_prompt
# import google.generativeai as genai
# import os

# # Set up API key, possibly from environment or securely managed secrets

# def assistant_tool(code: str, user_input: str) -> str:
#     """Agent tool for rerunning code with conversational context."""
#     model = genai.GenerativeModel("gemini-2.0-flash")

#     template = load_prompt("assistant_prompt.txt")
#     prompt = template.format(code=code, user_input=user_input)
#     response = model.generate_content(prompt)
#     return response.text.strip()


import os
from PromptHub import load_prompt
import google.generativeai as genai
from dotenv import load_dotenv
from guardrails import Guard

# Set up API key for Google
load_dotenv()
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

# Define the custom fail callback function for when validation fails
def on_fail(value, failure_result):
    """
    Handles validation failures.
    :param value: The value being validated (user_input, code, etc.)
    :param failure_result: The result of the validation, containing error details
    :return: Error message with validation errors
    """
    # Print the failure result to debug and understand what went wrong
    print(f"Validation failed for value: {value}. Errors: {failure_result}")
    return f"Validation failed for value: {value}. Errors: {failure_result}"

# Initialize Guardrails with BiasCheck validator
guard = Guard().use_many(
    BiasCheck(
        debias_strength=0.5,  # Adjust the debiasing strength as needed
        on_fail=on_fail      # Pass the corrected on_fail function
    )
)

def assistant_tool(code: str, user_input: str) -> str:
    """Validate user input and code using BiasCheck, then run through LLM."""
    
    # 1) Validate user input using Guardrails BiasCheck
    validation_result_input = guard.validate(user_input)
    if validation_result_input:
        print(f"User input validation failed: {validation_result_input}")  # Debugging message
        return validation_result_input  # If validation fails, return the error message
    
    # 2) Validate the code (if necessary, or add additional checks here)
    validation_result_code = guard.validate(code)
    if validation_result_code:
        print(f"Code validation failed: {validation_result_code}")  # Debugging message
        return validation_result_code  # If validation fails, return the error message

    # 3) Process code and user input with the Gemini model if BiasCheck validation passes
    model = genai.GenerativeModel("gemini-2.0-flash")

    # Load prompt template
    template = load_prompt("assistant_prompt.txt")
    prompt = template.format(code=code, user_input=user_input)

    # Generate content using the Gemini model
    response = model.generate_content(prompt)
    generated_text = response.text.strip()

    # Optionally validate the generated content with BiasCheck
    validation_result_generated = guard.validate(generated_text)
    if validation_result_generated:
        print(f"Generated text validation failed: {validation_result_generated}")  # Debugging message
        return validation_result_generated  # Return error if the generated content fails validation

    # Return the safely generated content
    return generated_text
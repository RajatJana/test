import os
import shutil
import tempfile
import git
import time
import stat
import random
from dotenv import load_dotenv
from google import genai
from google.api_core import exceptions
from PromptHub import load_prompt

load_dotenv()

class Analyzer_Agent:
    def __init__(self):
        # 1. Force Global Universe to bypass regional '0' quota traps
        self.client = genai.Client(
            api_key=os.getenv("GOOGLE_API_KEY"),
            http_options={'api_version': 'v1beta'} # Uses global routing
        )
        # Using 1.5-flash for the most consistent quota availability
        self.model_id = "gemini-1.5-flash"

    def _on_rm_error(self, func, path, exc_info):
        """Fixes Windows [WinError 5] Access Denied for .git folders."""
        os.chmod(path, stat.S_IWRITE)
        func(path)

    def _clone_repo(self, repo_link):
        temp_dir = tempfile.mkdtemp()
        try:
            git.Repo.clone_from(repo_link, temp_dir)
            return temp_dir, None
        except Exception as e:
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir, onerror=self._on_rm_error)
            return None, str(e)

    def _collect_key_files(self, project_path, max_files=15, max_chars=3000):
        """Truncated collection to stay under Tokens Per Minute (TPM) limits."""
        important_files = []
        extensions = ('.xml', '.gradle', '.txt', '.go', '.sln', '.mod', '.kts', 
                      '.yml', '.yaml', 'Dockerfile', '.tf', '.json', '.properties')
        for root, _, files in os.walk(project_path):
            if 'node_modules' in root or '.git' in root: continue
            for file in files:
                filepath = os.path.join(root, file)
                if file.endswith(extensions) or file == 'Dockerfile':
                    try:
                        with open(filepath, 'r', encoding='utf-8') as f:
                            content = f.read().strip()
                            if content:
                                rel_path = os.path.relpath(filepath, project_path)
                                important_files.append({"path": rel_path, "content": content[:max_chars]})
                                if len(important_files) >= max_files: return important_files
                    except: continue
        return important_files

    async def analyze_codebase(self, repo_link: str) -> str:
        project_path, error = self._clone_repo(repo_link)
        if error: return f"Error: Failed to clone repo: {error}"

        try:
            files_data = self._collect_key_files(project_path)
            if not files_data: return "Error: No valid configuration files detected."

            partial_reports = []
            # 2. Sequential Processing: One file at a time to prevent burst 429s
            for file_info in files_data:
                file_text = f"File: {file_info['path']}\nContent: {file_info['content']}"
                try:
                    template = load_prompt("detect_tech_prompt.txt")
                    user_prompt = template.format(files_data=[file_info], repo_link=repo_link, file_texts=file_text)
                except:
                    user_prompt = f"Analyze this file for tech stack info: {file_text}"

                # Retry logic for individual file analysis
                for attempt in range(5):
                    try:
                        response = self.client.models.generate_content(
                            model=self.model_id,
                            contents=user_prompt,
                            config={'system_instruction': "You are a Tech Stack Analyzer. Output professional text only."}
                        )
                        if response.text:
                            partial_reports.append(response.text.strip())
                        
                        # 3. MANDATORY THROTTLE: Sleep 2 seconds between every request
                        time.sleep(2)
                        break 
                    except exceptions.ResourceExhausted:
                        wait = (2 ** attempt) + random.uniform(2, 5)
                        print(f"⚠️ Limit hit. Cooling down for {wait:.1f}s...")
                        time.sleep(wait)
                    except Exception as e:
                        print(f"File analysis skipped: {e}")
                        break

            if not partial_reports:
                return "Error: Analysis failed to generate results after retries."

            # Final Summary Step (Optional)
            combined_summary = "\n\n".join(partial_reports)
            return combined_summary

        finally:
            if project_path and os.path.exists(project_path):
                shutil.rmtree(project_path, onerror=self._on_rm_error)
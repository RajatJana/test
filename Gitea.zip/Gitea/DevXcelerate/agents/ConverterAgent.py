import os
import time
import random
from dotenv import load_dotenv
from google import genai
from google.api_core import exceptions
from PromptHub import load_prompt  # Using your custom prompt loader

load_dotenv()

class Converter_Agent:
    def __init__(self):
        # Initializing with System Instructions for strict rule following
        # This acts as the 'preamble' for every conversion
        self.client = genai.Client(
            api_key=os.getenv("GOOGLE_API_KEY"),
            http_options={'api_version': 'v1beta'}
        )
        # Using 1.5-flash for stable quota as confirmed working
        self.model_id = "gemini-2.5-flash"

    def convert_pipeline(self, pipeline_code: str, source_tech: str, target_tech: str, input_os: str) -> str:
        """
        Loads your custom prompt files and executes the conversion with retry logic.
        """
        # 1. Load your existing custom prompt from PromptHub
        # We determine the prompt file based on your tech stack
        prompt_file = f"convert_{source_tech}_to_{target_tech}_prompt.txt"
        
        try:
            template = load_prompt(prompt_file)
            # Formatting with your existing variables
            user_prompt = template.format(
                file_content=pipeline_code, 
                os=input_os
            )
        except Exception as e:
            return f"Error loading prompt {prompt_file}: {str(e)}"

        # 2. System Instruction to enforce 'Code Only' behavior
        system_rules = (
            "You are a DevOps expert. Output ONLY raw code. "
            "STRICTLY forbidden: triple backticks (```), markdown fences, "
            "or explanations."
        )

        # 3. Execution with Exponential Backoff for 429 Errors
        max_retries = 5
        for attempt in range(max_retries):
            try:
                response = self.client.models.generate_content(
                    model=self.model_id,
                    contents=user_prompt,
                    config={'system_instruction': system_rules} # Applies to the entire request
                )
                
                if not response.text:
                    raise ValueError("Empty response from model.")
                
                return response.text.strip()

            except exceptions.ResourceExhausted:
                if attempt < max_retries - 1:
                    wait_time = (2 ** attempt) + random.uniform(0, 1)
                    print(f"⚠️ Quota hit. Retrying in {wait_time:.1f}s...")
                    time.sleep(wait_time)
                    continue
                return "Error: Quota exhausted. Please check AI Studio limits."
            
            except Exception as e:
                return f"An unexpected error occurred: {str(e)}"
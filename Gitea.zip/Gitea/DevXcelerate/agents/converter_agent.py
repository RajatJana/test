# # from google.adk.agents import LlmAgent
# # from tools.converter_tool import convert_pipeline_tool


# # # 🤖 Create LLM Agent using the tool function
# # def create_pipeline_converter_agent():
# #     return LlmAgent(
# #         name="PipelineConverterAgent",
# #         model="gemini-2.5-flash",
# #         tools=[convert_pipeline_tool],
# #         instruction=(
# #             "You convert CI/CD pipelines from one technology to another. "
# #             "Display the converted pipeline code. Always explain your changes clearly."
# #         )
# #     )
# from google.adk.agents import LlmAgent
# from tools.converter_tool import convert_pipeline_tool

# # 🤖 Create LLM Agent using the tool function
# def create_pipeline_converter_agent():
#     return LlmAgent(
#         name="PipelineConverterAgent",
#         model="gemini-2.5-flash",  # upgraded for better reasoning
#         tools=[convert_pipeline_tool],
#         instruction=(
#             "You convert CI/CD pipelines from one technology to another. "
#             "Output only the converted pipeline code in the target format, with no explanations or markdown fences."
#         )
#     )
from google.adk.agents import LlmAgent
from tools.converter_tool import convert_pipeline_tool

# 🤖 Updated LLM Agent for DevXcelerate
def create_pipeline_converter_agent():
    return LlmAgent(
        name="PipelineConverterAgent",
        # Using the latest flagship for agents
        model="gemini-1.5-flash", 
        description="A specialized agent for converting CI/CD pipeline code between platforms (Jenkins, Azure, GitLab).",
        tools=[convert_pipeline_tool],
        instruction=(
            "You are a DevOps automation expert. Your core task is to convert pipeline "
            "definitions. ALWAYS use the 'convert_pipeline_tool' for conversions. "
            "When the tool returns the code, output that code directly. "
            "STRICT RULE: Do NOT add any markdown formatting, triple backticks (```), "
            "or conversational filler like 'Here is your code'. Just the raw code."
        )
    )
import os
import time
import random
from dotenv import load_dotenv
from google import genai
from google.api_core import exceptions

load_dotenv()

class Refiner_Agent:
    def __init__(self):
        # Force global routing to bypass regional '0' quota traps
        self.client = genai.Client(
            api_key=os.getenv("GOOGLE_API_KEY"),
            http_options={'api_version': 'v1beta'}
        )
        self.model_id = "gemini-2.5-flash"
        
        # 🤖 Internal System Rules for Dual-Role refinement
        self.REFINER_RULES = (
            "You are a Pipeline Refiner. Update the CI/CD code based on feedback. "
            "Output ONLY raw updated code. No markdown fences or explanations."
        )
        self.DEVOPS_EXPERT_RULES = (
            "You are a DevOps Expert. Review CI/CD pipelines for security and efficiency. "
            "Provide brief, actionable feedback."
        )

    def _call_gemini_with_retry(self, prompt: str, rules: str) -> str:
        """Internal helper with exponential backoff for 429 quota errors."""
        for attempt in range(5):
            try:
                response = self.client.models.generate_content(
                    model=self.model_id,
                    contents=prompt,
                    config={'system_instruction': rules}
                )
                if not response.text:
                    raise ValueError("Empty response.")
                return response.text.strip()
            except exceptions.ResourceExhausted:
                wait_time = (2 ** attempt) + random.uniform(0, 1)
                print(f"⚠️ Quota hit. Retrying in {wait_time:.1f}s...")
                time.sleep(wait_time)
            except Exception as e:
                return f"Error: {str(e)}"
        return "Error: Max retries reached."

    def start_refinement(self, pipeline_code: str) -> dict:
        """Initial turn: Get first review of the draft."""
        expert_prompt = f"Review this initial pipeline draft and suggest improvements:\n\n{pipeline_code}"
        expert_feedback = self._call_gemini_with_retry(expert_prompt, self.DEVOPS_EXPERT_RULES)
        
        return {
            "refiner": pipeline_code,
            "devops": expert_feedback
        }

    def process_feedback(self, current_code: str, feedback: str) -> dict:
        """Subsequent turns: Update code then review again."""
        # Step 1: Update code (Refiner Role)
        refine_prompt = f"Update this code based on feedback: {feedback}\n\nCode:\n{current_code}"
        updated_code = self._call_gemini_with_retry(refine_prompt, self.REFINER_RULES)

        # Step 2: Review updated code (Expert Role)
        review_prompt = f"Review this updated pipeline version:\n\n{updated_code}"
        expert_review = self._call_gemini_with_retry(review_prompt, self.DEVOPS_EXPERT_RULES)

        return {
            "refiner": updated_code,
            "devops": expert_review
        }

# Global instance
refiner_agent = Refiner_Agent()
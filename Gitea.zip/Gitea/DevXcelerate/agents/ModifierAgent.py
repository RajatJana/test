import os
import time
import random
from dotenv import load_dotenv
from google import genai
from google.api_core import exceptions

load_dotenv()

class Modifier_Agent:
    def __init__(self):
        # Force global routing via v1beta to avoid restricted regional 0-quota traps
        self.client = genai.Client(
            api_key=os.getenv("GOOGLE_API_KEY"),
            http_options={'api_version': 'v1beta'}
        )
        # Using 1.5-flash for stable performance across your DevOps tools
        self.model_id = "gemini-2.5-flash"
        
        # 🤖 Internal System Rules
        self.system_instruction = (
            "You are a CI/CD code expert helping users iteratively modify pipeline files. "
            "Output ONLY the raw updated code. No markdown fences (```), no explanations. "
            "If a request is irrelevant to DevOps, return the original code and ask for a relevant question."
        )

        # 📝 Internal Prompt Template
        self.MODIFIER_PROMPT_TEMPLATE = """
        Original Code: 
        {code}

        User Change Request:
        {user_input}

        Respond with the full updated code only.
        """

    def _call_gemini_with_retry(self, user_prompt: str) -> str:
        """Internal helper with exponential backoff for quota management."""
        max_retries = 5
        for attempt in range(max_retries):
            try:
                response = self.client.models.generate_content(
                    model=self.model_id,
                    contents=user_prompt,
                    config={'system_instruction': self.system_instruction}
                )
                if not response.text:
                    raise ValueError("Model returned an empty response.")
                return response.text.strip()
            except exceptions.ResourceExhausted:
                if attempt < max_retries - 1:
                    # Exponential wait: 2, 4, 8, 16... seconds
                    wait_time = (2 ** attempt) + random.uniform(0, 1)
                    print(f"⚠️ Quota hit (429). Retrying in {wait_time:.1f}s...")
                    time.sleep(wait_time)
                    continue
                return "Error: Quota exhausted. Please check AI Studio limits."
            except Exception as e:
                return f"Error: {str(e)}"
        return "Error: Maximum retries reached."

    def modify_pipeline(self, code: str, user_input: str) -> str:
        """
        Executes the modification logic using the internal prompt template.
        """
        formatted_prompt = self.MODIFIER_PROMPT_TEMPLATE.format(
            code=code, 
            user_input=user_input
        )
        return self._call_gemini_with_retry(formatted_prompt)

# Initialize once at module level for FastAPI efficiency
modifier_agent = Modifier_Agent()
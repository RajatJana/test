import os
import time
import random
from dotenv import load_dotenv
from google import genai
from google.api_core import exceptions

# 1. Setup Environment
load_dotenv()

class Assistant_Agent:
    def __init__(self):
        # Force global routing via v1beta to avoid restricted regional 0-quota traps
        self.client = genai.Client(
            api_key=os.getenv("GOOGLE_API_KEY"),
            http_options={'api_version': 'v1beta'}
        )
        # Using 1.5-flash for stable production performance
        self.model_id = "gemini-2.5-flash"
        
        # 🤖 Internal System Rules
        self.system_instruction = (
            "You are a helpful Senior Software Engineer and DevOps Assistant. "
            "Your goal is to answer user questions accurately based on the provided code context. "
            "Provide detailed, naturally phrased explanations and actionable fixes if required."
        )

    def get_assistance(self, code: str, user_input: str) -> str:
        """
        Processes user questions about a specific codebase with built-in retry logic.
        """
        prompt = (
            f"CONTEXT CODE:\n{code}\n\n"
            f"USER QUESTION: {user_input}\n\n"
            "Analyze the code above and provide a complete, natural response to the question."
        )

        # Exponential Backoff Retry Loop for 429 Errors
        max_retries = 5
        for attempt in range(max_retries):
            try:
                response = self.client.models.generate_content(
                    model=self.model_id,
                    contents=prompt,
                    config={'system_instruction': self.system_instruction}
                )
                
                if not response.text:
                    raise ValueError("Model returned an empty response.")
                
                return response.text.strip()

            except exceptions.ResourceExhausted:
                if attempt < max_retries - 1:
                    # Wait 2, 4, 8, 16... seconds with jitter
                    wait_time = (2 ** attempt) + random.uniform(0, 1)
                    print(f"⚠️ Quota hit (429). Retrying in {wait_time:.1f}s...")
                    time.sleep(wait_time)
                    continue
                return "Error: Quota exhausted. Please try again in a few moments."
            
            except Exception as e:
                return f"An unexpected error occurred: {str(e)}"

# Initialize once at module level for FastAPI efficiency
assistant_agent = Assistant_Agent()
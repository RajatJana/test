import os
import time
import random
from dotenv import load_dotenv
from google import genai
from google.api_core import exceptions

load_dotenv()

class Generator_Agent:
    def __init__(self):
        self.client = genai.Client(
            api_key=os.getenv("GOOGLE_API_KEY"),
            http_options={'api_version': 'v1beta'}
        )
        self.model_id = "gemini-2.5-flash"

        # 🤖 INTERNAL PROMPT TEMPLATES
        self.SPEC_PROMPT_TEMPLATE = """
        Act as a Senior DevOps Architect. Your goal is to create a technical 
        CI/CD specification for the following project:
        
        PROJECT DETAILS: {detected_info}
        REPO LINK: {repo_link}
        USER REQUIREMENTS: {user_additions}
        
        TASK:
        1. Identify the build, test, and deployment stages required.
        2. Specify the necessary environment variables and secrets.
        3. Define the optimal runner/agent configuration for this stack.
        
        Output a clear, structured technical specification.
        """

        self.PIPELINE_PROMPT_TEMPLATE = """
        Act as a DevOps Expert. Generate a production-ready {ci_cd_tool} pipeline 
        for a {os_env} environment based on the following specification:
        
        TECHNICAL SPEC: {specification}
        PROJECT DETAILS: {detected_info}
        USER REQUIREMENTS: {user_additions}
        
        STRICT RULES:
        - Use modern, optimized {ci_cd_tool} syntax.
        - Include stages for security scanning (SAST) and linting.
        - Output ONLY the raw code. No markdown fences (```) or explanations.
        """

    def _call_gemini_with_retry(self, user_prompt: str, system_rules: str) -> str:
        """Internal helper with exponential backoff for quota management."""
        max_retries = 5
        for attempt in range(max_retries):
            try:
                response = self.client.models.generate_content(
                    model=self.model_id,
                    contents=user_prompt,
                    config={'system_instruction': system_rules}
                )
                if not response.text:
                    raise ValueError("Empty response from model.")
                return response.text.strip()
            except exceptions.ResourceExhausted:
                if attempt < max_retries - 1:
                    wait_time = (2 ** attempt) + random.uniform(0, 1)
                    time.sleep(wait_time)
                    continue
                return "Error: Quota exhausted. Please check AI Studio limits."
            except Exception as e:
                return f"Error: {str(e)}"
        return "Error: Maximum retries reached."

    def generate_pipeline(self, detected_info: str, repo_link: str, user_additions: str, ci_cd_tool: str, os_env: str) -> str:
        """
        Executes the two-step generation process using internal prompts.
        """
        # --- Step 1: Generate Specification ---
        spec_prompt = self.SPEC_PROMPT_TEMPLATE.format(
            detected_info=detected_info, 
            repo_link=repo_link, 
            user_additions=user_additions or "None"
        )
        spec_rules = "You are a DevOps Architect. Generate a clear technical CI/CD specification."
        specification = self._call_gemini_with_retry(spec_prompt, spec_rules)
        
        if "Error:" in specification:
            return specification

        # --- Step 2: Generate Final Pipeline Code ---
        pipeline_prompt = self.PIPELINE_PROMPT_TEMPLATE.format(
            detected_info=detected_info, 
            repo_link=repo_link, 
            user_additions=user_additions or "None", 
            ci_cd_tool=ci_cd_tool, 
            specification=specification, 
            os_env=os_env
        )
        code_rules = "You are a DevOps expert. Output ONLY raw pipeline code. No markdown, no explanations."

        return self._call_gemini_with_retry(pipeline_prompt, code_rules)
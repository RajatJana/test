import google.generativeai as genai
import os
import sys
import json
import requests
from openai import AzureOpenAI
from utils.logger import get_logger

logger = get_logger()


def get_config_path():
   
    if getattr(sys, 'frozen', False):
    
        base_path = os.path.dirname(sys.executable)
    else:
      
        base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    return os.path.join(base_path, "config.json")


def load_config():

    config_path = get_config_path()
    
   
    if not os.path.exists(config_path):
        error_msg = f"""
========================================
ERROR: Config File Not Found!
========================================
Please create a file named 'config.json' 
in the same folder as ClarifAI.exe

File location expected: {config_path}

The file should contain:
{{
    "model_name": "Model_name",
    "llm_model": "your_llm_model_here",
    "api_key": "your_api_key_here"(if it need api key),
    "base_url": "your_base_url_here"(if it need base url)
}}

========================================
"""
        print(error_msg)
        return None
    
   
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            content = f.read().strip()
        
        if not content:
            error_msg = f"""
========================================
ERROR: Config File is Empty!
========================================
The file 'config.json' exists but is empty.

Please add your configuration in JSON format.

File location: {config_path}
========================================
"""
            print(error_msg)
            return None
        
        config = json.loads(content)
        
      
        if "model_name" not in config:
            error_msg = """
========================================
ERROR: Missing 'model_name' in config.json!
========================================
The config.json must include a 'model_name' field.
========================================
"""
            print(error_msg)
            return None
        
        model_name = config["model_name"].lower()
        
        if model_name not in ("gemini", "gemma", "azure_openai"):
            error_msg = f"""
========================================
ERROR: Unsupported model_name '{config["model_name"]}'!
========================================
Supported: "gemini", "gemma", "azure_openai"
========================================
"""
            print(error_msg)
            return None
        
        model_config = config.get(model_name, {})
        
        
        if model_name == "gemini":
            api_key = model_config.get("api_key", "").strip()
            if not api_key or api_key == "YOUR_API_KEY_HERE" or api_key == "<YOUR API KEY>":
                error_msg = f"""
========================================
ERROR: Invalid API Key in '{model_name}' section!
========================================
Please set a valid api_key in the "{model_name}" 
section of config.json.

File location: {config_path}
========================================
"""
                print(error_msg)
                return None
        
        elif model_name == "gemma":
            base_url = model_config.get("base_url", "").strip()
            if not base_url:
                error_msg = f"""
========================================
ERROR: Missing base_url in 'gemma' section!
========================================
Please set a valid base_url in the "gemma" 
section of config.json.

File location: {config_path}
========================================
"""
                print(error_msg)
                return None
        
        elif model_name == "azure_openai":
            api_key = model_config.get("api_key", "").strip()
            base_url = model_config.get("base_url", "").strip()
            api_version = model_config.get("api_version", "").strip()
            if not api_key or api_key == "YOUR_API_KEY_HERE":
                error_msg = f"""
========================================
ERROR: Invalid API Key for Azure OpenAI!
========================================
File location: {config_path}

Format:
{{
    "model_name": "azure_openai",
    "llm_model": "your-deployment-name",
    "api_key": "your_azure_api_key",
    "base_url": "https://your-resource.openai.azure.com",
    "api_version": "2024-08-01-preview"
}}
========================================
"""
                print(error_msg)
                return None
            if not base_url:
                error_msg = f"""
========================================
ERROR: Missing base_url for Azure OpenAI!
========================================
base_url (Azure endpoint) is required.

File location: {config_path}
========================================
"""
                print(error_msg)
                return None
            if not api_version:
                error_msg = f"""
========================================
ERROR: Missing api_version for Azure OpenAI!
========================================
api_version is required (e.g. "2024-08-01-preview").

File location: {config_path}
========================================
"""
                print(error_msg)
                return None
        
        logger.info(f"[load_config] Config loaded successfully. Model: {model_name}")
        return config
    
    except json.JSONDecodeError as e:
        error_msg = f"""
========================================
ERROR: Invalid JSON in config.json!
========================================
Failed to parse config.json: {str(e)}

File location: {config_path}

Please ensure the file contains valid JSON.
========================================
"""
        print(error_msg)
        return None
    
    except Exception as e:
        error_msg = f"""
========================================
ERROR: Failed to Read Config File!
========================================
Error: {str(e)}

File location: {config_path}
========================================
"""
        print(error_msg)
        return None




CONFIG = load_config()
if not CONFIG:
    input("Press Enter to exit...")
    sys.exit(1)

MODEL_NAME = CONFIG["model_name"].lower()
MODEL_CONFIG = CONFIG.get(MODEL_NAME, {})

GEMINI_API_KEY = MODEL_CONFIG.get("api_key", "").strip()
BASE_URL = MODEL_CONFIG.get("base_url", "").strip()
API_VERSION = MODEL_CONFIG.get("api_version", "").strip()
LLM_MODEL = MODEL_CONFIG.get("llm_model", MODEL_NAME).strip()


if MODEL_NAME == "gemini":
    genai.configure(api_key=GEMINI_API_KEY)



def call_gemini(prompt: str, api_key: str = None, model: str = None) -> str:
  
    logger.info(f"[call_gemini] Calling llm with model set as {model or LLM_MODEL}")

  
    api_key_to_use = api_key or GEMINI_API_KEY
    genai.configure(api_key=api_key_to_use)
    model_name = model or LLM_MODEL
    model_obj = genai.GenerativeModel(model_name)
    response = model_obj.generate_content(
        prompt,
        generation_config=genai.types.GenerationConfig(
            temperature=0.0
        )
    )

    return response.text


def call_gemma(prompt: str) -> str:
    logger.info(f"[call_gemma] Calling Gemma model at {BASE_URL}")

    payload = {
        "user_message": prompt,
        "sender_id": "",
        "prompt": []
    }

    try:
        result = requests.post(BASE_URL, json=payload)
        result.raise_for_status()
        response = json.loads(result.content)["content"]
        return response
    except requests.exceptions.ConnectionError:
        error_msg = f"Failed to connect to Gemma server at {BASE_URL}. Is the server running?"
        logger.error(f"[call_gemma] {error_msg}")
        raise ConnectionError(error_msg)
    except requests.exceptions.RequestException as e:
        error_msg = f"HTTP request to Gemma server failed: {str(e)}"
        logger.error(f"[call_gemma] {error_msg}")
        raise RuntimeError(error_msg)
    except (json.JSONDecodeError, KeyError) as e:
        error_msg = f"Failed to parse Gemma server response: {str(e)}"
        logger.error(f"[call_gemma] {error_msg}")
        raise RuntimeError(error_msg)


def call_azure_openai(prompt: str) -> str:
  
    logger.info(f"[call_azure_openai] Calling Azure OpenAI, model: {LLM_MODEL}")

    try:
        client = AzureOpenAI(
            api_key=GEMINI_API_KEY,
            api_version=API_VERSION,
            azure_endpoint=BASE_URL,
        )

        response = client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.0,
        )

        return response.choices[0].message.content
    except Exception as e:
        error_msg = f"Azure OpenAI request failed: {str(e)}"
        logger.error(f"[call_azure_openai] {error_msg}")
        raise RuntimeError(error_msg)




def call_llm(prompt: str, api_key: str = None, model: str = None) -> str:

    if MODEL_NAME == "gemini":
        return call_gemini(prompt, api_key=api_key, model=model)
    elif MODEL_NAME == "gemma":
        return call_gemma(prompt)
    elif MODEL_NAME == "azure_openai":
        return call_azure_openai(prompt)
    else:
        raise ValueError(f"Unsupported model: {MODEL_NAME}")
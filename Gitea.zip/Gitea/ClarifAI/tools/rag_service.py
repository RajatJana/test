"""
RAG Service for User Story Generation
Handles ChromaDB integration for storing and retrieving examples
"""
import chromadb
from chromadb.config import Settings
from typing import List, Dict, Optional, Any
import logging
import os
import json

logger = logging.getLogger("RequirementAI")


class RAGService:
    """
    Singleton service for managing RAG operations with ChromaDB.
    Supports two collections:
    - requirements_collection: For requirements-based user story generation
    - wireframe_collection: For wireframe-based user story generation
    """
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(RAGService, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
            
        # Initialize ChromaDB client with persistent storage
        db_path = os.path.join(os.getcwd(), "chroma_db")
        os.makedirs(db_path, exist_ok=True)
        
        self.client = chromadb.PersistentClient(
            path=db_path,
            settings=Settings(
                anonymized_telemetry=False,
                allow_reset=True
            )
        )
        
        logger.info(f"ChromaDB initialized at: {db_path}")
        self._initialized = True
    
    def initialize_collection(self, collection_name: str):
        """
        Create or get a collection by name.
        
        Args:
            collection_name: Name of the collection (e.g., 'requirements_collection', 'wireframe_collection')
        
        Returns:
            ChromaDB collection object
        """
        try:
            collection = self.client.get_or_create_collection(
                name=collection_name,
                metadata={"hnsw:space": "cosine"}  # Use cosine similarity
            )
            logger.info(f"Collection '{collection_name}' initialized. Current count: {collection.count()}")
            return collection
        except Exception as e:
            logger.error(f"Failed to initialize collection '{collection_name}': {e}")
            raise
    
    def store_example(
        self,
        collection_name: str,
        requirement_text: str,
        user_story_data: Dict[str, Any]
    ) -> None:
        """
        Store a requirement/chunk → user story mapping in ChromaDB.
        
        Args:
            collection_name: Name of the collection to store in
            requirement_text: The requirement text or chunk (used for embedding)
            user_story_data: The generated user story data (stored as metadata)
        """
        try:
            collection = self.initialize_collection(collection_name)
            
            # Generate a unique ID based on requirement text hash
            doc_id = f"{collection_name}_{hash(requirement_text)}"
            
            # Store the example
            collection.add(
                documents=[requirement_text],
                metadatas=[{
                    "user_story_id": user_story_data.get("user_story_id", ""),
                    "title": user_story_data.get("title", ""),
                    "user_story": user_story_data.get("user_story", ""),
                    "description": user_story_data.get("Description/Note", user_story_data.get("description", "")),
                    "acceptance_criteria": json.dumps(user_story_data.get("acceptance_criteria", [])),
                    "tags": json.dumps(user_story_data.get("Tags/Labels", user_story_data.get("tags", []))),
                    "tshirt_size": user_story_data.get("tshirt_size", ""),
                    "priority": user_story_data.get("priority", ""),
                    "confidence_score": str(user_story_data.get("confidence_score", 0.0))
                }],
                ids=[doc_id]
            )
            
            logger.info(f"✅ Stored example in '{collection_name}': {user_story_data.get('user_story_id', 'N/A')}")
            
        except Exception as e:
            logger.error(f"Failed to store example in '{collection_name}': {e}")
    
    def update_example(
        self,
        collection_name: str,
        user_story_id: str,
        requirement_text: str,
        updated_user_story_data: Dict[str, Any]
    ) -> bool:
        """
        Update an existing user story in ChromaDB.
        
        Args:
            collection_name: Name of the collection
            user_story_id: The user story ID to update
            requirement_text: The requirement text (used for embedding)
            updated_user_story_data: The updated user story data
        
        Returns:
            True if update was successful, False otherwise
        """
        try:
            collection = self.initialize_collection(collection_name)
            
            # Generate the same ID format used in store_example
            doc_id = f"{collection_name}_{hash(requirement_text)}"
            
            # Check if the document exists
            try:
                existing = collection.get(ids=[doc_id])
                if not existing or not existing['ids']:
                    logger.warning(f"⚠️  Document not found for update: {user_story_id}")
                    # If not found, store as new
                    self.store_example(collection_name, requirement_text, updated_user_story_data)
                    return True
            except Exception:
                # If get fails, store as new
                print(f"\n⚠️  Document not found, storing as new: {user_story_id}")
                self.store_example(collection_name, requirement_text, updated_user_story_data)
                return True
            
            # Update the document
            collection.update(
                ids=[doc_id],
                documents=[requirement_text],
                metadatas=[{
                    "user_story_id": updated_user_story_data.get("user_story_id", updated_user_story_data.get("usid", "")),
                    "title": updated_user_story_data.get("title", ""),
                    "user_story": updated_user_story_data.get("user_story", updated_user_story_data.get("story", "")),
                    "description": updated_user_story_data.get("Description/Note", updated_user_story_data.get("description", "")),
                    "acceptance_criteria": json.dumps(updated_user_story_data.get("acceptance_criteria", updated_user_story_data.get("acceptanceCriteria", []))),
                    "tags": json.dumps(updated_user_story_data.get("Tags/Labels", updated_user_story_data.get("tags", []))),
                    "tshirt_size": updated_user_story_data.get("tshirt_size", ""),
                    "priority": updated_user_story_data.get("priority", ""),
                    "confidence_score": str(updated_user_story_data.get("confidence_score", updated_user_story_data.get("confidence", 0.0)))
                }]
            )
            
            print(f"\n✅ Updated example in ChromaDB collection '{collection_name}': {user_story_id}")
            logger.info(f"✅ Updated example in '{collection_name}': {user_story_id}")
            return True
            
        except Exception as e:
            print(f"\n❌ Failed to update example in '{collection_name}': {e}")
            logger.error(f"Failed to update example in '{collection_name}': {e}")
            return False
    
    def delete_example(
        self,
        collection_name: str,
        requirement_text: str
    ) -> bool:
        """
        Delete an example from ChromaDB.
        
        Args:
            collection_name: Name of the collection
            requirement_text: The requirement text (used to generate ID)
        
        Returns:
            True if deletion was successful, False otherwise
        """
        try:
            collection = self.initialize_collection(collection_name)
            
            # Generate the same ID format used in store_example
            doc_id = f"{collection_name}_{hash(requirement_text)}"
            
            collection.delete(ids=[doc_id])
            
            logger.info(f"✅ Deleted example from '{collection_name}'")
            return True
            
        except Exception as e:
            logger.error(f"Failed to delete example from '{collection_name}': {e}")
            return False

    def get_story_by_id(
        self,
        collection_name: str,
        user_story_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Get a user story from ChromaDB by its ID.
        
        Args:
            collection_name: Name of the collection
            user_story_id: The user story ID to retrieve
        
        Returns:
            Dictionary with story data if found, None otherwise
        """
        try:
            collection = self.initialize_collection(collection_name)
            
            if collection.count() == 0:
                return None
            
            # Get all documents and search for matching ID
            results = collection.get()
            
            if results and results['metadatas']:
                for i, metadata in enumerate(results['metadatas']):
                    if metadata.get("user_story_id") == user_story_id:
                        return {
                            "requirement_text": results['documents'][i],
                            "user_story_id": metadata.get("user_story_id", ""),
                            "title": metadata.get("title", ""),
                            "user_story": metadata.get("user_story", ""),
                            "description": metadata.get("description", ""),
                            "acceptance_criteria": json.loads(metadata.get("acceptance_criteria", "[]")),
                            "tags": json.loads(metadata.get("tags", "[]")),
                            "tshirt_size": metadata.get("tshirt_size", ""),
                            "priority": metadata.get("priority", ""),
                            "confidence_score": metadata.get("confidence_score", "0.0")
                        }
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting story by ID: {e}")
            return None


    def find_requirement_by_story(
        self,
        collection_name: str,
        user_story_id: str,
        user_story_text: str
    ) -> Optional[str]:
        """
        Find the original requirement text by comparing user story text in metadata.
        Since ChromaDB stores requirement text as documents, we need to search metadata.
        
        Args:
            collection_name: Name of the collection to search
            user_story_id: The user story ID (for logging purposes)
            user_story_text: The user story text to match against stored metadata
        
        Returns:
            The requirement text if found, None otherwise
        """
        try:
            collection = self.initialize_collection(collection_name)
            
            if collection.count() == 0:
                print(f"\n⚠️  Collection '{collection_name}' is empty")
                return None
            
            # Get all documents and their metadata
            results = collection.get()
            
            if not results or not results['metadatas']:
                print(f"\n⚠️  No documents found in collection '{collection_name}'")
                return None
            
            # Search through metadata to find matching user story text
            best_match_idx = None
            best_similarity = 0.0
            
            for i, metadata in enumerate(results['metadatas']):
                stored_story = metadata.get("user_story", "")
                
                # Simple text similarity - check if stories match closely
                # Normalize and compare
                stored_normalized = stored_story.lower().strip()
                query_normalized = user_story_text.lower().strip()
                
                # Exact match
                if stored_normalized == query_normalized:
                    best_match_idx = i
                    best_similarity = 1.0
                    break
                
                # Partial match - calculate simple similarity
                if stored_normalized and query_normalized:
                    # Check if one contains the other or significant overlap
                    if stored_normalized in query_normalized or query_normalized in stored_normalized:
                        similarity = 0.9
                        if similarity > best_similarity:
                            best_similarity = similarity
                            best_match_idx = i
            
            if best_match_idx is not None:
                requirement_text = results['documents'][best_match_idx]
                stored_story = results['metadatas'][best_match_idx].get("user_story", "")
                stored_id = results['metadatas'][best_match_idx].get("user_story_id", "")
                
                print(f"\n✅ Found matching user story in ChromaDB")
                print(f"   User Story ID: {stored_id}")
                print(f"   Match Confidence: {best_similarity:.2%}")
                print(f"   Stored Story: {stored_story[:80]}...")
                print(f"   Requirement: {requirement_text[:100]}...")
                
                return requirement_text
            
            print(f"\n⚠️  Could not find matching user story in ChromaDB")
            print(f"   Searched for: {user_story_text[:80]}...")
            return None
            
        except Exception as e:
            print(f"\n❌ Error finding requirement text: {e}")
            logger.error(f"Error finding requirement text: {e}")
            return None

    def retrieve_examples(
        self,
        collection_name: str,
        query_text: str,
        top_k: int = 1
    ) -> List[Dict[str, Any]]:
        """
        Retrieve similar examples from ChromaDB based on query text.
        
        Args:
            collection_name: Name of the collection to query
            query_text: The requirement text or chunk to find similar examples for
            top_k: Number of examples to retrieve
        
        Returns:
            List of example dictionaries with metadata
        """
        try:
            collection = self.initialize_collection(collection_name)
            
            # Check if collection has any data
            if collection.count() == 0:
                logger.info(f"⚠️  Collection '{collection_name}' is empty. No examples to retrieve.")
                return []
            
            # Query the collection
            results = collection.query(
                query_texts=[query_text],
                n_results=min(top_k, collection.count())
            )
            
            # Parse results
            examples = []
            if results and results['metadatas'] and len(results['metadatas'][0]) > 0:
                for i, metadata in enumerate(results['metadatas'][0]):
                    example = {
                        "requirement_text": results['documents'][0][i],
                        "user_story_id": metadata.get("user_story_id", ""),
                        "title": metadata.get("title", ""),
                        "user_story": metadata.get("user_story", ""),
                        "description": metadata.get("description", ""),
                        "acceptance_criteria": json.loads(metadata.get("acceptance_criteria", "[]")),
                        "tags": json.loads(metadata.get("tags", "[]")),
                        "tshirt_size": metadata.get("tshirt_size", ""),
                        "priority": metadata.get("priority", ""),
                        "confidence_score": float(metadata.get("confidence_score", 0.0)),
                        "distance": results['distances'][0][i] if results.get('distances') else 0.0
                    }
                    examples.append(example)
                
                logger.info(f"🔍 Retrieved {len(examples)} example(s) from '{collection_name}' for query")
            else:
                logger.info(f"⚠️  No similar examples found in '{collection_name}'")
            
            return examples
            
        except Exception as e:
            logger.error(f"Failed to retrieve examples from '{collection_name}': {e}")
            return []
    
    def rank_and_select_top_examples(
        self,
        all_examples: List[List[Dict[str, Any]]],
        top_n: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Rank all retrieved examples and select the top N.
        
        Args:
            all_examples: List of example lists (one list per requirement/chunk)
            top_n: Number of top examples to select
        
        Returns:
            List of top N examples sorted by distance (lower is better)
        """
        # Flatten all examples into a single list
        flattened = []
        for example_list in all_examples:
            flattened.extend(example_list)
        
        if not flattened:
            logger.info("⚠️  No examples to rank")
            return []
        
        # Sort by distance (lower distance = more similar)
        ranked = sorted(flattened, key=lambda x: x.get('distance', float('inf')))
        
        # Select top N
        top_examples = ranked[:top_n]
        
        logger.info(f"📊 Ranked {len(flattened)} total examples, selected top {len(top_examples)}")
        
        return top_examples
    
    def format_examples_for_prompt(self, examples: List[Dict[str, Any]]) -> str:
        """
        Format retrieved examples into a string for prompt augmentation.
        
        Args:
            examples: List of example dictionaries
        
        Returns:
            Formatted string with examples
        """
        if not examples:
            return ""
        
        formatted_parts = ["Here are some examples of high-quality user stories from previous runs:\n"]
        
        for i, example in enumerate(examples, 1):
            formatted_parts.append(f"\n--- Example {i} ---")
            formatted_parts.append(f"Requirement: {example['requirement_text']}")
            formatted_parts.append(f"User Story ID: {example['user_story_id']}")
            formatted_parts.append(f"Title: {example['title']}")
            formatted_parts.append(f"User Story: {example['user_story']}")
            if example.get('description'):
                formatted_parts.append(f"Description: {example['description']}")
            formatted_parts.append(f"Acceptance Criteria:")
            for criterion in example['acceptance_criteria']:
                formatted_parts.append(f"  - {criterion}")
            if example.get('tags'):
                formatted_parts.append(f"Tags: {', '.join(example['tags'])}")
            formatted_parts.append(f"T-shirt Size: {example['tshirt_size']}")
            formatted_parts.append(f"Priority: {example['priority']}")
        
        formatted_parts.append("\n--- End of Examples ---\n")
        
        return "\n".join(formatted_parts)

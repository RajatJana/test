from fastapi import APIRouter, HTTPException, Body
from pydantic import BaseModel
from typing import List, Dict, Optional, Any,Annotated
from fastapi.responses import FileResponse
from fastapi import UploadFile, File, Form
import os
import shutil
import uuid
import tempfile, yaml
from agents.extractor_agent import ExtractorAgent
from agents.image_extractor_agent import ImageExtractorAgent
from agents.requirement_user_story_agent import RequirementUserStoryAgent
from agents.classifier_agent import ClassifierAgent
from agents.validation_agent import ValidationAgent
from agents.user_story_agent import UserStoryAgent
from agents.user_story_feedback_agent import UserStoryFeedbackAgent
from agents.gherkin_agent import GherkinAgent
from agents.testcase_agent import TestCaseAgent
from agents.traceability_agent import TraceabilityAgent
from agents.new_traceability_agent import NewTraceabilityAgent
from agents.acceptance_criteria_update_agent import AcceptanceCriteriaUpdateAgent
from tools.llm_utils import call_llm
from tools.rag_service import RAGService
from utils.jira_utils import post_user_stories_to_jira, post_test_cases_to_jira
from utils.export_us import export_user_stories_to_excel
from utils.export_tc import export_test_cases_to_excel

router = APIRouter()

# Initialize RAG service (singleton)
rag_service = RAGService()


###########################################################################

# @router.post("/extract-info")
# async def extract_info(file: UploadFile = File(...)):
#     agent = ImageExtractorAgent()
#     try:
#         file_bytes = await file.read()
#         result = agent.run(file_bytes, file.filename)
#         return result  # {"raw_info": "..."}
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))
@router.post("/extract-info")
async def extract_info(files: Annotated[List[UploadFile], File(...)]):
    agent = ImageExtractorAgent()
    combined_info = []
    errors = []
    
    for file in files:
        try:
            file_bytes = await file.read()
            result = agent.run(file_bytes, file.filename)
            extracted_info = result.get("raw_info", "")
            if not isinstance(extracted_info, str):
                extracted_info = str(extracted_info)  # Convert non-string to string
            combined_info.append(f"--- {file.filename} ---\n{extracted_info}")
        except Exception as e:
            errors.append(f"Error processing {file.filename}: {str(e)}")
    
    # Combine all extracted info into a single string
    final_output = "\n\n".join(combined_info)
    if errors:
        final_output += "\n\n--- Errors ---\n" + "\n".join(errors)
    
    return {"raw_info": final_output}
###########################################################################
UPLOAD_DIR = "/tmp/reference_docs"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.post("/generate-userstory")
async def generate_userstory(
    raw_info: Annotated[str, Form(...)],
    files: Annotated[Optional[List[UploadFile]], File()] = None
):
    """
    Generate user stories from raw_info and optional reference documents.
    - raw_info: required text from UI/UX extraction
    - files: optional list of PDF/DOCX uploads
    """

    reference_paths = []
    if files:
        for f in files:
            try:
                ext = os.path.splitext(f.filename)[1]
                safe_name = f"{uuid.uuid4().hex}{ext}"
                file_path = os.path.join(UPLOAD_DIR, safe_name)

                with open(file_path, "wb") as buffer:
                    shutil.copyfileobj(f.file, buffer)

                reference_paths.append(file_path)
            except Exception as e:
                raise HTTPException(
                    status_code=400,
                    detail=f"Failed to save file {f.filename}: {e}"
                )

    agent = RequirementUserStoryAgent(llm_caller=call_llm, rag_service=rag_service)

    try:
        result = agent.run({
            "raw_info": raw_info,
            "reference_docs": reference_paths  # optional param
        })
        return result  # {"user_stories": [...]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
# class RawInfoRequest(BaseModel):
#     raw_info: str

# @router.post("/generate-userstory")
# async def generate_userstory(request: RawInfoRequest):
#     agent = RequirementUserStoryAgent(llm_caller=call_gemini)
#     try:
#         result = agent.run({"raw_info": request.raw_info})
#         return result  # {"user_stories": [...]}
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))
###########################################################################
# Single API for both extract-and-generate

# @router.post("/extract-and-generate")
# async def extract_and_generate(
#     image_file: UploadFile = File(..., description="UI/UX screenshot or image"),
#     reference_files: Optional[List[UploadFile]] = File(None, description="Optional reference docs (PDF/DOCX)")
# ):
#     """
#     1. Extract raw_info from image_file
#     2. Optionally process reference_files
#     3. Generate user stories
#     """

#     # Step 1: Extract info from image
#     agent_extractor = ImageExtractorAgent()
#     try:
#         image_bytes = await image_file.read()
#         raw_info_result = agent_extractor.run(image_bytes, image_file.filename)
#         raw_info = raw_info_result.get("raw_info") if isinstance(raw_info_result, dict) else raw_info_result

#         if not raw_info or not str(raw_info).strip():
#             raise HTTPException(status_code=400, detail="No raw_info extracted from image.")
#     except HTTPException:
#         raise
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Image extraction failed: {e}")

#     # Step 2: Save optional reference docs
#     reference_paths = []
#     if reference_files:
#         for f in reference_files:
#             try:
#                 ext = os.path.splitext(f.filename)[1]
#                 safe_name = f"{uuid.uuid4().hex}{ext}"
#                 file_path = os.path.join(UPLOAD_DIR, safe_name)

#                 with open(file_path, "wb") as buffer:
#                     shutil.copyfileobj(f.file, buffer)

#                 reference_paths.append(file_path)
#             except Exception as e:
#                 raise HTTPException(status_code=400, detail=f"Failed to save file {f.filename}: {e}")

#     # Step 3: Generate user stories
#     agent_userstory = RequirementUserStoryAgent(llm_caller=call_gemini)
#     try:
#         result = agent_userstory.run({
#             "raw_info": raw_info,
#             "reference_docs": reference_paths
#         })
#         return result  # {"user_stories": [...]}
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"User story generation failed: {e}")
@router.post("/extract-and-generate")
async def extract_and_generate(
    image_files: Annotated[List[UploadFile], File(..., description="UI/UX screenshots or images")],
    reference_files: Annotated[Optional[List[UploadFile]], File(description="Optional reference docs (PDF/DOCX)")]=None
):
    """
    1. Extract raw_info from multiple image_files and combine into a single output
    2. Optionally process reference_files
    3. Generate user stories based on combined raw_info and reference files
    """

    # Step 1: Extract info from images and combine
    agent_extractor = ImageExtractorAgent()
    combined_info = []
    errors = []

    for image_file in image_files:
        try:
            image_bytes = await image_file.read()
            raw_info_result = agent_extractor.run(image_bytes, image_file.filename)
            raw_info = raw_info_result.get("raw_info", "") if isinstance(raw_info_result, dict) else str(raw_info_result)
            
            if not raw_info or not str(raw_info).strip():
                errors.append(f"No raw_info extracted from {image_file.filename}")
                continue
                
            combined_info.append(f"--- {image_file.filename} ---\n{raw_info}")
        except Exception as e:
            errors.append(f"Error processing {image_file.filename}: {str(e)}")

    # Combine all extracted info into a single string
    final_raw_info = "\n\n".join(combined_info)
    if not final_raw_info and errors:
        raise HTTPException(status_code=400, detail="No valid information extracted from any image. Errors: " + "; ".join(errors))
    
    if errors:
        final_raw_info += "\n\n--- Errors ---\n" + "\n".join(errors)

    # Step 2: Save optional reference docs
    reference_paths = []
    if reference_files:
        try:
            for f in reference_files:
                ext = os.path.splitext(f.filename)[1]
                safe_name = f"{uuid.uuid4().hex}{ext}"
                file_path = os.path.join(UPLOAD_DIR, safe_name)

                with open(file_path, "wb") as buffer:
                    shutil.copyfileobj(f.file, buffer)

                reference_paths.append(file_path)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to save reference files: {str(e)}")

    # Step 3: Generate user stories
    agent_userstory = RequirementUserStoryAgent(llm_caller=call_llm, rag_service=rag_service)
    try:
        result = agent_userstory.run({
            "raw_info": final_raw_info,
            "reference_docs": reference_paths
        })
        return result  # Expected to return {"user_stories": [...]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"User story generation failed: {str(e)}")    
##########################################################################
class AcceptanceCriteriaRequest(BaseModel):
    description: str
    story: str

@router.post("/update-acceptance-criteria")
async def update_acceptance_criteria(request: AcceptanceCriteriaRequest):
    """
    Generate acceptance criteria for a given user story and description.
    """
    agent = AcceptanceCriteriaUpdateAgent(llm_caller=call_llm)
    result = agent.run(request.model_dump())

    if not result.get("acceptance_criteria"):
        raise HTTPException(
            status_code=500,
            detail="Failed to update acceptance criteria"
        )

    return result
###########################################################################

# class FilePathRequest(BaseModel):
#     file_path: str

# @router.post("/extract")
# async def extract_requirements(request: FilePathRequest):
#     agent = ExtractorAgent(llm_caller=call_gemini)
#     extracted = agent.run(request.file_path)
#     # return extracted
#     return {"extracted_requirements": extracted}
@router.post("/extract")
async def extract_requirements(file: Annotated[UploadFile, File(...)]):
    # Validate file type
    if not file.filename.endswith(('.docx', '.pdf')):
        raise HTTPException(status_code=400, detail="Only .docx and .pdf files are supported")
    
    # Create temporary file
    with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(file.filename)[1]) as temp_file:
        # Save uploaded content to temp file
        content = await file.read()
        temp_file.write(content)
        temp_path = temp_file.name
    
    try:
        # Process the file
        agent = ExtractorAgent(llm_caller=call_llm)
        extracted = agent.run(temp_path)
        return {"extracted_requirements": extracted}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing file: {str(e)}")
    finally:
        # Clean up temporary file
        if os.path.exists(temp_path):
            os.unlink(temp_path)
###########################################################################

class RequirementsRequest(BaseModel):
    extracted_requirements: List[Dict]

@router.post("/classify")
async def classify_requirements(request: RequirementsRequest):
    agent = ClassifierAgent(llm_caller=call_llm)
    classified = agent.run(request.extracted_requirements)
    return classified

###########################################################################

class ClassifiedRequirementsRequest(BaseModel):
    classified_requirements: List[Dict]

@router.post("/validate")
async def validate_requirements(request: ClassifiedRequirementsRequest):
    agent = ValidationAgent(llm_caller=call_llm)
    validated = agent.run(request.model_dump())
    return validated

###########################################################################

class ValidatedRequirementsRequest(BaseModel):
    validated_requirements: List[Dict]


@router.post("/user_stories")
async def generate_user_stories(request: ValidatedRequirementsRequest):
    agent = UserStoryAgent(llm_caller=call_llm, rag_service=rag_service)
    user_stories = agent.run(request.model_dump())
    return user_stories

###########################################################################

class FeedbackRequest(BaseModel):
    story: Dict
    feedback: str
    requirement_text: Optional[str] = None  # Original requirement text for ChromaDB lookup
    collection_name: Optional[str] = "requirements_collection"  # Which collection to update

@router.post("/update-story")
async def update_story(request: FeedbackRequest):
    """Update a user story based on feedback and sync with ChromaDB"""
    agent = UserStoryFeedbackAgent(llm_caller=call_llm)
    result = agent.run(request.model_dump())
    if not result.get("updated_story"):
        raise HTTPException(status_code=500, detail="Failed to update story from feedback")
    
    updated_story = result["updated_story"]
    user_story_id = updated_story.get("usid", updated_story.get("user_story_id", ""))
    
    # If requirement_text not provided, try to find it using the user story
    requirement_text = request.requirement_text
    if not requirement_text:
        print("\n" + "="*80)
        print("🔍 SEARCHING FOR REQUIREMENT TEXT")
        print("="*80)
        print(f"User story ID: {user_story_id}")
        
        # Try to find requirement text by searching with the original story
        original_story = request.story.get("story", "")
        requirement_text = rag_service.find_requirement_by_story(
            collection_name=request.collection_name,
            user_story_id=user_story_id,
            user_story_text=original_story
        )
        print("="*80 + "\n")
    
    # Sync updated story with ChromaDB if requirement_text is found
    if requirement_text:
        print("\n" + "="*80)
        print("🔄 CHROMADB UPDATE PHASE")
        print("="*80)
        print(f"Updating user story: {user_story_id}")
        print(f"Collection: {request.collection_name}")
        print(f"Requirement text: {requirement_text[:100]}...")
        
        # Get the current story from ChromaDB before updating
        current_story = rag_service.get_story_by_id(
            collection_name=request.collection_name,
            user_story_id=user_story_id
        )
        
        success = rag_service.update_example(
            collection_name=request.collection_name,
            user_story_id=user_story_id,
            requirement_text=requirement_text,
            updated_user_story_data=updated_story
        )
        
        if success:
            print(f"✅ Successfully synced updated story to ChromaDB: {user_story_id}")
            
            # Display what changed
            if current_story:
                print("\n" + "-"*80)
                print("📋 CHANGES MADE TO CHROMADB")
                print("-"*80)
                
                # Compare fields
                fields_to_compare = [
                    ("title", "Title"),
                    ("user_story", "User Story"),
                    ("description", "Description"),
                    ("tshirt_size", "T-shirt Size"),
                    ("priority", "Priority"),
                    ("tags", "Tags"),
                    ("acceptance_criteria", "Acceptance Criteria")
                ]
                
                changes_made = False
                for field_key, field_label in fields_to_compare:
                    old_value = current_story.get(field_key, "")
                    new_value = updated_story.get(field_key, updated_story.get(field_key.replace("_", ""), ""))
                    
                    # Handle different field name formats
                    if field_key == "acceptance_criteria":
                        new_value = updated_story.get("acceptance_criteria", updated_story.get("acceptanceCriteria", []))
                    elif field_key == "tags":
                        new_value = updated_story.get("tags", updated_story.get("Tags/Labels", []))
                    
                    # Convert to string for comparison
                    old_str = str(old_value)
                    new_str = str(new_value)
                    
                    if old_str != new_str:
                        changes_made = True
                        print(f"\n🔸 {field_label}:")
                        print(f"   BEFORE: {old_str[:150]}")
                        print(f"   AFTER:  {new_str[:150]}")
                
                if not changes_made:
                    print("\nℹ️  No changes detected in stored fields")
                
                print("-"*80)
            
        else:
            print(f"⚠️  Failed to sync updated story to ChromaDB")
        print("="*80 + "\n")
    else:
        print("\n⚠️  Could not find requirement text - skipping ChromaDB sync\n")
    
    return result

###########################################################################
# Manual Update Endpoint for ChromaDB
###########################################################################

class ManualUpdateRequest(BaseModel):
    user_story_id: str
    requirement_text: str
    updated_story: Dict
    collection_name: Optional[str] = "requirements_collection"

@router.post("/update-chromadb")
async def update_chromadb_story(request: ManualUpdateRequest):
    """
    Manually update a user story in ChromaDB without LLM processing.
    Useful when user stories are edited directly in the UI.
    """
    try:
        success = rag_service.update_example(
            collection_name=request.collection_name,
            user_story_id=request.user_story_id,
            requirement_text=request.requirement_text,
            updated_user_story_data=request.updated_story
        )
        
        if success:
            return {
                "success": True,
                "message": f"Successfully updated user story {request.user_story_id} in ChromaDB"
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to update ChromaDB")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating ChromaDB: {str(e)}")

###########################################################################


class UserStoriesRequest(BaseModel):
    user_stories: List[Dict]

@router.post("/gherkin")
async def generate_gherkin(request: UserStoriesRequest):
    agent = GherkinAgent(llm_caller=call_llm)
    gherkin = agent.run(request.model_dump())
    return gherkin

###########################################################################

@router.post("/test_cases")
async def generate_test_cases(request: UserStoriesRequest):
    agent = TestCaseAgent(llm_caller=call_llm)
    test_cases = agent.run(request.model_dump())
    print("Generated test cases:", test_cases)
    return test_cases

###########################################################################

class TraceabilityRequest(BaseModel):
    classified_requirements: List[Dict]
    validated_requirements: Optional[List[Dict]]
    user_stories: Optional[List[Dict]]
    gherkin_scenarios: Optional[List[Dict]]
    test_cases: Optional[List[Dict]]

# @router.post("/traceability")
# async def generate_traceability(request: TraceabilityRequest):
#     agent = TraceabilityAgent()  # ✅ no args since class doesn’t support it
#     traceability = agent.run(request.model_dump())
#     return traceability

@router.post("/traceability")
async def generate_traceability(request: TraceabilityRequest):
    inputs = {
        "classified": request.classified_requirements or [],
        "validated": request.validated_requirements or [],
        "user_stories": request.user_stories or [],
        "gherkin_scenarios": request.gherkin_scenarios or [],
        "test_cases": request.test_cases or [],
    }
    agent = TraceabilityAgent()
    traceability = agent.run(inputs)
    return traceability
###########################################################################

class NewTraceabilityRequest(BaseModel):
    user_stories: List[Dict]
    gherkin_scenarios: Optional[List[Dict]] = None
    test_cases: Optional[List[Dict]] = None

@router.post("/newtraceability")
async def generate_new_traceability(request: NewTraceabilityRequest):
    inputs = {
        "user_stories": request.user_stories or [],
        "gherkin_scenarios": request.gherkin_scenarios or [],
        "test_cases": request.test_cases or [],
    }
    agent = NewTraceabilityAgent()
    traceability = agent.run(inputs)
    return traceability

###########################################################################
class UserStoryPayload(BaseModel):
    user_stories: Optional[List[Dict[str, Any]]] = None

@router.post("/export-userstories")
async def export_userstories(payload: UserStoryPayload):
    """
    Accepts JSON payload of user stories and returns an Excel file download.
    """
    result = export_user_stories_to_excel(payload.dict(exclude_none=True))

    if result["status"] == "failed":
        raise HTTPException(status_code=400, detail=result["errors"])

    file_path = result["file_path"]

    if not os.path.exists(file_path):
        raise HTTPException(status_code=500, detail="Excel file not found after export.")

    return FileResponse(
        path=file_path,
        filename=os.path.basename(file_path),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
###########################################################################
class TestCasePayload(BaseModel):
    test_cases: Optional[List[Dict[str, Any]]] = None

@router.post("/export-testcases")
async def export_testcases(payload: TestCasePayload):
    """
    Accepts JSON payload of test cases and returns an Excel file download.
    """
    result = export_test_cases_to_excel(payload.dict(exclude_none=True))

    if result["status"] == "failed":
        raise HTTPException(status_code=400, detail=result["errors"])

    file_path = result["file_path"]

    if not os.path.exists(file_path):
        raise HTTPException(status_code=500, detail="Excel file not found after export.")

    return FileResponse(
        path=file_path,
        filename=os.path.basename(file_path),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
###########################################################################
@router.post("/jira/user_stories")
async def create_user_stories(request: UserStoriesRequest):
    response = post_user_stories_to_jira(request.user_stories)
    if response is None:
        raise HTTPException(status_code=500, detail="Failed to create user stories in Jira")
    return response

###########################################################################

class TestCasesRequest(BaseModel):
    test_cases: List[Dict]

@router.post("/jira/test_cases")
async def create_test_cases(request: TestCasesRequest):
    response = post_test_cases_to_jira(request.test_cases)
    if response is None:
        raise HTTPException(status_code=500, detail="Failed to create test cases in Jira")
    return response


#########################################################################

# New endpoint for YAML to JSON conversion
@router.post("/convert-yaml-to-requirements-json")
async def convert_yaml_to_json(file: Annotated[UploadFile, File(...)]):
    """
    Upload a YAML file and convert it to JSON format.
    Expects YAML with 'Functional_Requirements' structure and returns JSON with specified fields.
    """
    # Validate file type
    if not file.filename.endswith(('.yaml', '.yml', '.YAML')):
        raise HTTPException(status_code=400, detail="Only .yaml or .yml files are supported")

    # Create temporary file
    with tempfile.NamedTemporaryFile(delete=False, suffix='.yaml') as temp_file:
        # Save uploaded content to temp file
        content = await file.read()
        temp_file.write(content)
        temp_path = temp_file.name

    try:
        # Read and parse YAML content
        with open(temp_path, 'r') as f:
            yaml_content = f.read()
        
        data = yaml.safe_load(yaml_content)
        if not data or 'Functional_Requirements' not in data:
            raise HTTPException(status_code=400, detail="Invalid YAML structure: Missing 'Functional_Requirements'")

        # Initialize the output list for JSON
        output = []

        # Process each requirement in Functional_Requirements
        for req in data.get('Functional_Requirements', []):
            requirement = {
                "requirement_id": req.get('requirement_id', ''),
                "requirement_text": req.get('requirement_text', ''),
                "original_text": req.get('original_text', ''),
                "line_number": req.get('line_number', None),
                "page_number": req.get('page_number', None),
                "source_section": req.get('source_section_name', '')
            }
            output.append(requirement)

        return {"extracted_requirements": output}

    except yaml.YAMLError as e:
        raise HTTPException(status_code=400, detail=f"Error parsing YAML: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing file: {str(e)}")
    finally:
        # Clean up temporary file
        if os.path.exists(temp_path):
            os.unlink(temp_path)
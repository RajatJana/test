# agents/classifier_agent.py
import logging
from google.adk import Agent
from google.adk.tools import FunctionTool
from tools.classifier_tools import classify_requirement_tool
from typing import List, Dict, Callable
from utils.logger import get_logger
import json

class ClassifierAgent(Agent):
    def __init__(self, llm_caller: Callable[[str], str], verbose=False):
        super().__init__(
            name="ClassifierAgent",
            description="Classifies extracted requirements using Gemini."
        )
        
        self._llm_caller = llm_caller
        """ self._logger = get_logger(
            log_to_console=False,
            log_to_file=True,
            level=logging.DEBUG if verbose else logging.INFO
        ) """

        """ # Wrap and bind Gemini-aware tool
        def classify_with_llm(inputs: Dict, verbose=False) -> Dict:
            return classify_requirement_tool(inputs, self._llm_caller, verbose)

        self._classify_func = classify_with_llm  # for internal use

        # Register tools
        self.tools.append(FunctionTool(func=classify_with_llm)) """

    def run(self, extracted_requirements: List[Dict]) -> Dict:
        # self._logger.info(f"[{self.name}] Received {len(extracted_requirements)} requirements for classification.")
        if not extracted_requirements:
            return {"classified_requirements": []}

        batch_size = 10
        all_classified_requirements = []

        for i in range(0, len(extracted_requirements), batch_size):
            current_batch_no = (i // batch_size) + 1
            total_batches = (len(extracted_requirements) + batch_size - 1) // batch_size
            print(
                f">>> Processing Classification Batch {current_batch_no} of {total_batches} "
                f"(Requirements {i} to {min(i + batch_size, len(extracted_requirements)) - 1})"
            )

            batch = extracted_requirements[i:i + batch_size]

            try:
                classified_batch = classify_requirement_tool(batch, self._llm_caller, verbose=False)
                all_classified_requirements.extend(classified_batch.get("classified_requirements", []))
            except Exception as e:
                logging.error(f"Error processing classification batch {current_batch_no}: {e}")
                continue

        return {"classified_requirements": all_classified_requirements}
from typing import List, Dict, Callable, Optional
import json
import logging

from tools.prompt_utils import extract_clean_json
from tools.rag_service import RAGService

class UserStoryAgent:
    def __init__(self, llm_caller: Callable[[str], str], rag_service: Optional[RAGService] = None):
        self.llm_caller = llm_caller
        self.rag_service = rag_service or RAGService()
        self.collection_name = "requirements_collection"

    def _resequence_story_ids(self, stories: List[Dict]) -> List[Dict]:
        for idx, story in enumerate(stories, 1):
            story["user_story_id"] = f"US-{idx:03d}"
        return stories

    def run(self, inputs: Dict) -> Dict:
        validated = inputs["validated_requirements"]

        # Step 1: Filter functional and validated
        functional_reqs = [
            r for r in validated
            if r.get("requirement_type") == "Functional"
            and r.get("validation", {}).get("llm_check_passed") is True
        ]

        if not functional_reqs:
            return {"user_stories": []}

        batch_size = 10
        all_parsed: List[Dict] = []

        for i in range(0, len(functional_reqs), batch_size):
            current_batch_no = (i // batch_size) + 1
            total_batches = (len(functional_reqs) + batch_size - 1) // batch_size
            print(
                f">>> Processing User Story Batch {current_batch_no} of {total_batches} "
                f"(Requirements {i} to {min(i + batch_size, len(functional_reqs)) - 1})"
            )

            batch_reqs = functional_reqs[i:i + batch_size]

            # Step 2: Retrieve examples from RAG for this batch
            all_retrieved_examples = []
            print("\n" + "="*80)
            print("🔍 RAG RETRIEVAL PHASE - Requirements-based Flow")
            print("="*80)

            for req in batch_reqs:
                req_text = req["requirement_text"]
                examples = self.rag_service.retrieve_examples(
                    collection_name=self.collection_name,
                    query_text=req_text,
                    top_k=1
                )
                if examples:
                    all_retrieved_examples.append(examples)
                    print(f"\n✅ Retrieved {len(examples)} example(s) for requirement: {req['requirement_id']}")
                    print(f"   Requirement: {req_text[:100]}...")

            # Step 3: Rank and select top 5 examples for this batch
            top_examples = self.rag_service.rank_and_select_top_examples(
                all_retrieved_examples,
                top_n=5
            )

            if top_examples:
                print(f"\n📊 Selected top {len(top_examples)} examples for prompt augmentation")
                for j, ex in enumerate(top_examples, 1):
                    print(f"   {j}. {ex['user_story_id']} - Distance: {ex['distance']:.4f}")
            else:
                print("\n⚠️  No examples available for this run (first run or empty database)")

            # Step 4: Format examples for prompt
            examples_text = self.rag_service.format_examples_for_prompt(top_examples)

            # Step 5: Build prompt with examples for this batch
            formatted = "\n".join([
                f'{r["requirement_id"]}: {r["requirement_text"]}' for r in batch_reqs
            ])

            prompt = f"""
        You are a skilled product owner. Your task is to analyze business requirements and break them down into actionable user stories for a development team. For each requirement, generate one or more user stories (some requirements may result in multiple user stories).

        {examples_text}

        For each user story, provide:

        ⦁\tuser_story_id: Always start the 1st user story ID from US-001. Subsequent IDs should increment sequentially.
        ⦁\ttitle: A short, descriptive title.
        ⦁\tuser_story: In the format: "As a <role>, I want to <action>, so that <benefit>."
        ⦁\tdescription: A brief sentence to add context or clarification.
        ⦁\tacceptance_criteria: 3–4 clear and testable acceptance criteria.
        ⦁\tconfidence_score: A score from 0.0 to 1.0 reflecting how confidently you believe the requirement was converted correctly. Base this on the clarity and detail of the original requirement. A vague requirement should result in a lower score.
        ⦁\ttshirt_size: An estimate (XS, S, M, L, XL) representing the relative effort to implement the story. These estimates should be consistent across all generated stories.
        ⦁\tpriority: A priority level (High/Medium/Low) based on business value and urgency.

        Respond with raw JSON in the format:
        [
        {{
            "requirement_id": "REQ-001",
            "user_story_id": "US-001",
            "title": "User Authentication via OTP"
            "user_story": "As a user, I want to log in with OTP so that I can access my account securely.",
            "description": "This user story covers the generation and sending of the one-time password. The verification part is handled in a separate story.",            
            "acceptance_criteria": [
            "User receives OTP after entering username.",
            "OTP must expire after 5 minutes.",
            "User cannot proceed without valid OTP."
            ],
            "confidence_score": 0.92,
            "tshirt_size": "M",
            "priority": "High",
            "tags": [
            "authentication",
            "security",
            "login"
            ]
        }},
        ...
        ]

        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        Requirements:
        {formatted}
        """.strip()
            llm_response = self.llm_caller(prompt)

            try:
                parsed = extract_clean_json(llm_response)
                if isinstance(parsed, list):
                    all_parsed.extend(parsed)
            except Exception as e:
                logging.error(f"Failed to parse LLM response: {e}, raw: {llm_response[:500]}")
                continue

        all_parsed = self._resequence_story_ids(all_parsed)

        # Step 6: Store generated user stories in RAG for future use
        if all_parsed:
            print("\n" + "="*80)
            print("💾 STORING EXAMPLES IN RAG DATABASE")
            print("="*80)
            for story in all_parsed:
                req_id = story.get("requirement_id")
                req_text = next(
                    (r["requirement_text"] for r in functional_reqs if r["requirement_id"] == req_id),
                    None
                )
                if req_text:
                    self.rag_service.store_example(
                        collection_name=self.collection_name,
                        requirement_text=req_text,
                        user_story_data=story
                    )
                    print(f"✅ Stored: {story.get('user_story_id')} for {req_id}")
            print("="*80 + "\n")

        return {"user_stories": all_parsed}

        #v1
        # prompt = f"""
        # You are a product owner.

        # For each of the following requirements, generate:
        # - A user story in the format: "As a <role>, I want to <action>, so that <benefit>"
        # - 2–4 clear acceptance criteria
        # - A confidence score between 0.0 and 1.0 based on how confident you are that the requirement was converted correctly
        # - A T-shirt size estimate (XS, S, M, L, XL) representing the relative effort or complexity to implement the user story

        # Respond with raw JSON in the format:
        # [
        # {{
        #     "requirement_id": "REQ-001",
        #     "user_story": "As a user, I want to log in with OTP so that I can access my account securely.",
        #     "acceptance_criteria": [
        #     "User receives OTP after entering username.",
        #     "OTP must expire after 5 minutes.",
        #     "User cannot proceed without valid OTP."
        #     ],
        #     "confidence_score": 0.92,
        #     "tshirt_size": "M"
        # }},
        # ...
        # ]

        # IMPORTANT:
        # - Do NOT use Markdown or triple backticks.
        # - Do NOT add explanations.
        # - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        # Requirements:
        # {formatted}
        # """.strip()
        

        #v2
        # prompt = f"""
        # You are a product owner.

        # For each requirement, generate ONE OR MORE user stories (some requirements may result in multiple user stories).

        # For each user story, provide:

        # - title - short description
        # - A user story in the format: "As a <role>, I want to <action>, so that <benefit>"
        # - 2–4 clear acceptance criteria
        # - A confidence score between 0.0 and 1.0 based on how confident you are that the requirement was converted correctly
        # - A T-shirt size estimate (XS, S, M, L, XL) representing the relative effort or complexity to implement the user story
        # - priority - High/Medium/Low
        # - status - Draft/In Progress/Done
        # - Always start 1st user story id from US-001

        # Respond with raw JSON in the format (example):
        # [
        # {{
        # "requirement_id": "REQ-001",
        # "user_stories": [
        # {{
        # "id": "US-001"
        # "title": "Login validation"
        # "story": "As a user, I want to log in with OTP so that I can access my account securely.",
        # "acceptance_criteria": [
        # "User receives OTP after entering username.",
        # "OTP must expire after 5 minutes.",
        # "User cannot proceed without valid OTP."
        # ],
        # "priority": "High",
        # "tshirt_size": "M",
        # "confidence_score": 0.92
        # }},
        # ...
        # ]
        # }},
        # ...
        # ]

        # IMPORTANT:
        # - Do NOT use Markdown or triple backticks.
        # - Do NOT add explanations.
        # - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        # Requirements:
        # {formatted}
        # """.strip()

        #v3
        # For the 1st Requirement generate atleast 3 user stories.
        prompt = f"""
        You are a skilled product owner. Your task is to analyze business requirements and break them down into actionable user stories for a development team. For each requirement, generate one or more user stories (some requirements may result in multiple user stories).

        For each user story, provide:

        ⦁	user_story_id: Always start the 1st user story ID from US-001. Subsequent IDs should increment sequentially.
        ⦁	title: A short, descriptive title.
        ⦁	user_story: In the format: "As a <role>, I want to <action>, so that <benefit>."
        ⦁	description: A brief sentence to add context or clarification.
        ⦁	acceptance_criteria: 3–4 clear and testable acceptance criteria.
        ⦁	confidence_score: A score from 0.0 to 1.0 reflecting how confidently you believe the requirement was converted correctly. Base this on the clarity and detail of the original requirement. A vague requirement should result in a lower score.
        ⦁	tshirt_size: An estimate (XS, S, M, L, XL) representing the relative effort to implement the story. These estimates should be consistent across all generated stories.
        ⦁	priority: A priority level (High/Medium/Low) based on business value and urgency.

        Respond with raw JSON in the format:
        [
        {{
            "requirement_id": "REQ-001",
            "user_story_id": "US-001",
            "title": "User Authentication via OTP"
            "user_story": "As a user, I want to log in with OTP so that I can access my account securely.",
            "description": "This user story covers the generation and sending of the one-time password. The verification part is handled in a separate story.",            
            "acceptance_criteria": [
            "User receives OTP after entering username.",
            "OTP must expire after 5 minutes.",
            "User cannot proceed without valid OTP."
            ],
            "confidence_score": 0.92,
            "tshirt_size": "M",
            "priority": "High",
            "tags": [
            "authentication",
            "security",
            "login"
            ]
        }},
        ...
        ]

        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        Requirements:
        {formatted}
        """.strip()
        llm_response = self.llm_caller(prompt)

        try:
            # parsed = json.loads(llm_response)
            parsed = extract_clean_json(llm_response)
        except Exception as e:
            logging.error(f"Failed to parse LLM response: {e}, raw: {llm_response[:500]}")
            parsed = []

        return {"user_stories": parsed}

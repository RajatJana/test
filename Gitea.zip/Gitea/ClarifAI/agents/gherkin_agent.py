from typing import List, Dict, Callable
import json
import logging

from tools.prompt_utils import extract_clean_json


class GherkinAgent:
    def __init__(self, llm_caller: Callable[[str], str]):
        self.llm_caller = llm_caller

    def run(self, inputs: Dict) -> Dict:
        user_stories: List[Dict] = inputs["user_stories"]

        if not user_stories:
            return {"gherkin_scenarios": []}

        # ── Batch Processing ────────────────────────────────────────────────
        batch_size = 10
        all_gherkin_scenarios: List[Dict] = []
        total_batches = (len(user_stories) + batch_size - 1) // batch_size

        for i in range(0, len(user_stories), batch_size):
            current_batch_no = (i // batch_size) + 1
            batch = user_stories[i : i + batch_size]

            print(
                f">>> Processing Gherkin Batch {current_batch_no} of {total_batches} "
                f"(Stories {i + 1} to {min(i + batch_size, len(user_stories))})"
            )

            # Format only the fields needed for Gherkin generation
            formatted = "\n".join([
                f"""Requirement ID: {story['requirement_id']}
                User Story Id: {story['user_story_id']}
                User Story: {story['user_story']}
                Acceptance Criteria:
-               {joined_criteria}""".strip()
                for story in batch
                for joined_criteria in ['\n- '.join(story['acceptance_criteria'])]
            ])

            prompt = f"""
        You are a test automation expert.

        For each user story below, generate:
        - A Gherkin "Feature" name
        - One or two or three test "Scenario" titles
        - Steps in Gherkin format: Given / When / Then
        - A confidence_score between 0.0 and 1.0 indicating how accurate the Gherkin test is

        Return JSON only in this format:
        [
        {{
            "requirement_id": "REQ-001",
            "user_story_id": "US-001",
            "feature": "Login using OTP",
            "scenarios": [
            {{
                "name": "Successful login with valid OTP",
                "steps": [
                "Given the user enters a valid username",
                "And the user receives an OTP",
                "When the user enters the correct OTP",
                "Then the user is logged in"
                ]
            }}
            ],
            "confidence_score": 0.92
        }},
        ...
        ]

        DO NOT use markdown or triple backticks.
        DO NOT include explanation.
        Respond only with raw JSON.

        Requirements:
        {formatted}
            """.strip()

            try:
                llm_response = self.llm_caller(prompt)
                batch_scenarios = extract_clean_json(llm_response)

                if isinstance(batch_scenarios, list):
                    all_gherkin_scenarios.extend(batch_scenarios)
                    print(f"✅ Batch {current_batch_no}: {len(batch_scenarios)} scenario(s) generated")
                else:
                    logging.warning(f"Batch {current_batch_no} did not return a list. Skipping.")

            except Exception as e:
                logging.error(f"Error processing Gherkin batch {current_batch_no}: {str(e)}")
                continue  # Move to next batch even if one fails

        print(f"✅ Finished! Total Gherkin scenarios generated: {len(all_gherkin_scenarios)}")
        return {"gherkin_scenarios": all_gherkin_scenarios}

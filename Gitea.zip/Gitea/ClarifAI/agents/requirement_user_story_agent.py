# agents/requirement_user_story_agent.py
import logging
from typing import Dict, List, Callable, Optional
from tools.prompt_utils import extract_clean_json
from tools.doc_parsers import extract_text_from_file  # your new parser
from tools.rag_service import RAGService

class RequirementUserStoryAgent:
    def __init__(self, llm_caller: Callable[[str], str], rag_service: Optional[RAGService] = None):
        self.llm_caller = llm_caller
        self.rag_service = rag_service or RAGService()
        self.collection_name = "wireframe_collection"

    def _extract_reference_text(self, docs: List) -> str:
        """
        Extracts and concatenates text from a list of document file paths or file-like objects.
        """
        extracted_parts = []
        for doc in docs:
            try:
                print(f"\n📄 Extracting text from: {getattr(doc, 'filename', doc)}")
                text = extract_text_from_file(doc)
                if text:
                    extracted_parts.append(text.strip())
                    print(f"   ✅ Extracted {len(text)} characters")
                else:
                    print(f"   ⚠️  No text extracted")
            except Exception as e:
                print(f"   ❌ Failed to extract text: {e}")
                logging.error(f"Failed to extract text from {doc}: {e}")
        
        total_text = "\n\n".join(extracted_parts)
        print(f"\n📊 Total reference text extracted: {len(total_text)} characters from {len(extracted_parts)} document(s)")
        return total_text
    
    def _chunk_text(self, text: str, chunk_size: int = 2000) -> List[str]:
        """
        Chunk text into smaller pieces for RAG retrieval and LLM processing.

        Splits by sentence boundaries and fills each chunk up to `chunk_size`
        characters. The number of chunks scales with the input length — e.g.
        55 images (~110 000 chars) with chunk_size=2000 produces ~55 chunks,
        one per image, each fitting comfortably in a single LLM call.

        Args:
            text:       The full text to chunk.
            chunk_size: Target maximum character budget per chunk (default 2000).

        Returns:
            List of text chunks (at least 1).
        """
        # Split on sentence boundaries; keep non-empty sentences
        sentences = text.replace('\n', ' ').split('. ')
        sentences = [s.strip() for s in sentences if s.strip()]

        if not sentences:
            return [text] if text.strip() else []

        chunks: List[str] = []
        current_sentences: List[str] = []
        current_len = 0

        for sentence in sentences:
            sentence_len = len(sentence) + 2  # +2 for ". "
            # Start a new chunk if adding this sentence exceeds the budget
            # (but always include at least one sentence per chunk)
            if current_sentences and current_len + sentence_len > chunk_size:
                chunks.append('. '.join(current_sentences) + '.')
                current_sentences = [sentence]
                current_len = sentence_len
            else:
                current_sentences.append(sentence)
                current_len += sentence_len

        # Flush the last chunk
        if current_sentences:
            chunks.append('. '.join(current_sentences) + '.')

        # Guard: ensure at least one chunk
        if not chunks:
            chunks = [text]

        logging.info(
            f"Chunked {len(text):,} chars into {len(chunks)} chunk(s) "
            f"(target chunk_size={chunk_size})"
        )
        print(f"\n✂️  Chunking: {len(text):,} chars → {len(chunks)} chunk(s) "
              f"(~{chunk_size} chars each)")
        return chunks

    def _batch_chunks(
        self,
        chunks: List[str],
        batch_size: int = 3,
        overlap: int = 1
    ) -> List[List[str]]:
        """
        Groups chunks into overlapping batches for batch LLM processing.

        Each batch contains `batch_size` consecutive chunks. Consecutive batches
        share `overlap` chunks so context is not lost at batch boundaries.

        Args:
            chunks:     The full list of text chunks produced by _chunk_text.
            batch_size: Number of chunks per batch (default 3).
            overlap:    Number of trailing chunks from the previous batch that
                        are prepended to the next batch (default 1).

        Returns:
            A list of batches, where each batch is a list of chunk strings.

        Example (5 chunks, batch_size=3, overlap=1):
            batch 0 → chunks[0:3]   (0, 1, 2)
            batch 1 → chunks[2:5]   (2, 3, 4)   ← chunk 2 is the overlap
        """
        if not chunks:
            return []

        step = max(1, batch_size - overlap)   # how far to advance each iteration
        batches: List[List[str]] = []

        start = 0
        while start < len(chunks):
            end = min(start + batch_size, len(chunks))
            batches.append(chunks[start:end])
            if end == len(chunks):
                break
            start += step

        logging.info(
            f"Created {len(batches)} batch(es) from {len(chunks)} chunk(s) "
            f"(batch_size={batch_size}, overlap={overlap})"
        )
        print(
            f"\n🗂️  Batch plan: {len(chunks)} chunk(s) → "
            f"{len(batches)} batch(es) "
            f"(size={batch_size}, overlap={overlap})"
        )
        return batches

    def _resequence_story_ids(self, stories: List[Dict], id_offset: int) -> List[Dict]:
        """
        Re-numbers user_story_id fields so IDs are globally unique across batches.

        Args:
            stories:   List of story dicts from a single batch.
            id_offset: The next available story index (0-based).

        Returns:
            The same list with user_story_id values rewritten as
            "US-{id_offset+1:03d}", "US-{id_offset+2:03d}", …
        """
        for i, story in enumerate(stories):
            story["user_story_id"] = f"US-{id_offset + i + 1:03d}"
        return stories

    def run(self, inputs: Dict) -> Dict:
        raw_info = inputs.get("raw_info", "")
        reference_docs = inputs.get("reference_docs", [])  # optional list of file paths or file-like objects

        # Extract reference document text (kept SEPARATE from chunking)
        reference_text = ""
        if reference_docs:
            reference_text = self._extract_reference_text(reference_docs)

        # ── CRITICAL: chunk ONLY the wireframe/image text ───────────────────
        # Reference text is NOT chunked — it is injected in full into every
        # batch prompt so every LLM call has complete business rule context.
        # ────────────────────────────────────────────────────────────────────
        chunks = self._chunk_text(raw_info, chunk_size=2000)
        print(f"\n📄 Chunked wireframe text into {len(chunks)} chunks")
        if reference_text:
            print(f"📎 Reference document: {len(reference_text):,} chars — "
                  f"will be injected into EVERY batch prompt")

        # Group chunks into overlapping batches
        batches = self._batch_chunks(chunks, batch_size=3, overlap=1)

        all_parsed_stories: List[Dict] = []
        story_id_offset = 0  # tracks global story count for ID resequencing

        for batch_idx, batch_chunks in enumerate(batches, 1):
            print(f"\n{'='*80}")
            print(f"🚀 PROCESSING BATCH {batch_idx}/{len(batches)}  "
                  f"({len(batch_chunks)} chunk(s))")
            print("="*80)

            # Step 2: Retrieve RAG examples for each chunk in this batch
            all_retrieved_examples = []
            print("\n🔍 RAG RETRIEVAL PHASE - Wireframe-based Flow")

            for i, chunk in enumerate(batch_chunks, 1):
                examples = self.rag_service.retrieve_examples(
                    collection_name=self.collection_name,
                    query_text=chunk,
                    top_k=3
                )
                if examples:
                    all_retrieved_examples.append(examples)
                    print(f"\n✅ Retrieved {len(examples)} example(s) for chunk {i}")
                    print(f"   Chunk preview: {chunk[:100]}...")

            # Step 3: Rank and select top 5 examples
            top_examples = self.rag_service.rank_and_select_top_examples(
                all_retrieved_examples,
                top_n=5
            )

            if top_examples:
                print(f"\n📊 Selected top {len(top_examples)} examples for prompt augmentation")
                for i, ex in enumerate(top_examples, 1):
                    print(f"   {i}. {ex['user_story_id']} - Distance: {ex['distance']:.4f}")
            else:
                print("\n⚠️  No examples available for this batch (first run or empty database)")

            # Step 4: Format examples for prompt
            examples_text = self.rag_service.format_examples_for_prompt(top_examples)

            # Step 5: Build batch wireframe content (image data only)
            batch_wireframe_info = "\n\n".join(batch_chunks)

            # Step 5b: Build reference section — full doc injected every batch
            if reference_text:
                reference_section = (
                    f"\n\nReference Documents (business rules / requirements — "
                    f"apply to all user stories where relevant):\n"
                    f"{'─'*60}\n"
                    f"{reference_text}\n"
                    f"{'─'*60}"
                )
            else:
                reference_section = ""

            # Step 6: Build prompt with examples  (unchanged prompt template)
#             prompt = f"""
# You are an expert software analyst assistant. Your task is to analyze the following raw information extracted from a UI/UX design and generate detailed user stories in a specific JSON format.

# {examples_text}

# For each user story, provide:

# ⦁   user_story_id: Start the first story with "US-001" and increment sequentially for subsequent stories.
# ⦁   title: A short, descriptive title for the story.
# ⦁   user_story: 
#             As a <role>
#             When I, <action>
#             Then, I can <benefit>
#     Rules:
#     <role>: Be specific. Instead of a generic "user," use a descriptive role like "existing customer," "first-time visitor," or "administrator."
#     <action>: Describe a specific, active event, not a passive state. It must start with a verb. For example, use "Tap on 'Send' from the Transfers screen" instead of "I am on the Transfers screen."
#     <benefit>: Phrase this as a capability the user gains. It must start with "I can." For example, use "I can initiate a transfer" instead of "I want to initiate a transfer."

# ⦁  acceptance_criteria: 
#     - Provide minimum 3–4 clear, testable acceptance criteria in a "Given..., When..., Then..." format.
#     - Avoid adding acceptance criteria that are not supported by the provided UI/UX information unless they are explicitly present in the provided reference document. In such cases, include them clearly and maintain their traceability to the reference document.
#     - Avoid repeating identical acceptance criteria across multiple stories unless absolutely necessary.
#     - Include additional **plausible negative scenarios** (even if not shown in the UI/Figma) that could be relevant for BA review, clearly marking them as "Potential Negative Scenario" in the statement so they can be included/excluded later.

# ⦁   Description/Note: If the reference documents provide a specific description, note, or business rule, use that exact text as the description for the respective user story, regardless of its length. If no such information is available in the documents, then write a brief sentence to add context or clarification.
# ⦁   Tags/Labels: An array of relevant string keywords for categorization.
# ⦁   confidence_score: A float between 0.0 and 1.0 representing the confidence in the story's accuracy based on the input.
# ⦁   tshirt_size: A relative effort estimate using "XS", "S", "M", "L", or "XL"
# ⦁   priority: "High", "Medium", or "Low".
# ⦁   requirement_id: Always set this to "N/A".

# Here is an example of the required output format:
# [
#     {{
#         "requirement_id": "N/A",
#         "user_story_id": "US-001",
#         "title": "User Authentication via OTP",
#         "user_story": "As a User, When I click on login, Then i can able to access OTP based login",
#         "acceptance_criteria": [
#             "Given a user is on the login page, When they enter a valid username and click 'Send OTP', Then an OTP is sent to their registered mobile number/email.",
#             "Given an OTP has been sent, When 5 minutes have passed, Then the OTP is invalid.",
#             "Given a user has entered an invalid username, When they click 'Send OTP', Then an error message is displayed."
#         ],
#         "Description/Note": "This user story covers the generation and sending of the one-time password. The verification part is handled in a separate story.",
#         "Tags/Labels": [
#             "authentication",
#             "security",
#             "login"
#         ],
#         "confidence_score": 0.95,
#         "tshirt_size": "M",
#         "priority": "High"
#     }}
# ]


# IMPORTANT:

# ⦁   Do NOT use Markdown or triple backticks in your final output.

# ⦁   Do NOT add any explanations, introductions, or conversational text.

# ⦁   Respond ONLY with the raw JSON array containing the generated user stories.

# Wireframe Input (UI/UX screens for this batch):
# {batch_wireframe_info}{reference_section}
# """.strip()
## Updated Prompt for ADIB
            prompt = f"""
You are an expert software Business Analyst assistant specializing in fintech and banking portals. Your task is to analyze raw information extracted from UI/UX designs and generate detailed, production-ready user stories in a specific JSON format.

{examples_text}

═══════════════════════════════════════════════
FIELD-BY-FIELD INSTRUCTIONS
═══════════════════════════════════════════════

1. requirement_id
   - Always set this to "N/A".

2. user_story_id
   - Start the first story with "US-001" and increment sequentially (US-002, US-003...).

3. title
   - Follow the pattern: "<Portal/Module> – <Feature Action>"
   - Examples: "Broker Dashboard – Application Pipeline Overview", "Login Screen – OTP Verification"
   - Must be specific enough that two stories on the same screen have distinct titles.

4. user_story
   Use this exact format:
   "As a <specific role>, I want to <specific action or view>, so that I can <business outcome or operational benefit>."

   Rules:
   - <role>: Be specific. Use descriptive roles like "Broker," "Sub-broker," "ADIB Sales Agent," "First-time Applicant." Never use a generic "user."
   - <action>: Describe a concrete interaction or information need. Must start with a verb (e.g., "view," "filter," "submit," "track").
   - <so that>: Must express real business value or operational benefit — not just restate the action. Ask "why does this matter to the business or user?"

5. acceptance_criteria
   - Generate a MINIMUM of 6–10 testable acceptance criteria per story.
   - Use strict "Given..., When..., Then..." format for every criterion.
   - You MUST cover all applicable dimensions below. Include at least one criterion per dimension:

     DIMENSION 1 — PRIMARY FLOW
     The core happy-path interaction from trigger to outcome.

     DIMENSION 2 — DATA DISPLAY RULES
     What exact fields, column headers, labels, counts, or values are shown.
     Reference the exact UI element names from the wireframe (e.g., "Application ID," "Last Updated," "FOL In Progress").
     Specify formats where relevant (e.g., date format, currency format, truncation rules).

     DIMENSION 3 — ZERO / EMPTY STATES
     What the UI shows when a count is 0, a list is empty, or no data matches a filter.
     Example: "When count is 0, the card still displays '0' and does not hide."

     DIMENSION 4 — UI INTERACTION BEHAVIOR
     What happens on click, tap, hover, or navigation.
     Example: "Clicking a row in the Recent Applications table opens the Application Details view."
     Example: "Clicking a status card does NOT filter the table in this UI version."

     DIMENSION 5 — ROLE-BASED VISIBILITY & DATA SCOPING
     What data is visible based on the logged-in user's role or organizational hierarchy.
     Example: "A Broker sees only applications initiated by their own employees and mapped sub-brokers."

     DIMENSION 6 — FILTER / REFRESH BEHAVIOR
     How the UI responds when filters change, pages reload, or data updates.
     Example: "All KPI widgets and status cards refresh instantly when the valuation partner filter is changed."

     DIMENSION 7 — NEGATIVE / ERROR SCENARIOS
     Prefix every negative scenario with: [Potential Negative Scenario]
     Include plausible failure cases even if not explicitly shown in the wireframe.
     Examples:
       - Unauthorized access attempts
       - API/data load failures
       - Session timeout mid-action
       - Invalid filter combinations

   Additional rules for acceptance criteria:
   - Reference exact field names, status labels, widget names, and button labels from the wireframe. Never use vague terms like "relevant data," "appropriate message," or "the list."
   - Do NOT repeat identical criteria across multiple stories.
   - If a rule is inferred from UI context rather than explicitly stated, append "(Inferred)" to that criterion.
   - Criteria marked as [Potential Negative Scenario] are included for BA review and may be accepted or excluded during refinement.

6. Description/Note
   - If the reference documents provide a specific description, note, or business rule, use that exact text.
   - If no such information is available, write 2–3 sentences that add business context, clarify scope, or note dependencies on other stories or systems.
   - Mention the corresponding Figma screen name or module if identifiable.

7. Tags/Labels
   - An array of 4–6 relevant lowercase keyword strings for categorization.
   - Include: portal name, feature area, user role, and key technical/functional concepts.
   - Example: ["broker-portal", "dashboard", "KPI", "application-tracking", "role-based-access"]

8. confidence_score
   - A float between 0.0 and 1.0 representing confidence in the story's accuracy based on the input quality.
   - 0.9–1.0: Wireframe is detailed and unambiguous.
   - 0.7–0.89: Some details inferred from context.
   - Below 0.7: Significant assumptions made; flag for BA review.

9. tshirt_size
   - Relative effort estimate: "XS", "S", "M", "L", or "XL"
   - Base this on: number of UI components, data integrations, role/access logic, and edge cases.

10. priority
    - "High", "Medium", or "Low"
    - High = core user journey or blocking dependency.
    - Medium = important but not blocking.
    - Low = enhancement or edge case.

═══════════════════════════════════════════════
OUTPUT FORMAT
═══════════════════════════════════════════════

Return a raw JSON array. Each story must follow this exact structure:

[
    {{
        "requirement_id": "N/A",
        "user_story_id": "US-001",
        "title": "Module – Feature Action",
        "user_story": "As a <role>, I want to <action>, so that I can <business outcome>.",
        "acceptance_criteria": [
            "Given <context>, When <action>, Then <outcome>.",
            "Given <context>, When <action>, Then <outcome>.",
            "Given <context>, When <action>, Then <outcome>. (Inferred)",
            "[Potential Negative Scenario] Given <context>, When <action>, Then <outcome>."
        ],
        "Description/Note": "Business context, scope clarification, or Figma screen reference.",
        "Tags/Labels": [
            "portal-name",
            "feature-area",
            "user-role",
            "key-concept"
        ],
        "confidence_score": 0.95,
        "tshirt_size": "L",
        "priority": "High"
    }}
]

═══════════════════════════════════════════════
STRICT OUTPUT RULES
═══════════════════════════════════════════════

- Do NOT use Markdown, triple backticks, or code fences in your output.
- Do NOT add explanations, introductions, commentary, or conversational text.
- Do NOT truncate stories or acceptance criteria to save space.
- Respond ONLY with the raw JSON array.
- If the input contains multiple screens, generate one or more stories per screen as needed — do not merge unrelated features into a single story.
- Every story must be self-contained and independently testable.

═══════════════════════════════════════════════
INPUT
═══════════════════════════════════════════════

Wireframe Input (UI/UX screens for this batch):
{batch_wireframe_info}{reference_section}
""".strip()
            # Step 7: Print final prompt for debugging
            print("\n" + "="*80)
            print(f"📝 FINAL PROMPT SENT TO LLM  (Batch {batch_idx})")
            print("="*80)
            print(prompt)
            print("="*80 + "\n")

            llm_response = self.llm_caller(prompt)

            try:
                batch_parsed = extract_clean_json(llm_response)
            except Exception as e:
                logging.error(
                    f"Failed to parse LLM response for batch {batch_idx}: {e}, "
                    f"raw: {llm_response[:500]}"
                )
                batch_parsed = []

            # Re-sequence IDs so they are globally unique across all batches
            if batch_parsed:
                batch_parsed = self._resequence_story_ids(batch_parsed, story_id_offset)
                story_id_offset += len(batch_parsed)
                all_parsed_stories.extend(batch_parsed)
                print(f"\n✅ Batch {batch_idx}: {len(batch_parsed)} story(ies) generated "
                      f"(total so far: {story_id_offset})")

        # ── De-duplicate by user_story_id (keep first occurrence) ───────────
        seen_ids = set()
        parsed: List[Dict] = []
        for story in all_parsed_stories:
            sid = story.get("user_story_id")
            if sid not in seen_ids:
                seen_ids.add(sid)
                parsed.append(story)

        print(f"\n📦 Final merged story count after de-duplication: {len(parsed)}")

        # Step 8: Store generated user stories in RAG for future use
        # For wireframe flow, we store each chunk with its corresponding user stories
        if parsed and chunks:
            print("\n" + "="*80)
            print("💾 STORING EXAMPLES IN RAG DATABASE")
            print("="*80)
            # Distribute stories across chunks (simple approach: round-robin)
            stories_per_chunk = max(1, len(parsed) // len(chunks))
            for i, chunk in enumerate(chunks):
                # Get stories for this chunk
                start_idx = i * stories_per_chunk
                end_idx = start_idx + stories_per_chunk if i < len(chunks) - 1 else len(parsed)
                chunk_stories = parsed[start_idx:end_idx]
                
                for story in chunk_stories:
                    self.rag_service.store_example(
                        collection_name=self.collection_name,
                        requirement_text=chunk,
                        user_story_data=story
                    )
                    print(f"✅ Stored: {story.get('user_story_id')} for chunk {i+1}")
            print("="*80 + "\n")

        return {"user_stories": parsed}
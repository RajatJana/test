"""
Agent 1: Text Extraction and Title Detection
Extracts text page-wise from PDF and detects document title using rule-based approach (no LLM).
"""
import os
import fitz  # PyMuPDF
import json
from typing import List, Dict, Any
from pathlib import Path
from utils.title_extractor import extract_document_title
import config


def extract_pages_with_metadata(
    pdf_path: str, 
    selected_pages: List[int],
    country: str = "AU"
) -> Dict[str, Any]:
    """
    Extract text from selected pages with metadata.
    
    Args:
        pdf_path: Path to PDF file
        selected_pages: List of page numbers to extract (1-indexed)
        country: Country code for title extraction
        
    Returns:
        Dictionary containing:
            - pages_data: List of {page_number, text} dictionaries
            - title: Extracted document title
            - total_pages: Total number of pages in document
    """
    if not os.path.exists(pdf_path):
        raise FileNotFoundError(f"PDF file not found: {pdf_path}")
    
    # Extract title using rule-based approach
    try:
        title = extract_document_title(pdf_path, country)
    except Exception as e:
        print(f"⚠️ Title extraction failed: {e}. Using default title.")
        title = "Unknown Document"
    
    # Open PDF and extract pages
    doc = fitz.open(pdf_path)
    total_pages = len(doc)
    
    pages_data = []
    
    for page_num in selected_pages:
        if 1 <= page_num <= total_pages:
            page = doc[page_num - 1]
            text = page.get_text()
            
            pages_data.append({
                "page_number": page_num,
                "text": text
            })
    
    doc.close()
    
    return {
        "pages_data": pages_data,
        "title": title,
        "total_pages": total_pages
    }


def save_extracted_pages(
    filename: str,
    pages_data: List[Dict[str, Any]],
    title: str
) -> Dict[str, Any]:
    """
    Save extracted pages to disk for later processing.
    
    Args:
        filename: Original PDF filename
        pages_data: List of page data dictionaries
        title: Document title
        
    Returns:
        Dictionary with output directory and saved files
    """
    # Create output directory
    name_no_ext = os.path.splitext(filename)[0]
    folder_name = f"{name_no_ext}_extracted"
    output_dir = config.TEMP_DATA_DIR / folder_name
    
    if output_dir.exists():
        import shutil
        shutil.rmtree(output_dir)
    
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Save individual page files
    saved_files = []
    for page_data in pages_data:
        page_num = page_data["page_number"]
        text = page_data["text"]
        
        md_filename = f"page_{page_num}.md"
        file_path = output_dir / md_filename
        
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(text)
        
        saved_files.append(md_filename)
    
    # Save metadata
    metadata = {
        "document_name": title,
        "total_pages": len(pages_data),
        "page_numbers": [p["page_number"] for p in pages_data]
    }
    
    meta_path = config.TEMP_DATA_DIR / f"{filename}.meta.json"
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)
    
    return {
        "output_dir": str(output_dir),
        "files": saved_files,
        "metadata": metadata
    }


def upload_and_extract_pdf(
    file_obj,
    filename: str,
    selected_pages: List[int] = None,
    country: str = "AU"
) -> Dict[str, Any]:
    """
    Complete workflow: Upload PDF, extract title, and extract selected pages.
    
    Args:
        file_obj: File object from upload
        filename: Original filename
        selected_pages: List of page numbers to extract (None = all pages)
        country: Country code for title extraction
        
    Returns:
        Dictionary with extraction results
    """
    # Save uploaded file
    pdf_path = config.TEMP_DATA_DIR / filename
    
    with open(pdf_path, "wb") as buffer:
        import shutil
        shutil.copyfileobj(file_obj, buffer)
    
    # Get total pages
    doc = fitz.open(str(pdf_path))
    total_pages = len(doc)
    doc.close()
    
    # If no pages selected, extract all
    if selected_pages is None:
        selected_pages = list(range(1, total_pages + 1))
    
    # Extract pages with metadata
    extraction_result = extract_pages_with_metadata(
        str(pdf_path),
        selected_pages,
        country
    )
    
    # Save extracted pages
    save_result = save_extracted_pages(
        filename,
        extraction_result["pages_data"],
        extraction_result["title"]
    )
    
    return {
        "filename": filename,
        "title": extraction_result["title"],
        "total_pages": extraction_result["total_pages"],
        "extracted_pages": len(selected_pages),
        "output_dir": save_result["output_dir"],
        "files": save_result["files"]
    }

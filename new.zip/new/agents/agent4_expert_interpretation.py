"""
Agent 4: Domain Expert Interpretations
Adds domain-specific and fixed expert interpretations to categorized items.
"""
import html
import re
import json
from typing import List, Dict, Any, Optional
import config
from utils.json_helpers import safe_json_parse


# Fixed expert output field names
LEGAL_FIELD = "Banking Legal Expert Interpretation/Simplification"
RISK_FIELD = "Risk Expert Interpretation/Simplification"
GEO_FIELD = "Geo-specific Financial Practice Expert Interpretation/Simplification"
COMPLIANCE_FIELD = "Compliance Expert Interpretation/Simplification"


def _canonicalize_domain(domain_raw: Optional[str]) -> Optional[str]:
    """
    Normalize domain values to canonical labels.
    """
    if not domain_raw:
        return None
    
    d = (domain_raw or "").strip()
    
    # Drop trailing "Expert"
    if d.lower().endswith(" expert"):
        d = d[: -len(" expert")].strip()
    
    # HTML unescape
    d = html.unescape(d)
    
    # Normalize
    d_low = d.lower().strip().rstrip(".")
    d_low = re.sub(r"\s*&\s*", " & ", d_low)
    d_low = re.sub(r"\s{2,}", " ", d_low)
    d_low = d_low.replace(" and ", " & ")
    d_low = d_low.replace("wealth management", "wealth mgmt.")
    
    canon_map = {
        "retail banking": "Retail Banking",
        "mortgage & retail loans": "Mortgage & Retail Loans",
        "commercial loans": "Commercial Loans",
        "cards": "Cards",
        "wealth mgmt. & investments": "Wealth Mgmt. & Investments",
        "agri-banking": "Agri-Banking",
        "agri banking": "Agri-Banking",
        "payments": "Payments",
    }
    
    if d_low in canon_map:
        return canon_map[d_low]
    
    return None


def _compute_domain_field_name(canonical_domain: str) -> str:
    """Generate field name for domain expert."""
    return f"{canonical_domain} Expert Interpretation/Simplification"


def _build_experts_prompt(model_items: List[Dict[str, Any]], include_fixed: bool) -> str:
    """Build prompt for expert interpretations."""
    domains_guidance = """You are a panel of banking domain experts. For EACH item, adopt the specific expert persona in `Domain`
and write an **Expert Interpretation/Simplification** that:
- Is precise, regulatory-aware, and practical (2–4 sentences).
- Clarifies obligations (who must do what), timing, thresholds, documentation, and controls.
- Highlights edge cases, dependencies, and exceptions when relevant.
- Avoids inventing facts; if the source is ambiguous, state the most conservative assumption.

Expert personas and focus:
1) Retail Banking — deposits, savings/current accounts, KYC/AML, fees, disclosures, branch/digital ops, complaints.
2) Mortgage & Retail Loans — underwriting, collateral/LTV, affordability, APR/fees, servicing, delinquency/collections, disclosures.
3) Commercial Loans — covenants, risk ratings, collateral, borrower/guarantor obligations, reporting, default remedies, restructuring.
4) Cards — issuance, credit limits, disclosures, interest/fees, chargebacks/disputes, fraud controls, network rules.
5) Wealth Mgmt. & Investments — suitability, fiduciary duty, product risks/fees, conflicts, best execution, KYC/AML, disclosures.
6) Agri-Banking — crop/seasonality cycles, input finance, subsidies, collateral/land records, insurance, weather risks.
7) Payments — onboarding, sanction screening, AML/CTF, transaction monitoring, clearing/settlement, chargebacks, scheme rules, reconciliation.
"""
    
    fixed_guidance = """
Additionally, produce FOUR fixed expert interpretations for EVERY item:

• Banking Legal Expert — focus on statutory/contractual obligations, enforceability, defined terms,
  cross-references to applicable regulations, liabilities/remedies, penalties/sanctions, safe harbors.
• Risk Expert — focus on risk taxonomy, control design, limits/thresholds, KRIs/KPIs,
  governance/second line oversight, stress testing/early warning, documentation and evidence.
• Geo-specific Financial Practice Expert — tailor to the jurisdiction inferred from the text (e.g., APRA→Australia,
  PRA/FCA→UK, EBA/ECB→EU, RBI→India, MAS→Singapore). If unclear, give globally accepted practices and note variability.
• Compliance Expert — focus on policies/procedures, monitoring/testing, attestations/approvals,
  training, record retention, breach escalation and regulatory reporting timelines.

Write all interpretations in clear, implementation-ready plain English (2–4 sentences each).
If information is ambiguous, state assumptions conservatively.
"""
    
    output_spec = (
        "Return ONLY valid JSON (no markdown fences, no comments).\n"
        "For each input, the response MUST be a JSON array of objects, each with:\n"
        '  {\n'
        '    "Sr. No.": <same as input>,\n'
        '    "domain_expert_text": "<2–4 sentences or null if Domain missing/unrecognized>",\n'
        '    "banking_legal_expert_text": "<2–4 sentences>",\n'
        '    "risk_expert_text": "<2–4 sentences>",\n'
        '    "geo_practice_expert_text": "<2–4 sentences>",\n'
        '    "compliance_expert_text": "<2–4 sentences>"\n'
        '  }\n'
    )
    
    guidance = domains_guidance + ("\n" + fixed_guidance if include_fixed else "")
    
    prompt = (
        output_spec
        + guidance
        + "\n\n### INPUT ITEMS\n"
        + json.dumps(model_items, ensure_ascii=False)
        + "\n\n### OUTPUT FORMAT (exact keys)\n"
        '[\n'
        '  {\n'
        '    "Sr. No.": 1,\n'
        '    "domain_expert_text": "… or null",\n'
        '    "banking_legal_expert_text": "…",\n'
        '    "risk_expert_text": "…",\n'
        '    "geo_practice_expert_text": "…",\n'
        '    "compliance_expert_text": "…"\n'
        '  }\n'
        ']'
    )
    return prompt


def add_domain_expert_interpretations_batch(
    items: List[Dict[str, Any]],
    include_fixed: bool = True
) -> Dict[str, Any]:
    """Add expert interpretations for a batch of items."""
    if not items:
        return {"data": [], "trace": {}}
    
    llm = config.get_llm_client()
    
    # Prepare inputs
    llm_inputs = []
    index_map = []
    
    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        
        sr_no = item.get("Sr. No.")
        text = item.get("Text")
        base_interp = item.get("Interpretation/Simplification")
        domain_raw = item.get("Domain")
        
        if sr_no is None or not (text or base_interp):
            continue
        
        canonical = _canonicalize_domain(domain_raw)
        source_for_expert = base_interp if base_interp else (text or "")
        
        llm_inputs.append({
            "Sr. No.": sr_no,
            "Domain": canonical,
            "Text": (text or ""),
            "Interpretation/Simplification": (base_interp or ""),
            "For Expert": source_for_expert,
        })
        index_map.append(idx)
    
    if not llm_inputs:
        return {"data": items, "trace": {}}
    
    # Build prompt and call LLM
    prompt = _build_experts_prompt(llm_inputs, include_fixed=include_fixed)
    raw_resp = llm.invoke(prompt, options={"temperature": config.LLM_TEMPERATURE})
    
    # Parse response
    try:
        expert_array = safe_json_parse(raw_resp)
    except Exception as e:
        return {
            "data": items,
            "trace": {
                "error": f"JSON parsing failed: {e}",
                "prompt_preview": prompt[:500] + "...",
                "raw_response": raw_resp[:1000] if raw_resp else ""
            }
        }
    
    # Build lookup by Sr. No.
    resp_by_srno = {}
    if isinstance(expert_array, list):
        for row in expert_array:
            if isinstance(row, dict) and "Sr. No." in row:
                resp_by_srno[row["Sr. No."]] = row
    
    # Merge back into items
    for model_row, data_index in zip(llm_inputs, index_map):
        sr_no = model_row["Sr. No."]
        resp_obj = resp_by_srno.get(sr_no, {})
        
        if not isinstance(resp_obj, dict):
            continue
        
        # Domain-specific field
        canon_domain = model_row.get("Domain")
        domain_text = resp_obj.get("domain_expert_text")
        if canon_domain and isinstance(domain_text, str) and domain_text.strip():
            items[data_index][_compute_domain_field_name(canon_domain)] = domain_text.strip()
        
        # Fixed experts
        legal_text = resp_obj.get("banking_legal_expert_text")
        if isinstance(legal_text, str) and legal_text.strip():
            items[data_index][LEGAL_FIELD] = legal_text.strip()
        
        risk_text = resp_obj.get("risk_expert_text")
        if isinstance(risk_text, str) and risk_text.strip():
            items[data_index][RISK_FIELD] = risk_text.strip()
        
        geo_text = resp_obj.get("geo_practice_expert_text")
        if isinstance(geo_text, str) and geo_text.strip():
            items[data_index][GEO_FIELD] = geo_text.strip()
        
        compliance_text = resp_obj.get("compliance_expert_text")
        if isinstance(compliance_text, str) and compliance_text.strip():
            items[data_index][COMPLIANCE_FIELD] = compliance_text.strip()
    
    return {
        "data": items,
        "trace": {
            "prompt_preview": prompt[:300] + "...",
            "raw_response_preview": raw_resp[:400] if raw_resp else "",
            "interpretations_count": len(expert_array) if isinstance(expert_array, list) else 0
        }
    }


def add_domain_expert_interpretations(items: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Add expert interpretations for all items with batch processing."""
    batch_size = config.BATCH_SIZE_AGENT4
    all_traces = []
    
    for i in range(0, len(items), batch_size):
        batch = items[i:i + batch_size]
        result = add_domain_expert_interpretations_batch(batch, include_fixed=True)
        
        # Update items in place
        items[i:i + batch_size] = result["data"]
        
        all_traces.append({
            "batch_index": (i // batch_size) + 1,
            **result.get("trace", {})
        })
    
    return {
        "status": "success",
        "data": items,
        "agent4_traces": all_traces
    }

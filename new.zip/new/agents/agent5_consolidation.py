"""
Agent 5: Final Consolidated Interpretation
Generates final consolidated interpretation by synthesizing all expert inputs.
"""
import json
from typing import List, Dict, Any
import config
from utils.json_helpers import safe_json_parse
from agents.agent4_expert_interpretation import (
    _canonicalize_domain,
    _compute_domain_field_name,
    LEGAL_FIELD,
    RISK_FIELD,
    GEO_FIELD,
    COMPLIANCE_FIELD
)


def _build_final_consolidation_prompt(model_items: List[Dict[str, Any]]) -> str:
    """Build prompt for final consolidation."""
    instructions = """Return ONLY valid JSON (no markdown fences, no comments).

You will receive multiple expert interpretations for each item:
- Base interpretation (if provided)
- Domain expert interpretation (if available)
- Banking Legal Expert interpretation
- Risk Expert interpretation
- Geo-specific Financial Practice Expert interpretation
- Compliance Expert interpretation

TASK: Produce a single, consolidated **Final Interpretation/Simplification** per item that:
1) Is clear, implementation-ready, and 2–4 sentences long.
2) Resolves conflicts conservatively; if experts differ, prefer the stricter/safer reading.
3) Integrates LEGAL (obligations, defined terms, liabilities), RISK (controls, limits, KRIs), GEO (jurisdiction nuances; if geo is vague, note that practices vary), and COMPLIANCE (policies/procedures, monitoring, training, record-keeping, escalation/timelines).
4) If domain expert text exists, ensure domain-specific nuances (e.g., LTV, covenants, card disputes, AML screening) are reflected.
5) Avoid inventing facts. If source is ambiguous, explicitly state a conservative assumption.

OUTPUT FORMAT (strict):
[
  { "Sr. No.": <value as-is>, "final_text": "<2–4 sentences consolidated interpretation>" },
  ...
]
"""
    
    prompt = (
        instructions
        + "\n### INPUT ITEMS (array)\n"
        + json.dumps(model_items, ensure_ascii=False)
        + "\n\n### OUTPUT (JSON array; exact keys)\n"
        '[ { "Sr. No.": 1, "final_text": "…" } ]'
    )
    return prompt


def add_final_consolidated_interpretation_batch(
    items: List[Dict[str, Any]],
    final_field_name: str = "Final Interpretation/Simplification",
    overwrite: bool = True
) -> Dict[str, Any]:
    """Add final consolidated interpretation for a batch of items."""
    if not items:
        return {"data": [], "trace": {}}
    
    llm = config.get_llm_client()
    
    # Gather inputs per row
    llm_inputs = []
    index_map = []
    
    for idx, row in enumerate(items):
        if not isinstance(row, dict):
            continue
        
        sr_no = row.get("Sr. No.")
        if sr_no is None:
            continue
        
        # Skip if final already present and we don't want to overwrite
        if not overwrite and isinstance(row.get(final_field_name), str) and row.get(final_field_name).strip():
            continue
        
        # Base interpretation
        base_interp = row.get("Interpretation/Simplification")
        
        # Domain expert
        domain_text_val = None
        canon = _canonicalize_domain(row.get("Domain"))
        if canon:
            domain_field = _compute_domain_field_name(canon)
            domain_text_val = row.get(domain_field)
        
        # Fixed experts
        legal_text = row.get(LEGAL_FIELD)
        risk_text = row.get(RISK_FIELD)
        geo_text = row.get(GEO_FIELD)
        compliance_text = row.get(COMPLIANCE_FIELD)
        
        # If nothing to consolidate, skip
        if not any([base_interp, domain_text_val, legal_text, risk_text, geo_text, compliance_text]):
            continue
        
        llm_inputs.append({
            "Sr. No.": sr_no,
            "Base Interpretation": (base_interp or ""),
            "Domain": (canon or None),
            "Domain Expert": (domain_text_val or ""),
            "Banking Legal Expert": (legal_text or ""),
            "Risk Expert": (risk_text or ""),
            "Geo-specific Financial Practice Expert": (geo_text or ""),
            "Compliance Expert": (compliance_text or "")
        })
        index_map.append(idx)
    
    if not llm_inputs:
        return {"data": items, "trace": {}}
    
    # Build prompt and invoke
    prompt = _build_final_consolidation_prompt(llm_inputs)
    raw_resp = llm.invoke(prompt, options={"temperature": config.LLM_TEMPERATURE})
    
    # Parse response
    try:
        out_array = safe_json_parse(raw_resp)
    except Exception as e:
        return {
            "data": items,
            "trace": {
                "error": f"JSON parsing failed: {e}",
                "prompt_preview": prompt[:500] + "...",
                "raw_response": raw_resp[:1000] if raw_resp else ""
            }
        }
    
    # Merge back into original rows
    by_sr = {}
    if isinstance(out_array, list):
        for obj in out_array:
            if isinstance(obj, dict) and "Sr. No." in obj:
                by_sr[obj["Sr. No."]] = obj
    
    for model_row, data_index in zip(llm_inputs, index_map):
        sr_no = model_row["Sr. No."]
        consolidated = by_sr.get(sr_no, {})
        final_text = consolidated.get("final_text")
        
        if isinstance(final_text, str) and final_text.strip():
            items[data_index][final_field_name] = final_text.strip()
    
    return {
        "data": items,
        "trace": {
            "prompt_preview": prompt[:300] + "...",
            "raw_response_preview": raw_resp[:400] if raw_resp else "",
            "consolidations_count": len(out_array) if isinstance(out_array, list) else 0
        }
    }


def add_final_consolidated_interpretation(items: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Add final consolidated interpretation for all items with batch processing."""
    batch_size = config.BATCH_SIZE_AGENT5
    all_traces = []
    
    for i in range(0, len(items), batch_size):
        batch = items[i:i + batch_size]
        result = add_final_consolidated_interpretation_batch(
            batch,
            final_field_name="Final Interpretation/Simplification",
            overwrite=True
        )
        
        # Update items in place
        items[i:i + batch_size] = result["data"]
        
        all_traces.append({
            "batch_index": (i // batch_size) + 1,
            **result.get("trace", {})
        })
    
    return {
        "status": "success",
        "data": items,
        "agent5_traces": all_traces
    }

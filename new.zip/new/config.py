"""
Centralized configuration management for RegAssist multi-agent system.
Loads settings from environment variables with sensible defaults.
"""
import os
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv
from langchain_ollama import OllamaLLM

# Load environment variables from .env file if it exists
load_dotenv()

# Base directory
BASE_DIR = Path(__file__).parent.absolute()

# ==================== LLM Configuration ====================
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "gemma3:12b")
LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.0"))
LLM_NUM_CTX = int(os.getenv("LLM_NUM_CTX", "8192"))
DEBUG_LLM = os.getenv("DEBUG_LLM", "0") == "1"

# ==================== ChromaDB Configuration ====================
CHROMA_DB_PATH = os.getenv("CHROMA_DB_PATH", str(BASE_DIR.parent / "chroma_db"))
EMBED_DEVICE = os.getenv("EMBED_DEVICE", "cpu")
EMBED_NORMALIZE = os.getenv("EMBED_NORMALIZE", "1") == "1"
LOCAL_EMBED_MODEL_PATH = os.getenv(
    "LOCAL_EMBED_MODEL_PATH", 
    str(BASE_DIR.parent / "all-MiniLM-L6-v2")
)

# ==================== Agent Batch Sizes ====================
BATCH_SIZE_AGENT2 = int(os.getenv("BATCH_SIZE_AGENT2", "5"))
BATCH_SIZE_AGENT3 = int(os.getenv("BATCH_SIZE_AGENT3", "10"))
BATCH_SIZE_AGENT4 = int(os.getenv("BATCH_SIZE_AGENT4", "10"))
BATCH_SIZE_AGENT5 = int(os.getenv("BATCH_SIZE_AGENT5", "10"))

# ==================== RAG Configuration ====================
RAG_N_RESULTS_PER_CHUNK = int(os.getenv("RAG_N_RESULTS_PER_CHUNK", "2"))
RAG_CHUNK_SIZE = int(os.getenv("RAG_CHUNK_SIZE", "750"))
RAG_CHUNK_OVERLAP = int(os.getenv("RAG_CHUNK_OVERLAP", "100"))

# ==================== File Paths ====================
TEMP_DATA_DIR = Path(os.getenv("TEMP_DATA_DIR", str(BASE_DIR / "temp_data")))
PROMPTS_DIR = Path(os.getenv("PROMPTS_DIR", str(BASE_DIR / "prompts")))
DEPARTMENTS_JSON = Path(os.getenv("DEPARTMENTS_JSON", str(BASE_DIR / "bank_departments_europe.json")))

# Ensure directories exist
TEMP_DATA_DIR.mkdir(parents=True, exist_ok=True)
PROMPTS_DIR.mkdir(parents=True, exist_ok=True)

# ==================== LLM Client Singleton ====================
_llm_client: Optional[OllamaLLM] = None

def get_llm_client() -> OllamaLLM:
    """
    Get or create the LLM client singleton.
    
    Returns:
        OllamaLLM: Configured LLM client instance
    """
    global _llm_client
    
    if _llm_client is None:
        _llm_client = OllamaLLM(
            model=OLLAMA_MODEL,
            base_url=OLLAMA_URL,
            num_ctx=LLM_NUM_CTX
        )
        
        if DEBUG_LLM:
            print(f"✅ LLM Client initialized: {OLLAMA_MODEL} @ {OLLAMA_URL}")
    
    return _llm_client

# ==================== Configuration Summary ====================
def print_config_summary():
    """Print configuration summary for debugging."""
    print("\n" + "="*60)
    print("RegAssist Configuration Summary")
    print("="*60)
    print(f"LLM Model: {OLLAMA_MODEL}")
    print(f"LLM URL: {OLLAMA_URL}")
    print(f"ChromaDB Path: {CHROMA_DB_PATH}")
    print(f"Embedding Device: {EMBED_DEVICE}")
    print(f"Temp Data Dir: {TEMP_DATA_DIR}")
    print(f"Prompts Dir: {PROMPTS_DIR}")
    print(f"Departments JSON: {DEPARTMENTS_JSON}")
    print(f"Agent 2 Batch Size: {BATCH_SIZE_AGENT2}")
    print(f"Agent 3 Batch Size: {BATCH_SIZE_AGENT3}")
    print(f"Agent 4 Batch Size: {BATCH_SIZE_AGENT4}")
    print(f"Agent 5 Batch Size: {BATCH_SIZE_AGENT5}")
    print("="*60 + "\n")

if __name__ == "__main__":
    print_config_summary()

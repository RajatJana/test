"""
Rule-based document title extraction using country-specific profiles.
"""
import fitz
import re
from typing import Dict, List, Optional
from utils.country_profiles import COUNTRY_PROFILES


def normalize(text: str) -> str:
    """Normalize whitespace in text."""
    return " ".join(text.split())


def has_junk(text: str, junk_terms: List[str]) -> bool:
    """Check if text contains any junk terms."""
    t = text.lower()
    return any(j in t for j in junk_terms)


def build_code_regex(codes: List[str]) -> Optional[re.Pattern]:
    """Build regex pattern for standard codes."""
    if not codes:
        return None
    joined = "|".join(codes)
    return re.compile(rf"\b({joined})\s?\d{{2,3}}(\.\d+)?\b", re.IGNORECASE)


def extract_document_title(pdf_path: str, country: str) -> str:
    """
    Extract document title from PDF using rule-based approach.
    
    Args:
        pdf_path: Path to PDF file
        country: Country code (AU, IN, EU, etc.)
        
    Returns:
        Extracted document title
        
    Raises:
        ValueError: If country is not supported
        RuntimeError: If title cannot be detected
    """
    country = country.upper()
    if country not in COUNTRY_PROFILES:
        raise ValueError(f"Unsupported country: {country}")

    profile = COUNTRY_PROFILES[country]
    code_regex = build_code_regex(profile.get("standard_codes", []))

    doc = fitz.open(pdf_path)
    page = doc[0]

    page_height = page.rect.height
    blocks = page.get_text("dict")["blocks"]

    candidates = []

    for block in blocks:
        if block["type"] != 0:
            continue

        y0 = block["bbox"][1]
        if y0 > page_height * 0.40:
            continue

        text = ""
        max_font = 0

        for line in block["lines"]:
            for span in line["spans"]:
                text += span["text"] + " "
                max_font = max(max_font, span["size"])

        text = normalize(text)
        if len(text) < 15:
            continue

        candidates.append({
            "text": text,
            "font": max_font,
            "y": y0
        })

    # -------- RULE 1: semantic title detection --------
    for i, c in enumerate(candidates):
        if has_junk(c["text"], profile["junk_terms"]):
            continue

        has_prefix = any(
            p.lower() in c["text"].lower()
            for p in profile["title_prefixes"]
        )

        has_code = (
            not profile.get("require_code") or
            (code_regex and code_regex.search(c["text"]))
        )

        # ✅ Complete title in one line
        if has_prefix and has_code:
            doc.close()
            return c["text"]

        # 🔥 Prefix found but code missing → try merge
        if has_prefix and profile.get("require_code"):
            if i + 1 < len(candidates):
                merged = f"{c['text']} {candidates[i + 1]['text']}"
                if (
                    code_regex
                    and code_regex.search(merged)
                    and not has_junk(merged, profile["junk_terms"])
                ):
                    doc.close()
                    return merged

    # -------- RULE 2: multiline merge (generic) --------
    candidates.sort(key=lambda x: x["y"])

    for i in range(len(candidates) - 1):
        a, b = candidates[i], candidates[i + 1]

        if abs(b["y"] - a["y"]) < 40:
            merged = f"{a['text']} {b['text']}"
            if not has_junk(merged, profile["junk_terms"]):
                if not profile.get("require_code") or (
                    code_regex and code_regex.search(merged)
                ):
                    doc.close()
                    return merged

    # -------- RULE 3: font-dominant fallback --------
    candidates.sort(key=lambda x: x["font"], reverse=True)

    for c in candidates:
        if not has_junk(c["text"], profile["junk_terms"]):
            doc.close()
            return c["text"]

    doc.close()
    raise RuntimeError("Document title could not be detected")

"""
JSON parsing and cleaning utilities for LLM outputs.
"""
import json
import re
from typing import Any


def clean_json_output(content: str) -> str:
    """
    Remove markdown fences if the model returned them, and trim whitespace.
    
    Args:
        content: Raw LLM output that may contain markdown fences
        
    Returns:
        Cleaned JSON string
    """
    content = (content or "").strip()
    
    if content.startswith("```"):
        parts = content.split("\n", 1)
        content = parts[1] if len(parts) > 1 else ""
        if content.endswith("```"):
            content = content.rsplit("\n", 1)[0]
    
    return content.strip()


def extract_first_json_block(s: str) -> str:
    """
    Minimal salvage: extract first bracketed JSON-looking block.
    Tries array first, then object.
    
    Args:
        s: String potentially containing JSON
        
    Returns:
        Extracted JSON string
    """
    s = s or ""
    
    # Try to find array first
    start = s.find("[")
    end = s.rfind("]")
    if start != -1 and end != -1 and end > start:
        return s[start:end+1]
    
    # Try to find object
    start = s.find("{")
    end = s.rfind("}")
    if start != -1 and end != -1 and end > start:
        return s[start:end+1]
    
    return s.strip()


def safe_json_parse(content: str) -> Any:
    """
    Parse JSON with fallback strategies.
    
    Args:
        content: JSON string to parse
        
    Returns:
        Parsed JSON object
        
    Raises:
        ValueError: If all parsing strategies fail
    """
    # Strategy 1: Direct parse
    try:
        return json.loads(content)
    except Exception:
        pass
    
    # Strategy 2: Clean and parse
    try:
        cleaned = clean_json_output(content)
        return json.loads(cleaned)
    except Exception:
        pass
    
    # Strategy 3: Extract first block and parse
    try:
        extracted = extract_first_json_block(content)
        return json.loads(extracted)
    except Exception:
        pass
    
    # All strategies failed
    raise ValueError(f"Failed to parse JSON from content: {content[:200]}...")

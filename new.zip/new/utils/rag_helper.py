"""
ChromaDB connection and RAG (Retrieval-Augmented Generation) operations.
"""
import os
from typing import List, Tuple, Set, Optional
import chromadb
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction
from chromadb.api.models.Collection import Collection
import config


# Global collection instance
_collection: Optional[Collection] = None


def split_text_into_chunks(text: str, chunk_size: int = 750, overlap: int = 100) -> List[str]:
    """
    Split text into overlapping chunks for RAG processing.
    
    Args:
        text: Text to split
        chunk_size: Size of each chunk
        overlap: Overlap between chunks
        
    Returns:
        List of text chunks
    """
    if not text:
        return []
    
    chunks: List[str] = []
    start = 0
    text_len = len(text)
    
    while start < text_len:
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk)
        
        if end >= text_len:
            break
        
        start += (chunk_size - overlap)
    
    return chunks


def initialize_chromadb() -> Optional[Collection]:
    """
    Initialize ChromaDB client and return collection.
    
    Returns:
        ChromaDB collection or None if initialization fails
    """
    global _collection
    
    if _collection is not None:
        return _collection
    
    try:
        chroma_client = chromadb.PersistentClient(path=config.CHROMA_DB_PATH)
        
        # Setup embedding function
        if os.path.isdir(config.LOCAL_EMBED_MODEL_PATH):
            embed_model_name = config.LOCAL_EMBED_MODEL_PATH
        else:
            embed_model_name = "sentence-transformers/all-MiniLM-L6-v2"
        
        embed_fn = SentenceTransformerEmbeddingFunction(
            model_name=embed_model_name,
            device=config.EMBED_DEVICE,
            normalize_embeddings=config.EMBED_NORMALIZE
        )
        
        _collection = chroma_client.get_collection(
            "banking_regulatory_data",
            embedding_function=embed_fn
        )
        
        print(f"✅ RAG: Connected to ChromaDB at {config.CHROMA_DB_PATH}")
        print(f"   └─ Embedder: {embed_model_name} | device={config.EMBED_DEVICE}")
        
        return _collection
        
    except Exception as e:
        print(f"⚠️ RAG Warning: Could not connect to ChromaDB. RAG will be disabled. Error: {e}")
        return None


def get_rag_examples(full_batch_text: str, n_results_per_chunk: int = None) -> Tuple[str, List]:
    """
    Retrieve RAG examples from ChromaDB for the given text.
    
    Args:
        full_batch_text: Text to query for similar examples
        n_results_per_chunk: Number of results per chunk (uses config default if None)
        
    Returns:
        Tuple of (formatted_examples_string, retrieved_items_list)
    """
    if n_results_per_chunk is None:
        n_results_per_chunk = config.RAG_N_RESULTS_PER_CHUNK
    
    collection = initialize_chromadb()
    
    if not collection or not full_batch_text.strip():
        return "", []
    
    chunks = split_text_into_chunks(
        full_batch_text, 
        chunk_size=config.RAG_CHUNK_SIZE, 
        overlap=config.RAG_CHUNK_OVERLAP
    )
    
    try:
        results = collection.query(
            query_texts=chunks,
            n_results=n_results_per_chunk,
            include=['metadatas', 'distances']
        )
        
        seen_inputs: Set[str] = set()
        formatted_examples = ""
        retrieved_items_for_frontend = []
        
        metadatas_list = results.get('metadatas', [])
        distances_list = results.get('distances', [])
        
        for i, chunk_metadatas in enumerate(metadatas_list):
            current_source_chunk = chunks[i] if i < len(chunks) else ""
            chunk_distances = distances_list[i] if i < len(distances_list) else []
            
            for j, metadata in enumerate(chunk_metadatas or []):
                original_input = metadata.get('original_input', '')
                json_str = metadata.get('output_json', '{}')
                
                is_duplicate = original_input in seen_inputs
                
                if not is_duplicate and original_input:
                    seen_inputs.add(original_input)
                    try:
                        import json
                        output_dict = json.loads(json_str)
                        output_formatted = json.dumps(output_dict, indent=2)
                        dist = float(chunk_distances[j]) if j < len(chunk_distances) else 0.0
                        
                        example_block = (
                            f"\n--- DYNAMIC RAG EXAMPLE (Sim: {dist:.4f}) ---\n"
                            f"Input: \"{original_input}\"\n"
                            f"Output:\n{output_formatted}\n"
                        )
                        formatted_examples += example_block
                    except Exception:
                        pass
                
                # Add to frontend/debug, even if duplicate in prompt
                try:
                    import json
                    output_dict = json.loads(json_str)
                    sim = float(chunk_distances[j]) if j < len(chunk_distances) else 0.0
                    retrieved_items_for_frontend.append({
                        "source_chunk": current_source_chunk,
                        "original_input": original_input,
                        "output_preview": output_dict,
                        "similarity": sim,
                        "used_in_prompt": not is_duplicate
                    })
                except Exception:
                    continue
        
        return formatted_examples, retrieved_items_for_frontend
        
    except Exception as e:
        print(f"   ❌ RAG Search Error: {e}")
        return "", []

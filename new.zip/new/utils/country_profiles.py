"""
Country-specific profiles for document title extraction.
"""

COUNTRY_PROFILES = {
    "AU": {
        "standard_codes": [
            "CPS", "APS", "LPS", "GPS", "HPS",
            "CPG", "APG", "LPG", "GPG",
            "ARS", "GRS"
        ],
        "title_prefixes": [
            "Prudential Standard",
            "Prudential Practice Guide",
            "Reporting Standard"
        ],
        "junk_terms": [
            "determination",
            "instrument",
            "no.",
            "of 20",
            "made under",
            "revokes",
            "banking act",
            "insurance act",
            "life insurance act",
            "private health insurance"
        ],
        "require_code": True
    },

    "IN": {
        "title_prefixes": [
            "Master Direction",
            "Circular",
            "Guidelines",
            "Notification"
        ],
        "junk_terms": [
            "issued by",
            "reserve bank of india",
            "gazette"
        ],
        "require_code": False
    },

    "EU": {
        "title_prefixes": [
            "Guidelines",
            "Regulation",
            "Directive"
        ],
        "junk_terms": [
            "whereas",
            "having regard to",
            "article"
        ],
        "require_code": False
    }
}
